import React from 'react'

const Footer = ():React.ReactNode => {
    return (
        <footer className='text-center fw-bold text-main py-3'>
            My React Project for my university
        </footer>
    )
}

export default Footer
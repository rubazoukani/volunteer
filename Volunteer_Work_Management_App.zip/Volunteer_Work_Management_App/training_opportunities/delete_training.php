<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

// التحقق من وجود مُعرّف فرصة التدريب
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: training_opportunities.php?error=معرف فرصة التدريب غير صالح");
    exit();
}

$training_id = (int)$_GET['id'];

// جلب بيانات فرصة التدريب للعرض - تم التصحيح هنا!
$stmt = $pdo->prepare("
    SELECT t.*, c.name as center_name 
    FROM training_opportunities t 
    LEFT JOIN centers c ON t.center_id = c.id 
    WHERE t.id = ?
");
$stmt->execute([$training_id]);
$training = $stmt->fetch();

if (!$training) {
    header("Location: training_opportunities.php?error=فرصة التدريب غير موجودة");
    exit();
}

// معالجة تأكيد الحذف
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM training_opportunities WHERE id = ?");
        $stmt->execute([$training_id]);
        
        header("Location: training_opportunities.php?success=تم حذف فرصة التدريب بنجاح!");
        exit();
    } catch (Exception $e) {
        $error = "حدث خطأ أثناء حذف فرصة التدريب: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حذف فرصة تدريب - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --danger: #dc3545;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .delete-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            border-top: 4px solid var(--danger);
        }
        
        .warning-box {
            background-color: rgba(220, 53, 69, 0.1);
            border: 1px solid var(--danger);
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
        }
        
        .btn-danger {
            background-color: var(--danger);
            border-color: var(--danger);
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <i class="bi bi-heart-pulse me-2 text-primary"></i>
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="training_opportunities.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة لفرص التدريب
            </a>
            <a href="../logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-danger fw-bold">
            <i class="bi bi-trash me-2"></i> تأكيد حذف فرصة تدريب
        </h2>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="delete-card">
        <div class="text-center mb-4">
            <div class="bg-danger bg-opacity-10 d-inline-flex p-3 rounded-circle mb-3">
                <i class="bi bi-exclamation-triangle fs-1 text-danger"></i>
            </div>
            <h4 class="text-danger">هل أنت متأكد من حذف هذه الفرصة؟</h4>
            <p class="text-muted">هذا الإجراء لا يمكن التراجع عنه.</p>
        </div>

        <!-- معلومات فرصة التدريب -->
        <div class="row mb-4">
            <div class="col-md-8">
                <h5>معلومات فرصة التدريب</h5>
                <ul class="list-unstyled">
                    <li><strong>العنوان:</strong> <?= htmlspecialchars($training['title']) ?></li>
                    <li><strong>المركز:</strong> <?= htmlspecialchars($training['center_name'] ?: 'غير محدد') ?></li>
                    <li><strong>الحالة:</strong> 
                        <span class="badge <?= 
                            $training['status'] === 'open' ? 'bg-success' : 
                            ($training['status'] === 'closed' ? 'bg-warning' : 'bg-danger') 
                        ?>">
                            <?php 
                            if ($training['status'] === 'open') echo 'مفتوح';
                            elseif ($training['status'] === 'closed') echo 'مغلق';
                            else echo 'ممتلئ';
                            ?>
                        </span>
                    </li>
                    <?php if ($training['start_date']): ?>
                        <li><strong>الفترة:</strong> 
                            <?= date('Y-m-d', strtotime($training['start_date'])) ?>
                            <?php if ($training['end_date']): ?>
                                - <?= date('Y-m-d', strtotime($training['end_date'])) ?>
                            <?php endif; ?>
                        </li>
                    <?php endif; ?>
                    <li><strong>تاريخ الإنشاء:</strong> <?= date('Y-m-d', strtotime($training['created_at'])) ?></li>
                </ul>
            </div>
        </div>

        <!-- نموذج التأكيد -->
        <form method="POST" class="text-center">
            <div class="d-flex justify-content-center gap-3">
                <button type="submit" name="confirm_delete" class="btn btn-danger btn-lg">
                    <i class="bi bi-trash me-2"></i> نعم، احذف الفرصة
                </button>
                <a href="training_opportunities.php" class="btn btn-secondary btn-lg">
                    <i class="bi bi-x me-2"></i> إلغاء
                </a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

$error = '';
$success = '';

// التحقق من وجود مُعرّف فرصة التدريب
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: training_opportunities.php?error=معرف فرصة التدريب غير صالح");
    exit();
}

$training_id = (int)$_GET['id'];

// جلب المراكز النشطة
$centers = $pdo->query("SELECT id, name FROM centers WHERE status = 'active' ORDER BY name")->fetchAll();

// جلب بيانات فرصة التدريب - تم التصحيح هنا!
$stmt = $pdo->prepare("
    SELECT t.*, c.name as center_name 
    FROM training_opportunities t 
    LEFT JOIN centers c ON t.center_id = c.id 
    WHERE t.id = ?
");
$stmt->execute([$training_id]);
$training = $stmt->fetch();

if (!$training) {
    header("Location: training_opportunities.php?error=فرصة التدريب غير موجودة");
    exit();
}

// معالجة تحديث البيانات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $center_id = !empty($_POST['center_id']) ? (int)$_POST['center_id'] : null;
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $status = $_POST['status'] ?? 'open';

    if (empty($title)) {
        $error = "يرجى إدخال عنوان فرصة التدريب.";
    } elseif (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
        $error = "تاريخ الانتهاء يجب أن يكون بعد تاريخ البدء.";
    } else {
        $stmt = $pdo->prepare("UPDATE training_opportunities SET title = ?, description = ?, center_id = ?, start_date = ?, end_date = ?, status = ? WHERE id = ?");
        $stmt->execute([$title, $description, $center_id, $start_date ?: null, $end_date ?: null, $status, $training_id]);
        $success = "تم تحديث فرصة التدريب بنجاح!";
        header("Location: training_opportunities.php?success=" . urlencode($success));
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل فرصة تدريب - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .form-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <i class="bi bi-heart-pulse me-2 text-primary"></i>
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="training_opportunities.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة لفرص التدريب
            </a>
            <a href="../logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-pencil-square me-2"></i> تعديل فرصة تدريب: <?= htmlspecialchars($training['title']) ?>
        </h2>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="form-card">
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">عنوان فرصة التدريب <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($training['title']) ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">المركز التطوعي</label>
                    <select name="center_id" class="form-select">
                        <option value="">-- اختيار مركز --</option>
                        <?php foreach ($centers as $center): ?>
                            <option value="<?= $center['id'] ?>" <?= ($training['center_id'] == $center['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($center['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">الوصف</label>
                    <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($training['description']) ?></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">تاريخ البدء</label>
                    <input type="date" name="start_date" class="form-control" value="<?= $training['start_date'] ? date('Y-m-d', strtotime($training['start_date'])) : '' ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">تاريخ الانتهاء</label>
                    <input type="date" name="end_date" class="form-control" value="<?= $training['end_date'] ? date('Y-m-d', strtotime($training['end_date'])) : '' ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">الحالة الحالية</label>
                    <select name="status" class="form-select">
                        <option value="open" <?= $training['status'] === 'open' ? 'selected' : '' ?>>مفتوح</option>
                        <option value="closed" <?= $training['status'] === 'closed' ? 'selected' : '' ?>>مغلق</option>
                        <option value="full" <?= $training['status'] === 'full' ? 'selected' : '' ?>>ممتلئ</option>
                    </select>
                </div>
                <div class="col-12">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i> تحديث فرصة التدريب
                        </button>
                        <a href="training_opportunities.php" class="btn btn-secondary">
                            <i class="bi bi-x me-2"></i> إلغاء
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

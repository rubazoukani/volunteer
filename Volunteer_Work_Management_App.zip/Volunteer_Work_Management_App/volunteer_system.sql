-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2025 at 12:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `volunteer_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `centers`
--

CREATE TABLE `centers` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `centers`
--

INSERT INTO `centers` (`id`, `name`, `location`, `city`, `description`, `status`, `created_at`) VALUES
(1, 'مركز الرجاء الخيري', 'طريق غباغب', 'درعا', 'مركز يقدم دعماً اجتماعياً وتعليمياً للأسر المحتاجة', 'active', '2025-11-22 11:47:26'),
(2, 'جمعية البر التطوعية', 'شارع الحضارة', 'حمص', 'أنشطة إنسانية وصحية للمجتمع المحلي', 'active', '2025-11-22 11:47:26'),
(4, 'مركز أحمد التطوعي', 'شارع الفرقان', 'حلب', 'استجابة لجميع العمليات الطبية الخاصة بالجراحة', 'active', '2025-11-22 11:54:22'),
(5, 'مركز الشام الطبي', 'دمشق شارع بغداد', 'دمشق', 'مركز يضم جميع الخدمات الطبية(عينية جلدية قلبية )', 'active', '2025-11-22 12:06:24');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `created_at`) VALUES
(1, 'دمشق', '2025-11-23 19:46:42'),
(2, 'حلب', '2025-11-23 19:46:42'),
(3, 'حمص', '2025-11-23 19:46:42'),
(4, 'حماة', '2025-11-23 19:46:42'),
(5, 'اللاذقية', '2025-11-23 19:46:42'),
(6, 'طرطوس', '2025-11-23 19:46:42'),
(7, 'درعا', '2025-11-23 19:46:42'),
(8, 'السويداء', '2025-11-23 19:46:42'),
(9, 'إدلب', '2025-11-23 19:46:42'),
(10, 'الرقة', '2025-11-23 19:46:42'),
(11, 'دير الزور', '2025-11-23 19:46:42'),
(12, 'الحسكة', '2025-11-23 19:46:42'),
(13, 'القامشلي', '2025-11-23 19:46:42'),
(14, 'القنيطرة', '2025-11-23 19:46:42');

-- --------------------------------------------------------

--
-- Table structure for table `citizens`
--

CREATE TABLE `citizens` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `id_number` varchar(20) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('ذكر','أنثى') DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `citizens`
--

INSERT INTO `citizens` (`id`, `full_name`, `email`, `phone`, `city`, `address`, `id_number`, `birth_date`, `gender`, `status`, `created_at`, `updated_at`) VALUES
(1, 'أحمد محمد العلي', 'ahmad.ali@example.com', '0912345678', 'دمشق', 'حي الميدان، شارع بغداد رقم 45', '1234567890', '1985-03-15', 'ذكر', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(2, 'سارة خالد الحسين', 'sara.hussein@example.com', '0923456789', 'حلب', 'حي الشهباء، مبنى 12، شقة 3', '2345678901', '1990-07-22', 'أنثى', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(3, 'محمد يوسف أحمد', 'mohammed.yusuf@example.com', '0934567890', 'حمص', 'حي الزهراء، شارع الثورة رقم 78', '3456789012', '1978-11-05', 'ذكر', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(4, 'فاطمة عبد الله', 'fatima.abdullah@example.com', '0945678901', 'اللاذقية', 'حي الصليبة، عمارة النور، طابق 2', '4567890123', '1995-01-30', 'أنثى', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(5, 'خالد سامي محمد', 'khaled.sami@example.com', '0956789012', 'درعا', 'حي السبيل، شارع تشرين رقم 23', '5678901234', '1982-09-12', 'ذكر', 'inactive', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(6, 'رنا علي الحسن', 'rana.hassan@example.com', '0967890123', 'السويداء', 'حي المزة، مبنى السلام، شقة 7', '6789012345', '1993-05-18', 'أنثى', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(7, 'علي محمد عبد الرحمن', 'ali.abdulrahman@example.com', '0978901234', 'إدلب', 'حي المعارض، شارع السلام رقم 67', '7890123456', '1988-12-25', 'ذكر', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(8, 'لمى خالد', 'lama.khaled@example.com', '0989012345', 'الرقة', 'حي النخيل، عمارة الفرات، طابق 3', '8901234567', '1997-08-14', 'أنثى', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(9, 'ياسر سامي', 'yasser.sami@example.com', '0990123456', 'دير الزور', 'حي الفرات، شارع التنظيم رقم 34', '9012345678', '1980-04-03', 'ذكر', 'inactive', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(10, 'منى أحمد', 'mona.ahmed@example.com', '0901234567', 'الحسكة', 'حي غويران، مبنى الكرامة، شقة 5', '0123456789', '1992-06-21', 'أنثى', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48');

-- --------------------------------------------------------

--
-- Table structure for table `help_requests`
--

CREATE TABLE `help_requests` (
  `id` int(11) NOT NULL,
  `requester_name` varchar(100) NOT NULL,
  `requester_contact` varchar(100) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('accepted','rejected') DEFAULT 'rejected',
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `help_requests`
--

INSERT INTO `help_requests` (`id`, `requester_name`, `requester_contact`, `service_id`, `description`, `status`, `submitted_at`) VALUES
(1, 'فاطمة علي', '0501234567', 1, 'أسرة مكونة من 6 أفراد بحاجة لسلال غذائية', 'accepted', '2025-11-22 11:47:26'),
(2, 'محمد القحطاني', '0559876543', NULL, 'شاب بحاجة لدورة تأهيل مهني في مجال الحاسوب', 'accepted', '2025-11-22 11:47:26'),
(3, 'أم خالد', '0531112233', 2, 'أحتاج دعماً نفسياً بعد وفاة زوجي', '', '2025-11-22 11:47:26');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `reviewer_name` varchar(100) NOT NULL,
  `reviewer_email` varchar(100) DEFAULT NULL,
  `reviewer_type` enum('volunteer','citizen','org_admin') NOT NULL,
  `review_text` text NOT NULL,
  `rating` tinyint(4) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `reviewer_name`, `reviewer_email`, `reviewer_type`, `review_text`, `rating`, `created_at`, `updated_at`) VALUES
(11, 'أحمد محمد', 'ahmad@example.com', 'volunteer', 'تجربة ممتازة مع المنظمة، وجدت فرص تطوع مناسبة لمهاراتي.', 5, '2025-11-24 11:39:58', '2025-11-24 11:39:58'),
(12, 'سارة خالد', 'sara@example.com', 'citizen', 'الخدمة كانت سريعة وفعالة، شكرًا للفريق المتطوع.', 4, '2025-11-24 11:39:58', '2025-11-24 11:39:58'),
(13, 'محمد يوسف', 'mohammed@example.com', 'volunteer', 'واجهت بعض الصعوبات في التسجيل، لكن الدعم الفني كان ممتازًا.', 3, '2025-11-24 11:39:58', '2025-11-24 11:39:58'),
(14, 'فاطمة عبد الله', 'fatima@example.com', 'citizen', 'المتطوعون كانوا لطفاء جدًا وساعدوني في حل مشكلتي بسرعة.', 5, '2025-11-24 11:39:58', '2025-11-24 11:39:58'),
(15, 'خالد سامي', 'khaled@example.com', 'org_admin', 'النظام سهل الاستخدام ويوفر جميع الأدوات التي نحتاجها لإدارة المنظمة.', 4, '2025-11-24 11:39:58', '2025-11-24 11:39:58'),
(16, 'رنا علي', 'rana@example.com', 'volunteer', 'فرص التطوع متنوعة ومناسبة للجميع. أنصح بالانضمام.', 5, '2025-11-24 11:39:58', '2025-11-24 11:39:58'),
(17, 'علي محمد', 'ali@example.com', 'citizen', 'الخدمة كانت دون التوقعات، يحتاج الفريق إلى تحسين.', 2, '2025-11-24 11:39:58', '2025-11-24 11:39:58'),
(18, 'لمى خالد', 'lama@example.com', 'volunteer', 'تجربة رائعة، تعلمت الكثير وساعدت المجتمع.', 5, '2025-11-24 11:39:58', '2025-11-24 11:39:58'),
(19, 'ياسر سامي', 'yasser@example.com', 'citizen', 'المتطوعون وصلوا في الوقت المحدد وقدموا مساعدة فعالة.', 4, '2025-11-24 11:39:58', '2025-11-24 11:39:58'),
(20, 'منى أحمد', 'mona@example.com', 'volunteer', 'النظام يحتاج إلى تحسين واجهة المستخدم، لكنه فعال.', 3, '2025-11-24 11:39:58', '2025-11-24 11:39:58');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `description`, `status`, `created_at`) VALUES
(1, 'توزيع السلال الغذائية', 'توفير سلال غذائية شهرية مناسبة للأسر المتعففة', 'inactive', '2025-11-22 11:47:26'),
(2, 'الدعم النفسي', 'جلسات دعم نفسي مجانية للمحتاجين', 'active', '2025-11-22 11:47:26'),
(4, 'رعاية كبار السن', 'زيارات منزلية وخدمات رعاية لكبار السن', 'inactive', '2025-11-22 11:47:26');

-- --------------------------------------------------------

--
-- Table structure for table `training_opportunities`
--

CREATE TABLE `training_opportunities` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `center_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('open','closed','full') DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `training_opportunities`
--

INSERT INTO `training_opportunities` (`id`, `title`, `description`, `center_id`, `start_date`, `end_date`, `status`, `created_at`) VALUES
(1, 'دورة إدارة المشاريع التطوعية', 'تعلم أساسيات إدارة المشاريع الخيرية', 1, '2025-12-05', '2025-12-20', 'open', '2025-11-22 11:47:26'),
(2, 'ورشة مهارات التواصل', 'تحسين مهارات التواصل مع المستفيدين', 2, '2026-01-10', '2026-01-12', 'open', '2025-11-22 11:47:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('org_admin','system_admin','volunteer') NOT NULL COMMENT 'org_admin = مدير منظمة، system_admin = مدير النظام، volunteer = متطوع',
  `status` enum('pending','active','inactive') DEFAULT 'pending',
  `organization_name` varchar(150) DEFAULT NULL COMMENT 'اسم المنظمة (اختياري لمدير المنظمة)',
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `status`, `organization_name`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'مدير النظام', 'sysadmin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'system_admin', 'active', NULL, '099632597', '2025-11-22 11:33:55', '2025-11-23 20:08:26'),
(2, 'مدير منظمة الخير', 'orgadmin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'org_admin', 'active', 'جمعية الخير التطوعية', '0933987452', '2025-11-22 11:33:55', '2025-11-23 20:00:22'),
(3, 'أحمد محمد العلي', 'ahmad.alali@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'volunteer', 'active', NULL, '0912345678', '2025-11-22 12:57:47', '2025-11-22 12:57:47'),
(4, 'سارة خالد الحسين', 'sara.hussein@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'volunteer', 'active', NULL, '0923456789', '2025-11-22 12:57:47', '2025-11-22 12:57:47'),
(5, 'محمد يوسف أحمد', 'mohammed.youssef@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'volunteer', 'active', NULL, '0934567890', '2025-11-22 12:57:47', '2025-11-22 12:57:47'),
(6, 'فاطمة عبد الله', 'fatima.abdullah@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'volunteer', 'inactive', NULL, '0945678901', '2025-11-22 12:57:47', '2025-11-23 20:20:19'),
(7, 'خالد سامي', 'khalid.sami@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'volunteer', 'active', NULL, '0956789012', '2025-11-22 12:57:47', '2025-11-22 12:57:47'),
(8, 'أحمد الكامل', 'amal@gmail.com', '$2y$10$1Vn/TmtpCNYgq/RMC4FVqOzKPi1I5PHDUJ2NJAsepA3w80CobIPd.', 'org_admin', 'inactive', 'منظمة الأمل', NULL, '2025-11-24 09:44:32', '2025-11-24 09:55:42'),
(9, 'rtgg', 'as@gmail.com', '$2y$10$XFK.YeddTwTVmD7.MWx19.4DPEffp3yFDyoACHvaEmLMoxcD4hj7e', 'org_admin', 'pending', 'oih', NULL, '2025-11-24 09:56:34', '2025-11-24 09:56:34');

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `availability` varchar(100) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `volunteers`
--

INSERT INTO `volunteers` (`id`, `user_id`, `phone`, `city`, `skills`, `availability`, `status`, `created_at`) VALUES
(1, 3, '0912345678', 'دمشق', 'التصميم الجرافيكي, مونتاج الفيديو, التصوير الفوتوغرافي', 'عطلة نهاية الأسبوع', 'approved', '2025-11-22 12:58:14'),
(2, 4, '0923456789', 'حلب', 'التدريس, الإرشاد النفسي, الكتابة', 'مساءً بعد الساعة 5', 'pending', '2025-11-22 12:58:14'),
(3, 5, '0934567890', 'حمص', 'البرمجة, تطوير المواقع, دعم فني', 'مرن', 'approved', '2025-11-22 12:58:14'),
(4, 6, '0945678901', 'اللاذقية', 'الترجمة, اللغة الإنجليزية, الترجمة الفورية', 'عطلة نهاية الأسبوع', 'rejected', '2025-11-22 12:58:14'),
(5, 7, '0956789012', 'درعا', 'الإسعافات الأولية, الرعاية الصحية, التمريض', 'مساءً وبعد الظهر', 'pending', '2025-11-22 12:58:14');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_opportunities`
--

CREATE TABLE `volunteer_opportunities` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `center_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('open','closed','full') DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `volunteer_opportunities`
--

INSERT INTO `volunteer_opportunities` (`id`, `title`, `description`, `center_id`, `start_date`, `end_date`, `status`, `created_at`) VALUES
(2, 'دعم فعالية خيرية', 'المساهمة في تنظيم فعالية جمع التبرعات', 2, '2025-11-25', '2025-11-26', 'full', '2025-11-22 11:47:26'),
(3, 'مرشد تطوعي', 'توجيه المتطوعين الجدد وتدريبهم', 1, '2025-12-10', '2026-03-10', 'open', '2025-11-22 11:47:26'),
(4, 'مساعد طبيب', 'مساعدة الأطباء قسم التمريض', 4, '2025-11-22', '2025-11-29', 'full', '2025-11-22 12:12:21');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_requests`
--

CREATE TABLE `volunteer_requests` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `opportunity_id` int(11) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `volunteer_requests`
--

INSERT INTO `volunteer_requests` (`id`, `user_name`, `user_email`, `opportunity_id`, `status`, `submitted_at`) VALUES
(3, 'خالد سليمان', 'khaled@example.com', 2, 'rejected', '2025-11-22 11:47:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `centers`
--
ALTER TABLE `centers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `citizens`
--
ALTER TABLE `citizens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_number` (`id_number`);

--
-- Indexes for table `help_requests`
--
ALTER TABLE `help_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_opportunities`
--
ALTER TABLE `training_opportunities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `center_id` (`center_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `volunteer_opportunities`
--
ALTER TABLE `volunteer_opportunities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `center_id` (`center_id`);

--
-- Indexes for table `volunteer_requests`
--
ALTER TABLE `volunteer_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `opportunity_id` (`opportunity_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `centers`
--
ALTER TABLE `centers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `citizens`
--
ALTER TABLE `citizens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `help_requests`
--
ALTER TABLE `help_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `training_opportunities`
--
ALTER TABLE `training_opportunities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `volunteer_opportunities`
--
ALTER TABLE `volunteer_opportunities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `volunteer_requests`
--
ALTER TABLE `volunteer_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `help_requests`
--
ALTER TABLE `help_requests`
  ADD CONSTRAINT `help_requests_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `training_opportunities`
--
ALTER TABLE `training_opportunities`
  ADD CONSTRAINT `training_opportunities_ibfk_1` FOREIGN KEY (`center_id`) REFERENCES `centers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD CONSTRAINT `volunteers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `volunteer_opportunities`
--
ALTER TABLE `volunteer_opportunities`
  ADD CONSTRAINT `volunteer_opportunities_ibfk_1` FOREIGN KEY (`center_id`) REFERENCES `centers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `volunteer_requests`
--
ALTER TABLE `volunteer_requests`
  ADD CONSTRAINT `volunteer_requests_ibfk_1` FOREIGN KEY (`opportunity_id`) REFERENCES `volunteer_opportunities` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

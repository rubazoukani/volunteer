<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

// فقط مدير النظام يمكنه الدخول
requireRole('system_admin');

// جلب بيانات المستخدم الحالي
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$current_user = $stmt->fetch();

if (!$current_user) {
    header("Location: logout.php");
    exit();
}

$error = '';
$success = '';

// معالجة تحديث بيانات الملف الشخصي
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    
    if (empty($name) || empty($email)) {
        $error = "الاسم والبريد الإلكتروني مطلوبان.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "البريد الإلكتروني غير صحيح.";
    } else {
        // التحقق من عدم وجود بريد إلكتروني مسجل لمستخدم آخر
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $_SESSION['user_id']]);
        if ($stmt->fetch()) {
            $error = "البريد الإلكتروني مستخدم من قبل مستخدم آخر.";
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?");
            $stmt->execute([$name, $email, $phone, $_SESSION['user_id']]);
            
            // تحديث جلسة المستخدم
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            
            $success = "تم تحديث بيانات الملف الشخصي بنجاح!";
            header("Location: system_admin_profile.php?success=" . urlencode($success));
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ملفي الشخصي - مدير النظام</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --primary-light: #3a6bc5;
            --primary-dark: #1e3d6f;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray-light: #e9ecef;
            --gray: #6c757d;
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --card-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
        .profile-card {
            background: white;
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            overflow: hidden;
            max-width: 900px;
            margin: 40px auto;
            transition: var(--transition);
        }
        
        .profile-card:hover {
            box-shadow: 0 15px 35px rgba(0,0,0,0.12);
        }
        
        .profile-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            padding: 45px 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .profile-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
        }
        
        .profile-avatar {
            width: 130px;
            height: 130px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-size: 3.2rem;
            font-weight: bold;
            margin: 0 auto 20px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            position: relative;
            z-index: 1;
            transition: var(--transition);
        }
        
        .profile-avatar:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 30px rgba(0,0,0,0.25);
        }
        
        .profile-name {
            font-weight: 700;
            font-size: 1.9rem;
            margin-bottom: 8px;
            position: relative;
            z-index: 1;
        }
        
        .profile-role {
            opacity: 0.9;
            font-size: 1.15rem;
            margin-bottom: 15px;
            position: relative;
            z-index: 1;
        }
        
        .profile-badge {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            padding: 5px 15px;
            border-radius: 30px;
            font-size: 0.9rem;
            position: relative;
            z-index: 1;
        }
        
        .profile-body {
            padding: 45px;
        }
        
        .section-title {
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 25px;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--gray-light);
            position: relative;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -2px;
            right: 0;
            width: 80px;
            height: 2px;
            background: var(--primary);
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 8px;
        }
        
        .form-control {
            border: 1.5px solid var(--gray-light);
            border-radius: 10px;
            padding: 12px 15px;
            transition: var(--transition);
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(44, 90, 160, 0.15);
        }
        
        .btn-back {
            background: rgba(52, 58, 64, 0.1);
            color: var(--dark);
            border: none;
            padding: 10px 22px;
            border-radius: 30px;
            font-weight: 600;
            margin-bottom: 20px;
            transition: var(--transition);
        }
        
        .btn-back:hover {
            background: rgba(52, 58, 64, 0.2);
        }
        
        .btn-save {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border: none;
            padding: 14px 40px;
            font-weight: 600;
            border-radius: 30px;
            font-size: 1.1rem;
            transition: var(--transition);
            box-shadow: 0 4px 15px rgba(44, 90, 160, 0.3);
        }
        
        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(44, 90, 160, 0.4);
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
        }
        
        .sidebar {
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            width: 280px;
            overflow-y: auto;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }
        
        .sidebar-logo {
            padding: 25px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar a {
            color: #adb5bd;
            text-decoration: none;
            padding: 14px 20px;
            display: block;
            border-radius: 8px;
            margin: 6px 10px;
            transition: var(--transition);
            font-weight: 500;
        }
        
        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255,255,255,0.1);
            color: white;
            transform: translateX(-5px);
        }
        
        .sidebar a i {
            width: 25px;
            text-align: center;
        }
        
        .nav-title {
            color: #6c757d;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            padding: 20px 20px 10px;
            letter-spacing: 0.5px;
        }
        
        .main-content {
            margin-right: 280px;
            padding: 20px;
        }
        
        .header {
            background: white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            padding: 18px 25px;
            position: fixed;
            left: 280px;
            right: 0;
            top: 0;
            z-index: 1000;
        }
        
        .content-area {
            margin-top: 85px;
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 15px 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.1);
            color: var(--success);
            border-left: 4px solid var(--success);
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }
        
        .user-info-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: var(--card-shadow);
            margin-bottom: 25px;
        }
        
        .info-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray-light);
        }
        
        .info-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }
        
        .info-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: rgba(44, 90, 160, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-size: 1.2rem;
            margin-left: 15px;
        }
        
        .info-content h6 {
            margin-bottom: 3px;
            font-weight: 600;
        }
        
        .info-content p {
            margin-bottom: 0;
            color: var(--gray);
        }
        
        @media (max-width: 992px) {
            .sidebar {
                width: 250px;
            }
            
            .main-content {
                margin-right: 250px;
            }
            
            .header {
                left: 250px;
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-right: 0;
            }
            
            .header {
                left: 0;
                position: relative;
            }
            
            .content-area {
                margin-top: 20px;
            }
            
            .profile-body {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>

<!-- الشريط الجانبي -->
<div class="sidebar">
    <div class="sidebar-logo">
        <h5 class="text-white mb-0">نظام إدارة التطوع</h5>
        <small class="text-muted">مدير النظام</small>
    </div>
    
    <a href="system_admin_dashboard.php">
        <i class="bi bi-speedometer2 me-2"></i> لوحة التحكم
    </a>
    
    <div class="nav-title">الحساب</div>
    <a href="system_admin_profile.php" class="active">
        <i class="bi bi-person me-2"></i> ملفي الشخصي
    </a>
    
    <div class="nav-title">إدارة الحسابات</div>
    <a href="system_admin_organizations.php">
        <i class="bi bi-building me-2"></i> مدراء المنظمات
    </a>
    <a href="system_admin_volunteers.php">
        <i class="bi bi-people me-2"></i> المتطوعون
    </a>
    
    <div class="nav-title">إدارة المحتوى</div>
    <a href="system_admin_cities.php">
        <i class="bi bi-geo-alt me-2"></i> المدن
    </a>
    <a href="system_admin_centers.php">
        <i class="bi bi-building me-2"></i> المراكز التطوعية
    </a>
    <a href="system_admin_citizens.php">
        <i class="bi bi-person-lines-fill me-2"></i> المواطنين
    </a>
    
    <div class="nav-title">التحليلات</div>
    <a href="system_admin_reports.php">
        <i class="bi bi-bar-chart-line me-2"></i> التقارير
    </a>
    <a href="system_admin_reviews.php">
        <i class="bi bi-star me-2"></i> التقييمات
    </a>
</div>

<!-- الشريط العلوي -->
<div class="header">
    <div class="d-flex justify-content-between align-items-center">
        <h5 class="mb-0 text-dark fw-bold">ملفي الشخصي</h5>
        <div class="d-flex align-items-center">
            <span class="text-muted me-3">مرحباً، <?= htmlspecialchars($current_user['name']) ?></span>
            <a href="logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</div>

<div class="main-content">
    <div class="content-area">
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert" style="max-width: 900px; margin: 0 auto 20px;">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert" style="max-width: 900px; margin: 0 auto 20px;">
                <i class="bi bi-check-circle-fill me-2"></i>
                <?= htmlspecialchars($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="profile-card">
            <div class="profile-header">
                <div class="profile-role">مدير النظام</div>
                <div class="profile-badge">
                    <i class="bi bi-shield-check me-1"></i> حساب مفعل
                </div>
            </div>
            
            <div class="profile-body">
                <h4 class="section-title"><i class="bi bi-person me-2"></i> معلومات الحساب</h4>
                
                <div class="row">
                    <div class="col-lg-7">
                        <form method="POST">
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <label class="form-label">الاسم الكامل <span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control" 
                                           value="<?= htmlspecialchars($current_user['name']) ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">البريد الإلكتروني <span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control" 
                                           value="<?= htmlspecialchars($current_user['email']) ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">رقم الهاتف</label>
                                    <input type="text" name="phone" class="form-control" 
                                           value="<?= htmlspecialchars($current_user['phone'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">نوع الحساب</label>
                                    <input type="text" class="form-control" value="مدير النظام" disabled>
                                </div>
                            </div>
                            
                            <div class="text-center mt-5">
                                <button type="submit" name="update_profile" class="btn btn-save">
                                    <i class="bi bi-save me-2"></i> تحديث بيانات الملف الشخصي
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    <div class="col-lg-5">
                        <div class="user-info-card">
                            <h6 class="fw-bold mb-3"><i class="bi bi-info-circle me-2 text-primary"></i> معلومات إضافية</h6>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="bi bi-calendar"></i>
                                </div>
                                <div class="info-content">
                                    <h6 class="mb-0">تاريخ الإنشاء</h6>
                                    <p><?= date('Y/m/d', strtotime($current_user['created_at'])) ?></p>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="bi bi-clock"></i>
                                </div>
                                <div class="info-content">
                                    <h6 class="mb-0">آخر تحديث</h6>
                                    <p><?= date('Y/m/d', strtotime($current_user['updated_at'] ?? $current_user['created_at'])) ?></p>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="bi bi-shield-check"></i>
                                </div>
                                <div class="info-content">
                                    <h6 class="mb-0">حالة الحساب</h6>
                                    <p class="text-success">مفعل</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
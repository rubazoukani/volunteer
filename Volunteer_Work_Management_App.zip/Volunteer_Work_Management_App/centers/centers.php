<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';


requireRole('org_admin');


$syrian_cities = [
    'دمشق', 'حلب', 'حمص', 'حماة', 'اللاذقية', 'طرطوس', 
    'درعا', 'السويداء', 'إدلب', 'الرقة', 'دير الزور', 
    'الحسكة', 'القامشلي', 'القنيطرة'
];


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] === 'toggle_status') {
    header('Content-Type: application/json');
    
    if (!isset($_POST['id']) || !is_numeric($_POST['id']) || !isset($_POST['current_status'])) {
        echo json_encode(['success' => false, 'error' => 'بيانات غير صالحة']);
        exit();
    }

    $id = (int)$_POST['id'];
    $current_status = $_POST['current_status'];
    $new_status = $current_status === 'active' ? 'inactive' : 'active';
    
    try {
        $stmt = $pdo->prepare("UPDATE centers SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $id]);
        echo json_encode(['success' => true, 'new_status' => $new_status]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'فشل التحديث']);
    }
    exit();
}

$error = '';
$success = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_center'])) {
    $name = trim($_POST['name'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'active';

    if (empty($name)) {
        $error = "يرجى إدخال اسم المركز.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO centers (name, city, location, description, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $city, $location, $description, $status]);
        $success = "تم إضافة المركز بنجاح!";
        header("Location: centers.php?success=" . urlencode($success));
        exit();
    }
}


$centers = $pdo->query("SELECT * FROM centers ORDER BY created_at DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المراكز التطوعية - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .card-header {
            background: linear-gradient(120deg, var(--primary), #1e4a8a);
            color: white;
            border: none;
            border-radius: 15px 15px 0 0 !important;
        }
        
        .center-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .center-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .status-active {
            background-color: rgba(40, 167, 69, 0.15);
            color: #28a745;
            border: 1px solid #28a745;
        }
        
        .status-inactive {
            background-color: rgba(220, 53, 69, 0.15);
            color: #dc3545;
            border: 1px solid #dc3545;
        }
        
        .btn-icon {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            font-size: 0.9rem;
        }
        
        .form-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
        }
        
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #dc3545;
            transition: .4s;
            border-radius: 24px;
        }
        
        .slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background-color: #28a745;
        }
        
        input:checked + .slider:before {
            transform: translateX(26px);
        }
    </style>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="../dashboard.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للوحة التحكم
            </a>
            
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-building me-2"></i> إدارة المراكز التطوعية
        </h2>
        <span class="badge bg-primary"><?= count($centers) ?> مركز</span>
    </div>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- قسم إضافة مركز جديد -->
    <div class="form-section mb-5">
        <h4 class="mb-4"><i class="bi bi-plus-circle me-2 text-primary"></i> إضافة مركز جديد</h4>
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">اسم المركز <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">المدينة <span class="text-danger">*</span></label>
                    <select name="city" class="form-select" required>
                        <option value="">-- اختر المدينة --</option>
                        <?php foreach ($syrian_cities as $city): ?>
                            <option value="<?= htmlspecialchars($city) ?>"><?= htmlspecialchars($city) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">الموقع الدقيق (شارع، مبنى، إلخ)</label>
                    <input type="text" name="location" class="form-control" placeholder="مثال: شارع بغداد، مقابل الجامع الأموي">
                </div>
                <div class="col-12">
                    <label class="form-label">الوصف</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
                <div class="col-md-4">
                    <label class="form-label">الحالة</label>
                    <select name="status" class="form-select">
                        <option value="active">نشط</option>
                        <option value="inactive">غير نشط</option>
                    </select>
                </div>
                <div class="col-12">
                    <button type="submit" name="add_center" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i> حفظ المركز
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- عرض المراكز -->
    <h4 class="mb-4"><i class="bi bi-list-ul me-2 text-primary"></i> قائمة المراكز</h4>

    <?php if ($centers): ?>
        <div class="row g-4">
            <?php foreach ($centers as $center): ?>
                <div class="col-lg-6">
                    <div class="card center-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h5 class="card-title mb-1"><?= htmlspecialchars($center['name']) ?></h5>
                                    <p class="text-muted mb-0">
                                        <i class="bi bi-geo-alt me-1"></i> 
                                        <?= htmlspecialchars($center['city'] ?: 'غير محدد') ?>
                                        <?php if ($center['location']): ?>
                                            - <?= htmlspecialchars($center['location']) ?>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <span class="badge <?= $center['status'] === 'active' ? 'status-active' : 'status-inactive' ?>">
                                    <?= $center['status'] === 'active' ? 'نشط' : 'غير نشط' ?>
                                </span>
                            </div>
                            
                            <?php if ($center['description']): ?>
                                <p class="card-text mb-3"><?= htmlspecialchars(substr($center['description'], 0, 150)) ?><?= strlen($center['description']) > 150 ? '...' : '' ?></p>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <small class="text-muted">
                                    <i class="bi bi-calendar me-1"></i> <?= date('Y-m-d', strtotime($center['created_at'])) ?>
                                </small>
                                
                                <div class="d-flex gap-2">
                                    <!-- تبديل الحالة -->
                                    <div class="toggle-switch me-2">
                                        <input type="checkbox" class="toggle-center" 
                                               <?= $center['status'] === 'active' ? 'checked' : '' ?>
                                               data-id="<?= $center['id'] ?>">
                                        <span class="slider"></span>
                                    </div>
                                    
                                    <!-- أزرار الإجراءات -->
                                    <a href="edit_center.php?id=<?= $center['id'] ?>" class="btn btn-icon btn-outline-warning" title="تعديل">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="delete_center.php?id=<?= $center['id'] ?>" class="btn btn-icon btn-outline-danger" title="حذف" onclick="return confirm('هل أنت متأكد من حذف هذا المركز؟')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-building fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد مراكز تطوعية حتى الآن</h4>
            <p class="text-muted">يمكنك إضافة مركز تطوعي جديد من النموذج أعلاه.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // تبديل حالة المركز
    const toggleSwitches = document.querySelectorAll('.toggle-center');
    toggleSwitches.forEach(switchEl => {
        switchEl.addEventListener('change', function() {
            const centerId = this.getAttribute('data-id');
            const isChecked = this.checked;
            const currentStatus = isChecked ? 'inactive' : 'active';

            fetch('centers.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'ajax=toggle_status&id=' + centerId + '&current_status=' + currentStatus
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const badge = this.closest('.center-card').querySelector('.badge');
                    if (data.new_status === 'active') {
                        badge.textContent = 'نشط';
                        badge.className = 'badge status-active';
                    } else {
                        badge.textContent = 'غير نشط';
                        badge.className = 'badge status-inactive';
                    }
                } else {
                    this.checked = !this.checked;
                    alert('فشل تغيير الحالة. الرجاء المحاولة مرة أخرى.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                this.checked = !this.checked;
                alert('حدث خطأ أثناء تغيير الحالة.');
            });
        });
    });
});
</script>
</body>
</html>

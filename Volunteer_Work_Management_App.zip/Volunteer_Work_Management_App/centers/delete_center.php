<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

// التحقق من وجود مُعرّف المركز
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: centers.php?error=معرف المركز غير صالح");
    exit();
}

$center_id = (int)$_GET['id'];

// جلب بيانات المركز للعرض
$stmt = $pdo->prepare("SELECT * FROM centers WHERE id = ?");
$stmt->execute([$center_id]);
$center = $stmt->fetch();

if (!$center) {
    header("Location: centers.php?error=المركز غير موجود");
    exit();
}

// التحقق مما إذا كان المركز مرتبطًا بفرص (لإظهار تحذير)
$has_opportunities = $pdo->prepare("SELECT COUNT(*) FROM volunteer_opportunities WHERE center_id = ?");
$has_opportunities->execute([$center_id]);
$opportunities_count = $has_opportunities->fetchColumn();

$has_trainings = $pdo->prepare("SELECT COUNT(*) FROM training_opportunities WHERE center_id = ?");
$has_trainings->execute([$center_id]);
$trainings_count = $has_trainings->fetchColumn();

$linked_count = $opportunities_count + $trainings_count;

// معالجة تأكيد الحذف
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    try {
        // سيتم حذف الفرص المرتبطة تلقائيًا بسبب ON DELETE SET NULL
        // لكننا نحافظ على السجلات المرتبطة (فرص التطوع/التدريب) مع جعل center_id = NULL
        $stmt = $pdo->prepare("DELETE FROM centers WHERE id = ?");
        $stmt->execute([$center_id]);
        
        header("Location: centers.php?success=تم حذف المركز بنجاح!");
        exit();
    } catch (Exception $e) {
        $error = "حدث خطأ أثناء حذف المركز: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حذف مركز تطوعي - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --danger: #dc3545;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .delete-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            border-top: 4px solid var(--danger);
        }
        
        .warning-box {
            background-color: rgba(220, 53, 69, 0.1);
            border: 1px solid var(--danger);
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
        }
        
        .btn-danger {
            background-color: var(--danger);
            border-color: var(--danger);
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <i class="bi bi-heart-pulse me-2 text-primary"></i>
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="centers.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للمراكز
            </a>
            <a href="../logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-danger fw-bold">
            <i class="bi bi-trash me-2"></i> تأكيد حذف مركز
        </h2>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="delete-card">
        <div class="text-center mb-4">
            <div class="bg-danger bg-opacity-10 d-inline-flex p-3 rounded-circle mb-3">
                <i class="bi bi-exclamation-triangle fs-1 text-danger"></i>
            </div>
            <h4 class="text-danger">هل أنت متأكد من حذف هذا المركز؟</h4>
            <p class="text-muted">هذا الإجراء لا يمكن التراجع عنه.</p>
        </div>

        <!-- معلومات المركز -->
        <div class="row mb-4">
            <div class="col-md-6">
                <h5>معلومات المركز</h5>
                <ul class="list-unstyled">
                    <li><strong>الاسم:</strong> <?= htmlspecialchars($center['name']) ?></li>
                    <li><strong>الموقع:</strong> <?= htmlspecialchars($center['location'] ?: 'غير محدد') ?></li>
                    <li><strong>الحالة:</strong> 
                        <span class="badge <?= $center['status'] === 'active' ? 'bg-success' : 'bg-secondary' ?>">
                            <?= $center['status'] === 'active' ? 'نشط' : 'غير نشط' ?>
                        </span>
                    </li>
                    <li><strong>تاريخ الإنشاء:</strong> <?= date('Y-m-d', strtotime($center['created_at'])) ?></li>
                </ul>
            </div>
            
            <?php if ($linked_count > 0): ?>
            <div class="col-md-6">
                <div class="warning-box">
                    <h5 class="text-danger"><i class="bi bi-link-45deg me-2"></i> تحذير: محتوى مرتبط</h5>
                    <p>هذا المركز مرتبط بالعناصر التالية:</p>
                    <ul class="mb-0">
                        <?php if ($opportunities_count > 0): ?>
                            <li><?= $opportunities_count ?> فرصة تطوع</li>
                        <?php endif; ?>
                        <?php if ($trainings_count > 0): ?>
                            <li><?= $trainings_count ?> فرصة تدريب</li>
                        <?php endif; ?>
                    </ul>
                    <p class="mt-2 mb-0">
                        <small class="text-muted">
                            سيتم فصل هذه العناصر عن المركز (center_id = NULL) ولكنها لن تحذف.
                        </small>
                    </p>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- نموذج التأكيد -->
        <form method="POST" class="text-center">
            <div class="d-flex justify-content-center gap-3">
                <button type="submit" name="confirm_delete" class="btn btn-danger btn-lg">
                    <i class="bi bi-trash me-2"></i> نعم، احذف المركز
                </button>
                <a href="centers.php" class="btn btn-secondary btn-lg">
                    <i class="bi bi-x me-2"></i> إلغاء
                </a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
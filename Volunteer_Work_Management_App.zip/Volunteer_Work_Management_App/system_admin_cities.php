<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

// فقط مدير النظام يمكنه الدخول
requireRole('system_admin');

$error = '';
$success = '';

// معالجة إضافة مدينة جديدة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_city'])) {
    $city_name = trim($_POST['city_name'] ?? '');
    
    if (empty($city_name)) {
        $error = "يرجى إدخال اسم المدينة.";
    } else {
        // التحقق من عدم وجود المدينة مسبقًا
        $stmt = $pdo->prepare("SELECT id FROM cities WHERE name = ?");
        $stmt->execute([$city_name]);
        if ($stmt->fetch()) {
            $error = "المدينة موجودة مسبقًا.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO cities (name) VALUES (?)");
            $stmt->execute([$city_name]);
            $success = "تم إضافة المدينة بنجاح!";
            header("Location: system_admin_cities.php?success=" . urlencode($success));
            exit();
        }
    }
}

// معالجة تعديل مدينة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_city'])) {
    $city_id = (int)$_POST['city_id'];
    $city_name = trim($_POST['city_name'] ?? '');
    
    if (empty($city_name)) {
        $error = "يرجى إدخال اسم المدينة.";
    } else {
        // التحقق من عدم وجود المدينة مسبقًا (باستثناء المدينة الحالية)
        $stmt = $pdo->prepare("SELECT id FROM cities WHERE name = ? AND id != ?");
        $stmt->execute([$city_name, $city_id]);
        if ($stmt->fetch()) {
            $error = "المدينة موجودة مسبقًا.";
        } else {
            $stmt = $pdo->prepare("UPDATE cities SET name = ? WHERE id = ?");
            $stmt->execute([$city_name, $city_id]);
            $success = "تم تحديث المدينة بنجاح!";
            header("Location: system_admin_cities.php?success=" . urlencode($success));
            exit();
        }
    }
}

// معالجة حذف مدينة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_city'])) {
    $city_id = (int)$_POST['city_id'];
    
    // التحقق من عدم ارتباط المدينة بمراكز تطوعية
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM centers WHERE city = (SELECT name FROM cities WHERE id = ?)");
    $stmt->execute([$city_id]);
    $linked_centers = $stmt->fetchColumn();
    
    if ($linked_centers > 0) {
        $error = "لا يمكن حذف المدينة لأنها مرتبطة بـ {$linked_centers} مركز تطوعي.";
    } else {
        $stmt = $pdo->prepare("DELETE FROM cities WHERE id = ?");
        $stmt->execute([$city_id]);
        $success = "تم حذف المدينة بنجاح!";
        header("Location: system_admin_cities.php?success=" . urlencode($success));
        exit();
    }
}

// جلب جميع المدن
$cities = $pdo->query("SELECT * FROM cities ORDER BY name ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المدن - مدير النظام</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --sidebar-width: 280px;
            --sidebar-collapsed-width: 80px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        /* الشريط الجانبي */
        .admin-sidebar {
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            right: 0;
            width: var(--sidebar-width);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: -5px 0 15px rgba(0,0,0,0.1);
        }
        
        .admin-sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .sidebar-logo {
            font-weight: 700;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-logo i {
            color: var(--accent);
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }
        
        .toggle-sidebar:hover {
            background: rgba(255,255,255,0.1);
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-title {
            padding: 15px 25px 10px;
            font-size: 0.8rem;
            text-transform: uppercase;
            color: #adb5bd;
            font-weight: 600;
            letter-spacing: 1px;
        }
        
        .sidebar-menu a {
            color: #adb5bd;
            text-decoration: none;
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s;
            margin: 0 10px 4px;
            border-radius: 8px;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar-menu a i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-menu a span {
            transition: opacity 0.3s;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a span,
        .admin-sidebar.collapsed .menu-title,
        .admin-sidebar.collapsed .sidebar-logo span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            margin: 0;
        }
        
        .admin-sidebar.collapsed .sidebar-logo {
            justify-content: center;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a {
            justify-content: center;
            padding: 15px;
        }
        
        /* المحتوى الرئيسي */
        .admin-main {
            margin-right: var(--sidebar-width);
            padding: 20px;
            transition: margin-right 0.3s ease;
        }
        
        .admin-main.sidebar-collapsed {
            margin-right: var(--sidebar-collapsed-width);
        }
        
        /* الشريط العلوي */
        .admin-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 15px 25px;
            margin-bottom: 25px;
            border-radius: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title h1 {
            color: var(--primary);
            font-weight: 700;
            margin: 0;
            font-size: 1.8rem;
        }
        
        .page-title p {
            color: #6c757d;
            margin: 5px 0 0;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .user-info {
            text-align: right;
        }
        
        .user-info .username {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 2px;
        }
        
        .user-info .role {
            font-size: 0.85rem;
            color: #6c757d;
        }
        
        /* بطاقات المدن */
        .city-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
            border: none;
            background: white;
        }
        
        .city-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .city-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 20px;
            text-align: center;
        }
        
        .city-name {
            font-weight: 700;
            font-size: 1.3rem;
            margin: 0;
        }
        
        .city-body {
            padding: 20px;
        }
        
        .city-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .city-stats {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .btn-icon {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            font-size: 0.9rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        
        .form-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .modal-content {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        
        .modal-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border-radius: 15px 15px 0 0 !important;
        }
        
        /* التصميم المتجاوب */
        @media (max-width: 992px) {
            .admin-sidebar {
                transform: translateX(0);
                width: 280px;
            }
            
            .admin-sidebar.collapsed {
                transform: translateX(280px);
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-main.sidebar-collapsed {
                margin-right: 0;
            }
        }
        
        @media (max-width: 768px) {
            .admin-navbar {
                padding: 15px;
            }
            
            .page-title h1 {
                font-size: 1.5rem;
            }
            
            .user-profile {
                gap: 10px;
            }
            
            .avatar {
                width: 40px;
                height: 40px;
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

<!-- الشريط الجانبي -->
<div class="admin-sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <i class="bi bi-heart-pulse"></i>
            <span>نظام التطوع</span>
        </div>
        <button class="toggle-sidebar" id="toggleSidebar">
            <i class="bi bi-list"></i>
        </button>
    </div>
    
    <div class="sidebar-menu">
        <a href="system_admin_dashboard.php">
            <i class="bi bi-speedometer2"></i>
            <span>لوحة التحكم</span>
        </a>
        
        <div class="menu-title">الحساب</div>
        <a href="system_admin_profile.php">
            <i class="bi bi-person"></i>
            <span>ملفي الشخصي</span>
        </a>
        
        <div class="menu-title">إدارة الحسابات</div>
        <a href="system_admin_organizations.php">
            <i class="bi bi-building"></i>
            <span>مدراء المنظمات</span>
        </a>
        <a href="system_admin_volunteers.php">
            <i class="bi bi-people"></i>
            <span>المتطوعون</span>
        </a>
        
        <div class="menu-title">إدارة المحتوى</div>
        <a href="system_admin_cities.php" class="active">
            <i class="bi bi-geo-alt"></i>
            <span>المدن</span>
        </a>
        <a href="system_admin_centers.php">
            <i class="bi bi-building"></i>
            <span>المراكز التطوعية</span>
        </a>
        <a href="system_admin_citizens.php">
            <i class="bi bi-person-lines-fill"></i>
            <span>المواطنين</span>
        </a>
        
        <div class="menu-title">التحليلات</div>
        <a href="system_admin_reports.php">
            <i class="bi bi-bar-chart-line"></i>
            <span>التقارير</span>
        </a>
        <a href="system_admin_reviews.php">
            <i class="bi bi-star"></i>
            <span>التقييمات</span>
        </a>
    </div>
</div>

<!-- المحتوى الرئيسي -->
<div class="admin-main" id="mainContent">
    <!-- الشريط العلوي -->
    <div class="admin-navbar">
        <div class="page-title">
            <h1>إدارة المدن</h1>
            <p>إدارة المدن المدعومة في النظام</p>
        </div>
        
        <div class="user-profile">
            
            <div class="user-info">
               
            </div>
            <a href="logout.php" class="btn btn-outline-danger ms-3">
                <i class="bi bi-box-arrow-right"></i>
            </a>
        </div>
    </div>
    
    <!-- رسائل النجاح والخطأ -->
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- قسم إضافة مدينة جديدة -->
    <div class="form-section">
        <h4 class="mb-4">
            <i class="bi bi-plus-circle me-2 text-primary"></i>
            إضافة مدينة جديدة
        </h4>
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">اسم المدينة <span class="text-danger">*</span></label>
                    <input type="text" name="city_name" class="form-control" required placeholder="أدخل اسم المدينة">
                </div>
                <div class="col-md-4">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" name="add_city" class="btn btn-primary w-100">
                        <i class="bi bi-save me-2"></i> إضافة المدينة
                    </button>
                </div>
            </div>
        </form>
    </div>
    
    <!-- ملخص الإحصائيات -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card border-left-primary shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-primary font-weight-bold">إجمالي المدن المدعومة</h6>
                            <div class="h5 font-weight-bold"><?= count($cities) ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-geo-alt text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- قائمة المدن -->
    <h4 class="mb-4">
        <i class="bi bi-list-ul me-2 text-primary"></i>
        قائمة المدن
    </h4>
    
    <?php if ($cities): ?>
        <div class="row g-4">
            <?php foreach ($cities as $city): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card city-card h-100">
                        <div class="city-header">
                            <h3 class="city-name">
                                <i class="bi bi-geo-alt me-2"></i>
                                <?= htmlspecialchars($city['name']) ?>
                            </h3>
                        </div>
                        <div class="city-body">
                            <div class="city-info">
                                <div class="city-stats">
                                    <small class="text-muted">
                                        <i class="bi bi-calendar me-1"></i>
                                        <?= date('Y-m-d', strtotime($city['created_at'])) ?>
                                    </small>
                                </div>
                                <div class="d-flex gap-2">
                                    <!-- زر التعديل -->
                                    <button class="btn btn-icon btn-outline-warning" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editCityModal" 
                                            data-city-id="<?= $city['id'] ?>" 
                                            data-city-name="<?= htmlspecialchars($city['name']) ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    
                                    <!-- زر الحذف -->
                                    <form method="POST" class="d-inline" onsubmit="return confirm('هل أنت متأكد من حذف هذه المدينة؟')">
                                        <input type="hidden" name="city_id" value="<?= $city['id'] ?>">
                                        <button type="submit" name="delete_city" class="btn btn-icon btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-geo-alt fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد مدن مسجلة</h4>
            <p class="text-muted">يمكنك إضافة مدن جديدة من النموذج أعلاه.</p>
        </div>
    <?php endif; ?>
</div>

<!-- نافذة تعديل المدينة -->
<div class="modal fade" id="editCityModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-pencil-square me-2"></i>
                    تعديل المدينة
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="city_id" id="editCityId">
                    <div class="mb-3">
                        <label class="form-label">اسم المدينة <span class="text-danger">*</span></label>
                        <input type="text" name="city_name" id="editCityName" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x me-1"></i> إلغاء
                    </button>
                    <button type="submit" name="edit_city" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> تحديث المدينة
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// تبديل الشريط الجانبي
document.getElementById('toggleSidebar').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('sidebar-collapsed');
});

// تعبئة نافذة التعديل
const editCityModal = document.getElementById('editCityModal');
editCityModal.addEventListener('show.bs.modal', function (event) {
    const button = event.relatedTarget;
    const cityId = button.getAttribute('data-city-id');
    const cityName = button.getAttribute('data-city-name');
    
    const cityIdInput = editCityModal.querySelector('#editCityId');
    const cityNameInput = editCityModal.querySelector('#editCityName');
    
    cityIdInput.value = cityId;
    cityNameInput.value = cityName;
});
</script>
</body>
</html>

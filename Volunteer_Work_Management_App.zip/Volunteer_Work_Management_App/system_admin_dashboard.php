<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';


requireRole('system_admin');


$stats = [
    'org_admins' => $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'org_admin' AND status = 'active'")->fetchColumn(),
    'volunteers' => $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'volunteer' AND status = 'active'")->fetchColumn(),
    'centers' => $pdo->query("SELECT COUNT(*) FROM centers WHERE status = 'active'")->fetchColumn(),
    'cities' => $pdo->query("SELECT COUNT(*) FROM cities")->fetchColumn(),
    'opportunities' => $pdo->query("SELECT COUNT(*) FROM volunteer_opportunities WHERE status = 'open'")->fetchColumn(),
    'training_opportunities' => $pdo->query("SELECT COUNT(*) FROM training_opportunities WHERE status = 'open'")->fetchColumn(),
    'services' => $pdo->query("SELECT COUNT(*) FROM services WHERE status = 'active'")->fetchColumn(),
    'help_requests' => $pdo->query("SELECT COUNT(*) FROM help_requests WHERE status = 'accepted'")->fetchColumn(),
];
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم مدير النظام - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --sidebar-width: 280px;
            --sidebar-collapsed-width: 80px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        
        .admin-sidebar {
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            right: 0;
            width: var(--sidebar-width);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: -5px 0 15px rgba(0,0,0,0.1);
        }
        
        .admin-sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .sidebar-logo {
            font-weight: 700;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-logo i {
            color: var(--accent);
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }
        
        .toggle-sidebar:hover {
            background: rgba(255,255,255,0.1);
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-title {
            padding: 15px 25px 10px;
            font-size: 0.8rem;
            text-transform: uppercase;
            color: #adb5bd;
            font-weight: 600;
            letter-spacing: 1px;
        }
        
        .sidebar-menu a {
            color: #adb5bd;
            text-decoration: none;
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s;
            margin: 0 10px 4px;
            border-radius: 8px;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar-menu a i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-menu a span {
            transition: opacity 0.3s;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a span,
        .admin-sidebar.collapsed .menu-title,
        .admin-sidebar.collapsed .sidebar-logo span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            margin: 0;
        }
        
        .admin-sidebar.collapsed .sidebar-logo {
            justify-content: center;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a {
            justify-content: center;
            padding: 15px;
        }
        
        
        .admin-main {
            margin-right: var(--sidebar-width);
            padding: 20px;
            transition: margin-right 0.3s ease;
        }
        
        .admin-main.sidebar-collapsed {
            margin-right: var(--sidebar-collapsed-width);
        }
        
        
        .admin-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 15px 25px;
            margin-bottom: 25px;
            border-radius: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title h1 {
            color: var(--primary);
            font-weight: 700;
            margin: 0;
            font-size: 1.8rem;
        }
        
        .page-title p {
            color: #6c757d;
            margin: 5px 0 0;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .user-info {
            text-align: right;
        }
        
        .user-info .username {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 2px;
        }
        
        .user-info .role {
            font-size: 0.85rem;
            color: #6c757d;
        }
        
        .dropdown-menu {
            min-width: 200px;
        }
        
        
        .stat-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            height: 100%;
            border: none;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-bottom: 15px;
        }
        
        .bg-primary-light { background-color: rgba(44, 90, 160, 0.15); color: var(--primary); }
        .bg-success-light { background-color: rgba(40, 167, 69, 0.15); color: var(--secondary); }
        .bg-warning-light { background-color: rgba(255, 107, 53, 0.15); color: var(--accent); }
        .bg-info-light { background-color: rgba(23, 162, 184, 0.15); color: #17a2b8; }
        .bg-danger-light { background-color: rgba(220, 53, 69, 0.15); color: #dc3545; }
        .bg-purple-light { background-color: rgba(108, 117, 125, 0.15); color: #6c757d; }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
        }
        
       
        @media (max-width: 992px) {
            .admin-sidebar {
                transform: translateX(0);
                width: 280px;
            }
            
            .admin-sidebar.collapsed {
                transform: translateX(280px);
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-main.sidebar-collapsed {
                margin-right: 0;
            }
        }
        
        @media (max-width: 768px) {
            .admin-navbar {
                padding: 15px;
            }
            
            .page-title h1 {
                font-size: 1.5rem;
            }
            
            .user-profile {
                gap: 10px;
            }
            
            .avatar {
                width: 40px;
                height: 40px;
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>


<div class="admin-sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
           
            <span>نظام التطوع</span>
        </div>
        <button class="toggle-sidebar" id="toggleSidebar">
            <i class="bi bi-list"></i>
        </button>
    </div>
    
    <div class="sidebar-menu">
        <a href="system_admin_dashboard.php" class="active">
            <i class="bi bi-speedometer2"></i>
            <span>لوحة التحكم</span>
        </a>
        
<div class="menu-title">الفرص التطوعية</div>
        <a href="system_admin_volunteer_opportunities.php">
            <i class=" bi bi-unlock"> </i>
            <span>الفرص التطوعية </span>
        </a>

        <div class="menu-title">الحساب</div>
        <a href="system_admin_profile.php">
            <i class="bi bi-person"></i>
            <span>ملفي الشخصي</span>
        </a>
        
        <div class="menu-title">إدارة الحسابات</div>
        <a href="system_admin_organizations.php">
            <i class="bi bi-building"></i>
            <span>مدراء المنظمات</span>
        </a>
        <a href="system_admin_volunteers.php">
            <i class="bi bi-people"></i>
            <span>المتطوعون</span>
        </a>
        
        <div class="menu-title">إدارة المحتوى</div>
        <a href="system_admin_cities.php">
            <i class="bi bi-geo-alt"></i>
            <span>المدن</span>
        </a>
        <a href="system_admin_centers.php">
            <i class="bi bi-building"></i>
            <span>المراكز التطوعية</span>
        </a>
        <a href="system_admin_citizens.php">
            <i class="bi bi-person-lines-fill"></i>
            <span>المواطنين</span>
        </a>
        
        <div class="menu-title">التحليلات</div>
        <a href="system_admin_reports.php">
            <i class="bi bi-bar-chart-line"></i>
            <span>التقارير</span>
        </a>
        <a href="system_admin_reviews.php">
            <i class="bi bi-star"></i>
            <span>التقييمات</span>
        </a>
    </div>
</div>


<div class="admin-main" id="mainContent">
    
    <div class="admin-navbar">
        <div class="page-title">
            <h1>لوحة تحكم مدير النظام</h1>
            <p>نظرة عامة على أداء النظام والمنظمات التطوعية</p>
        </div>
        
        <div class="user-profile dropdown">
            
            <div class="user-info">
                <div class="username"><?= htmlspecialchars($_SESSION['user_name']) ?></div>
    
            </div>
            <a href="logout.php" class="btn btn-outline-danger ms-3">
                <i class="bi bi-box-arrow-right"></i>
            </a>
        </div>
    </div>
    
    
    <div class="row g-4 mb-5">
        <div class="col-md-6 col-lg-3">
            <div class="card stat-card">
                <div class="card-body text-center">
                    <div class="stat-icon bg-primary-light">
                        <i class="bi bi-building"></i>
                    </div>
                    <h5 class="card-title">مدراء المنظمات</h5>
                    <div class="stat-number"><?= $stats['org_admins'] ?></div>
                    <small class="text-muted">حسابات نشطة</small>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3">
            <div class="card stat-card">
                <div class="card-body text-center">
                    <div class="stat-icon bg-success-light">
                        <i class="bi bi-people"></i>
                    </div>
                    <h5 class="card-title">المتطوعون</h5>
                    <div class="stat-number"><?= $stats['volunteers'] ?></div>
                    <small class="text-muted">مستخدم فريد</small>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3">
            <div class="card stat-card">
                <div class="card-body text-center">
                    <div class="stat-icon bg-warning-light">
                        <i class="bi bi-geo-alt"></i>
                    </div>
                    <h5 class="card-title">المراكز</h5>
                    <div class="stat-number"><?= $stats['centers'] ?></div>
                    <small class="text-muted">مرفق تطوعي</small>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3">
            <div class="card stat-card">
                <div class="card-body text-center">
                    <div class="stat-icon bg-info-light">
                        <i class="bi bi-geo"></i>
                    </div>
                    <h5 class="card-title">المدن</h5>
                    <div class="stat-number"><?= $stats['cities'] ?></div>
                    <small class="text-muted">مدينة مدعومة</small>
                </div>
            </div>
        </div>
        
    
    </div>

    
    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">ملخص أداء النظام</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6>النشاط اليومي</h6>
                    <div class="progress mb-3" style="height: 8px;">
                        <div class="progress-bar bg-success" style="width: 75%"></div>
                    </div>
                    <p class="text-muted small">75% من المنظمات نشطة هذا الأسبوع</p>
                </div>
                <div class="col-md-6">
                    <h6>رضا المستخدمين</h6>
                    <div class="progress mb-3" style="height: 8px;">
                        <div class="progress-bar bg-primary" style="width: 88%"></div>
                    </div>
                    <p class="text-muted small">88% تقييم إيجابي من المتطوعين</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.getElementById('toggleSidebar').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('sidebar-collapsed');
});
</script>
</body>
</html>

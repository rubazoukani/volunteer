<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';


requireRole('system_admin');


$stmt = $pdo->prepare("SELECT * FROM reviews ORDER BY created_at DESC");
$stmt->execute();
$reviews = $stmt->fetchAll();


$total_reviews = count($reviews);


$avg_rating = number_format($pdo->query("SELECT AVG(rating) FROM reviews")->fetchColumn(), 2);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التقييمات - مدير النظام</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --sidebar-width: 280px;
            --sidebar-collapsed-width: 80px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
       
        .admin-sidebar {
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            right: 0;
            width: var(--sidebar-width);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: -5px 0 15px rgba(0,0,0,0.1);
        }
        
        .admin-sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .sidebar-logo {
            font-weight: 700;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-logo i {
            color: var(--accent);
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }
        
        .toggle-sidebar:hover {
            background: rgba(255,255,255,0.1);
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-title {
            padding: 15px 25px 10px;
            font-size: 0.8rem;
            text-transform: uppercase;
            color: #adb5bd;
            font-weight: 600;
            letter-spacing: 1px;
        }
        
        .sidebar-menu a {
            color: #adb5bd;
            text-decoration: none;
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s;
            margin: 0 10px 4px;
            border-radius: 8px;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar-menu a i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-menu a span {
            transition: opacity 0.3s;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a span,
        .admin-sidebar.collapsed .menu-title,
        .admin-sidebar.collapsed .sidebar-logo span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            margin: 0;
        }
        
        .admin-sidebar.collapsed .sidebar-logo {
            justify-content: center;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a {
            justify-content: center;
            padding: 15px;
        }
        
       
        .admin-main {
            margin-right: var(--sidebar-width);
            padding: 20px;
            transition: margin-right 0.3s ease;
        }
        
        .admin-main.sidebar-collapsed {
            margin-right: var(--sidebar-collapsed-width);
        }
        
        
        .admin-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 15px 25px;
            margin-bottom: 25px;
            border-radius: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title h1 {
            color: var(--primary);
            font-weight: 700;
            margin: 0;
            font-size: 1.8rem;
        }
        
        .page-title p {
            color: #6c757d;
            margin: 5px 0 0;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .user-info {
            text-align: right;
        }
        
        .user-info .username {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 2px;
        }
        
        .user-info .role {
            font-size: 0.85rem;
            color: #6c757d;
        }
        
        
        .review-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
            border: none;
            background: white;
        }
        
        .review-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .review-header {
            padding: 20px;
            background: linear-gradient(135deg, var(--accent), #e55a2b);
            color: white;
        }
        
        .review-name {
            font-weight: 700;
            font-size: 1.2rem;
            margin: 0 0 10px 0;
        }
        
        .review-type {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.85rem;
        }
        
        .review-body {
            padding: 20px;
        }
        
        .review-text {
            color: #495057;
            line-height: 1.6;
            margin-bottom: 15px;
            font-style: italic;
        }
        
        .review-rating {
            color: #ffc107;
            font-size: 1.3rem;
            margin-bottom: 15px;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        
        
        @media (max-width: 992px) {
            .admin-sidebar {
                transform: translateX(0);
                width: 280px;
            }
            
            .admin-sidebar.collapsed {
                transform: translateX(280px);
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-main.sidebar-collapsed {
                margin-right: 0;
            }
        }
        
        @media (max-width: 768px) {
            .admin-navbar {
                padding: 15px;
            }
            
            .page-title h1 {
                font-size: 1.5rem;
            }
            
            .user-profile {
                gap: 10px;
            }
            
            .avatar {
                width: 40px;
                height: 40px;
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>


<div class="admin-sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <span>نظام التطوع</span>
        </div>
        <button class="toggle-sidebar" id="toggleSidebar">
            <i class="bi bi-list"></i>
        </button>
    </div>
    
    <div class="sidebar-menu">
        <a href="system_admin_dashboard.php">
            <i class="bi bi-speedometer2"></i>
            <span>لوحة التحكم</span>
        </a>
        
        <div class="menu-title">الحساب</div>
        <a href="system_admin_profile.php">
            <i class="bi bi-person"></i>
            <span>ملفي الشخصي</span>
        </a>
        
        <div class="menu-title">إدارة الحسابات</div>
        <a href="system_admin_organizations.php">
            <i class="bi bi-building"></i>
            <span>مدراء المنظمات</span>
        </a>
        <a href="system_admin_volunteers.php">
            <i class="bi bi-people"></i>
            <span>المتطوعون</span>
        </a>
        
        <div class="menu-title">إدارة المحتوى</div>
        <a href="system_admin_cities.php">
            <i class="bi bi-geo-alt"></i>
            <span>المدن</span>
        </a>
        <a href="system_admin_centers.php">
            <i class="bi bi-building"></i>
            <span>المراكز التطوعية</span>
        </a>
        <a href="system_admin_citizens.php">
            <i class="bi bi-person-lines-fill"></i>
            <span>المواطنين</span>
        </a>
        
        <div class="menu-title">التحليلات</div>
        <a href="system_admin_reports.php">
            <i class="bi bi-bar-chart-line"></i>
            <span>التقارير</span>
        </a>
        <a href="system_admin_reviews.php" class="active">
            <i class="bi bi-star"></i>
            <span>التقييمات</span>
        </a>
    </div>
</div>


<div class="admin-main" id="mainContent">
    
    <div class="admin-navbar">
        <div class="page-title">
            <h1>التقييمات</h1>
            <p>عرض جميع التقييمات الواردة من المستخدمين</p>
        </div>
        
        
    </div>
    
    
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card border-left-primary shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-primary font-weight-bold">إجمالي التقييمات</h6>
                            <div class="h5 font-weight-bold"><?= $total_reviews ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-star text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">متوسط التقييم</h5>
                    <div class="review-rating">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="bi <?= $i <= $avg_rating ? 'bi-star-fill' : 'bi-star' ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <h2 class="stat-number"><?= $avg_rating ?>/5</h2>
                </div>
            </div>
        </div>
    </div>
    
    
    <h4 class="mb-4">
        <i class="bi bi-list-ul me-2 text-primary"></i>
        قائمة التقييمات
    </h4>
    
    <?php if ($reviews): ?>
        <div class="row g-4">
            <?php foreach ($reviews as $review): ?>
                <div class="col-lg-6">
                    <div class="card review-card h-100">
                        <div class="review-header">
                            <h3 class="review-name"><?= htmlspecialchars($review['reviewer_name']) ?></h3>
                            <div class="review-type">
                                <i class="bi bi-person me-1"></i>
                                <?php 
                                if ($review['reviewer_type'] === 'volunteer') echo 'متطوع';
                                elseif ($review['reviewer_type'] === 'citizen') echo 'مواطن';
                                else echo 'مدير منظمة';
                                ?>
                            </div>
                        </div>
                        <div class="review-body">
                            <p class="review-text">
                                "<?= htmlspecialchars($review['review_text']) ?>"
                            </p>
                            
                            <div class="review-rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="bi <?= $i <= $review['rating'] ? 'bi-star-fill' : 'bi-star' ?>"></i>
                                <?php endfor; ?>
                                <small class="text-muted me-3">(<?= $review['rating'] ?>/5)</small>
                            </div>
                            
                            <?php if ($review['reviewer_email']): ?>
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <i class="bi bi-envelope me-1"></i>
                                        <?= htmlspecialchars($review['reviewer_email']) ?>
                                    </small>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <small class="text-muted">
                                    <i class="bi bi-clock me-1"></i>
                                    <?= date('Y-m-d', strtotime($review['created_at'])) ?>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-star fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد تقييمات</h4>
            <p class="text-muted">لم يتم استلام أي تقييمات من المستخدمين حتى الآن.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.getElementById('toggleSidebar').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('sidebar-collapsed');
});
</script>
</body>
</html>

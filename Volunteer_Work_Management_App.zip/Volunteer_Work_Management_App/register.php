<?php
session_start();
require_once 'config/db.php';

// التحقق من أن المستخدم ليس مسجلًا بالفعل
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? '';
    $organization_name = trim($_POST['organization_name'] ?? '');

    // التحقق من الحقول المطلوبة
    if (empty($name) || empty($email) || empty($password) || empty($role)) {
        $error = "يرجى ملء جميع الحقول المطلوبة.";
    } elseif ($password !== $confirm_password) {
        $error = "كلمة المرور وتأكيد كلمة المرور غير متطابقين.";
    } elseif (strlen($password) < 6) {
        $error = "يجب أن تكون كلمة المرور على الأقل 6 أحرف.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "البريد الإلكتروني غير صحيح.";
    } elseif ($role === 'org_admin' && empty($organization_name)) {
        $error = "يرجى إدخال اسم المنظمة.";
    } else {
        // التحقق من عدم وجود بريد إلكتروني مسجل مسبقًا
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "البريد الإلكتروني مسجل مسبقًا.";
        } else {
            // تجزئة كلمة المرور
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // إدراج المستخدم
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, organization_name) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $email, $hashed_password, $role, $role === 'org_admin' ? $organization_name : null]);
            
            $success = "تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء حساب - نظام إدارة العمل التطوعي</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4edf9 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .register-container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
        }
        
        .register-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .register-header h2 {
            color: var(--primary);
            font-weight: 700;
        }
        
        .role-selector {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        .role-card {
            flex: 1;
            min-width: 200px;
            padding: 1.5rem;
            border: 2px solid #e9ecef;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .role-card:hover,
        .role-card.selected {
            border-color: var(--primary);
            background-color: rgba(44, 90, 160, 0.05);
        }
        
        .role-card i {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 12px;
            font-weight: 600;
            border-radius: 30px;
        }
        
        .btn-primary:hover {
            background-color: #1e4a8a;
            border-color: #1e4a8a;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-header">
            <h2><i class="bi bi-person-plus me-2"></i> إنشاء حساب جديد</h2>
            <p class="text-muted">اختر نوع الحساب الذي يناسبك</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <form method="POST" id="registerForm">
            <div class="mb-3">
                <label for="name" class="form-label">الاسم الكامل</label>
                <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">البريد الإلكتروني</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">كلمة المرور</label>
                <input type="password" class="form-control" id="password" name="password" required minlength="6">
            </div>

            <div class="mb-3">
                <label for="confirm_password" class="form-label">تأكيد كلمة المرور</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
            </div>

            <!-- اختيار نوع الحساب -->
            <div class="mb-3">
                <label class="form-label">نوع الحساب</label>
                <div class="role-selector">
                    <div class="role-card" onclick="selectRole('org_admin')">
                        <i class="bi bi-building"></i>
                        <h5>مدير منظمة تطوعية</h5>
                        <p class="small text-muted">لإدارة منظمتك وفرص التطوع</p>
                        <input type="radio" name="role" value="org_admin" id="role_org" class="d-none" required>
                    </div>
                    <div class="role-card" onclick="selectRole('system_admin')">
                        <i class="bi bi-gear"></i>
                        <h5>مدير النظام</h5>
                        <p class="small text-muted">لإدارة النظام بالكامل</p>
                        <input type="radio" name="role" value="system_admin" id="role_sys" class="d-none" required>
                    </div>
                </div>
            </div>

            <!-- حقل اسم المنظمة (يظهر فقط عند اختيار مدير منظمة) -->
            <div class="mb-3 d-none" id="orgField">
                <label for="organization_name" class="form-label">اسم المنظمة التطوعية</label>
                <input type="text" class="form-control" id="organization_name" name="organization_name" value="<?= htmlspecialchars($_POST['organization_name'] ?? '') ?>">
            </div>

            <button type="submit" class="btn btn-primary w-100">إنشاء الحساب</button>

            <div class="text-center mt-3">
                <a href="index.php" class="text-decoration-none"><i class="bi bi-arrow-left me-1"></i> العودة للرئيسية</a> |
                <a href="login.php" class="text-decoration-none">لديك حساب؟ سجل الدخول</a>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function selectRole(role) {
            // إزالة التحديد من جميع البطاقات
            document.querySelectorAll('.role-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            // تحديد البطاقة المختارة
            document.querySelector(`[onclick="selectRole('${role}')"]`).classList.add('selected');
            
            // تفعيل الإدخال المخفي
            document.getElementById('role_' + (role === 'org_admin' ? 'org' : 'sys')).checked = true;
            
            // إظهار/إخفاء حقل المنظمة
            if (role === 'org_admin') {
                document.getElementById('orgField').classList.remove('d-none');
                document.getElementById('organization_name').required = true;
            } else {
                document.getElementById('orgField').classList.add('d-none');
                document.getElementById('organization_name').required = false;
            }
        }

        // إذا كان هناك قيمة محفوظة من POST
        document.addEventListener('DOMContentLoaded', () => {
            const role = '<?= $_POST['role'] ?? '' ?>';
            if (role) {
                selectRole(role);
            }
        });
    </script>
</body>
</html>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام إدارة العمل التطوعي - منصة التطوع الشاملة</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
        }
        
        .hero-section {
            background: linear-gradient(135deg, rgba(44, 90, 160, 0.9), rgba(40, 167, 69, 0.8)), url('https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 150px 0;
            text-align: center;
        }
        
        .section-title {
            position: relative;
            margin-bottom: 3rem;
            color: var(--primary);
            font-weight: 700;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            right: 0;
            width: 80px;
            height: 4px;
            background-color: var(--accent);
            border-radius: 2px;
        }
        
        .feature-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            height: 100%;
            overflow: hidden;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }
        
        .feature-icon {
            font-size: 3.5rem;
            margin-bottom: 1.5rem;
            display: block;
        }
        
        .stat-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: scale(1.05);
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 30px;
        }
        
        .btn-primary:hover {
            background-color: #1e4a8a;
            border-color: #1e4a8a;
        }
        
        .btn-accent {
            background-color: var(--accent);
            border-color: var(--accent);
            color: white;
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 30px;
        }
        
        .btn-accent:hover {
            background-color: #e55a2b;
            border-color: #e55a2b;
            color: white;
        }
        
        .impact-section {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 80px 0;
        }
        
        .testimonial-card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
            transition: transform 0.3s;
        }
        
        .testimonial-card:hover {
            transform: translateY(-5px);
        }
        
        .footer {
            background-color: var(--dark);
            color: white;
            padding: 60px 0 30px;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
        
        .nav-link {
            font-weight: 500;
        }
        
        .hero-badge {
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
            border-radius: 30px;
            padding: 8px 20px;
            font-size: 0.9rem;
            margin-bottom: 20px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <!-- شريط التنقل -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand text-primary" href="#">
                <i class="bi bi-heart-pulse me-2"></i>
                نظام التطوع
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#home">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#features">المميزات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#impact">الأثر المجتمعي</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#testimonials">آراء المستخدمين</a>
                    </li>
                    
                </ul>
                <div class="d-flex">
                    <a href="login.php" class="btn btn-outline-primary me-2">تسجيل الدخول</a>
                    <a href="register.php" class="btn btn-primary">انضم إلينا</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- قسم البطل -->
    <section id="home" class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto">
                    <span class="hero-badge">منصة التطوع الرقمية الأولى</span>
                    <h1 class="display-3 fw-bold mb-4">نحو مجتمع متطوع متكامل</h1>
                    <p class="lead mb-5">منصة شاملة تربط المتطوعين بالفرص التطوعية المناسبة، وتوفر أدوات متكاملة لإدارة العمل التطوعي بفعالية واحترافية</p>
                    <div class="d-flex justify-content-center gap-3 flex-wrap">
                        <a href="#features" class="btn btn-accent btn-lg">اكتشف المميزات</a>
                        <a href="register.php" class="btn btn-outline-light btn-lg">ابدأ رحلتك التطوعية</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- إحصائيات سريعة -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-3 col-6">
                    <div class="text-center">
                        <h2 class="text-primary fw-bold">1,250+</h2>
                        <p class="text-muted">متطوع نشط</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="text-center">
                        <h2 class="text-primary fw-bold">350+</h2>
                        <p class="text-muted">منظمة خيرية</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="text-center">
                        <h2 class="text-primary fw-bold">5,740+</h2>
                        <p class="text-muted">ساعة تطوعية</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="text-center">
                        <h2 class="text-primary fw-bold">42+</h2>
                        <p class="text-muted">مشروع مجتمعي</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- المميزات -->
    <section id="features" class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center mb-5">
                    <h2 class="section-title">لماذا تختار منصتنا؟</h2>
                    <p class="text-muted">نوفر حلولاً مبتكرة تجعل تجربة التطوع أسهل وأكثر تأثيراً</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4">
                    <div class="card feature-card h-100">
                        <div class="card-body text-center p-5">
                            <i class="bi bi-search-heart feature-icon text-primary"></i>
                            <h4 class="card-title mb-3">اكتشاف الفرص</h4>
                            <p class="card-text">ابحث عن فرص التطوع التي تناسب مهاراتك واهتماماتك بسهولة باستخدام نظام التصفية المتقدم</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card feature-card h-100">
                        <div class="card-body text-center p-5">
                            <i class="bi bi-clock-history feature-icon text-primary"></i>
                            <h4 class="card-title mb-3">تتبع الساعات</h4>
                            <p class="card-text">سجل وتتبع ساعاتك التطوعية بكل دقة واحصل على شهادات معتمدة تثبت مشاركاتك</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card feature-card h-100">
                        <div class="card-body text-center p-5">
                            <i class="bi bi-graph-up-arrow feature-icon text-primary"></i>
                            <h4 class="card-title mb-3">تحليل الأداء</h4>
                            <p class="card-text">احصل على تقارير مفصلة وتحليلات ذكية تساعدك في قياس تأثيرك وتطوير أدائك التطوعي</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card feature-card h-100">
                        <div class="card-body text-center p-5">
                            <i class="bi bi-people feature-icon text-primary"></i>
                            <h4 class="card-title mb-3">إدارة الفرق</h4>
                            <p class="card-text">أنشئ فرق تطوعية وادر أعضاءها بفعالية من خلال أدوات التنسيق والتواصل المتكاملة</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card feature-card h-100">
                        <div class="card-body text-center p-5">
                            <i class="bi bi-award feature-icon text-primary"></i>
                            <h4 class="card-title mb-3">نظام تحفيزي</h4>
                            <p class="card-text">احصل على نقاط ومكافآت وشارات تقديرية تعكس جهودك وتحفزك على الاستمرار في العطاء</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card feature-card h-100">
                        <div class="card-body text-center p-5">
                            <i class="bi bi-chat-dots feature-icon text-primary"></i>
                            <h4 class="card-title mb-3">مجتمع تفاعلي</h4>
                            <p class="card-text">تواصل مع متطوعين آخرين وشارك تجاربك واستفد من خبرات الآخرين في مجتمع تفاعلي مخصص</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- الأثر المجتمعي -->
    <section id="impact" class="impact-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h2 class="fw-bold mb-4">الأثر المجتمعي للتطوع المنظم</h2>
                    <p class="mb-4">عندما يتم تنظيم العمل التطوعي بشكل احترافي، يصبح تأثيره أعمق وأكثر استدامة في المجتمع. نحن نساعد في تحقيق ذلك من خلال:</p>
                    <ul class="list-unstyled">
                        <li class="mb-3"><i class="bi bi-check-circle-fill me-2"></i> تعظيم الاستفادة من طاقات المتطوعين</li>
                        <li class="mb-3"><i class="bi bi-check-circle-fill me-2"></i> توجيه الجهود التطوعية نحو الاحتياجات الحقيقية</li>
                        <li class="mb-3"><i class="bi bi-check-circle-fill me-2"></i> بناء شراكات فعالة بين المنظمات والمتطوعين</li>
                        <li class="mb-3"><i class="bi bi-check-circle-fill me-2"></i> قياس وتوثيق الأثر المجتمعي للعمل التطوعي</li>
                    </ul>
                    <a href="#" class="btn btn-light mt-3">تعرف على قصص النجاح</a>
                </div>
                <div class="col-lg-6">
                    <div class="row g-3">
                        <div class="col-6">
                            <div class="card stat-card bg-white text-dark">
                                <div class="card-body text-center p-4">
                                    <i class="bi bi-tree fs-1 text-success mb-2"></i>
                                    <h4>125+</h4>
                                    <p>مشروع بيئي</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card stat-card bg-white text-dark">
                                <div class="card-body text-center p-4">
                                    <i class="bi bi-book fs-1 text-primary mb-2"></i>
                                    <h4>680+</h4>
                                    <p>طفل مستفيد</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card stat-card bg-white text-dark">
                                <div class="card-body text-center p-4">
                                    <i class="bi bi-heart-pulse fs-1 text-danger mb-2"></i>
                                    <h4>320+</h4>
                                    <p>مبادرة صحية</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card stat-card bg-white text-dark">
                                <div class="card-body text-center p-4">
                                    <i class="bi bi-house fs-1 text-warning mb-2"></i>
                                    <h4>45+</h4>
                                    <p>أسرة مستفيدة</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- آراء المستخدمين -->
    <section id="testimonials" class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center mb-5">
                    <h2 class="section-title">ماذا يقول مستخدمونا؟</h2>
                    <p class="text-muted">انضم إلى آلاف المتطوعين والمنظمات الذين يستخدمون منصتنا</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4">
                    <div class="card testimonial-card h-100">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center mb-3">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-person-circle fs-1 text-primary"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5 class="mb-0">سارة أحمد</h5>
                                    <small class="text-muted">متطوعة منذ 2023</small>
                                </div>
                            </div>
                            <p class="card-text">"بفضل هذه المنصة، تمكنت من العثور على فرص تطوعية تناسب تخصصي وخبراتي. نظام تتبع الساعات ساعدني في توثيق خبراتي للسيرة الذاتية."</p>
                            <div class="text-warning">
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card testimonial-card h-100">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center mb-3">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-person-circle fs-1 text-primary"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5 class="mb-0">محمد الخير</h5>
                                    <small class="text-muted">مدير منظمة خيرية</small>
                                </div>
                            </div>
                            <p class="card-text">"المنصة وفرت علينا الكثير من الجهد والوقت في إدارة المتطوعين. الآن يمكننا التركيز أكثر على تحقيق أهدافنا بدلاً من الأعمال الإدارية."</p>
                            <div class="text-warning">
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-half"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card testimonial-card h-100">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center mb-3">
                                <div class="flex-shrink-0">
                                    <i class="bi bi-person-circle fs-1 text-primary"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5 class="mb-0">فاطمة عبدالله</h5>
                                    <small class="text-muted">متطوعة عن بُعد</small>
                                </div>
                            </div>
                            <p class="card-text">"كمتطوعة عن بُعد، ساعدتني المنصة في العثور على فرص تطوعية يمكنني القيام بها من المنزل. النظام سهل الاستخدام ويوفر كل ما أحتاجه."</p>
                            <div class="text-warning">
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- دعوة للعمل -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h2 class="mb-4">جاهز لبدء رحلتك التطوعية؟</h2>
                    <p class="lead mb-4">انضم إلى منصتنا اليوم وكن جزءاً من التغيير الإيجابي في مجتمعك</p>
                    
                </div>
            </div>
        </div>
    </section>

    <!-- تذييل الصفحة -->
    <footer class="footer">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <h5 class="mb-4">
                        <i class="bi bi-heart-pulse me-2"></i>
                        نظام إدارة التطوع
                    </h5>
                    <p>منصة رقمية شاملة تربط المتطوعين بالفرص التطوعية المناسبة، وتوفر أدوات متكاملة لإدارة العمل التطوعي بفعالية واحترافية.</p>
                    <div class="d-flex gap-3 mt-4">
                        <a href="#" class="text-light fs-5"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="text-light fs-5"><i class="bi bi-twitter"></i></a>
                        <a href="#" class="text-light fs-5"><i class="bi bi-instagram"></i></a>
                        <a href="#" class="text-light fs-5"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <h5 class="mb-4">روابط سريعة</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">الرئيسية</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">عن المنصة</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">المميزات</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">الأسئلة الشائعة</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-6">
                    <h5 class="mb-4">الحسابات</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="login.php" class="text-light text-decoration-none">تسجيل الدخول</a></li>
                        <li class="mb-2"><a href="register.php" class="text-light text-decoration-none">إنشاء حساب</a></li>
                    </ul>
                </div>
                
            </div>
            <hr class="my-5">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">© 2025 نظام إدارة التطوع. جميع الحقوق محفوظة.</p>
                </div>
                
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
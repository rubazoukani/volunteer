<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

// فقط مدير النظام يمكنه الدخول
requireRole('system_admin');

// معالجة تغيير حالة الحساب
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $user_id = (int)$_POST['user_id'];
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ? AND role = 'volunteer'");
        $stmt->execute([$user_id]);
        $success = "تم الموافقة على حساب المتطوع بنجاح!";
    }
    elseif ($action === 'reject') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE id = ? AND role = 'volunteer'");
        $stmt->execute([$user_id]);
        $success = "تم رفض حساب المتطوع بنجاح!";
    }
    elseif ($action === 'activate') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ? AND role = 'volunteer'");
        $stmt->execute([$user_id]);
        $success = "تم تفعيل حساب المتطوع بنجاح!";
    } 
    elseif ($action === 'deactivate') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE id = ? AND role = 'volunteer'");
        $stmt->execute([$user_id]);
        $success = "تم إلغاء تفعيل حساب المتطوع بنجاح!";
    } 
    elseif ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'volunteer'");
        $stmt->execute([$user_id]);
        $success = "تم حذف حساب المتطوع بنجاح!";
    }
    
    if (isset($success)) {
        header("Location: system_admin_volunteers.php?success=" . urlencode($success));
        exit();
    }
}

// جلب جميع المتطوعين مع معلوماتهم الإضافية
$stmt = $pdo->prepare("
    SELECT u.*, v.city, v.skills, v.availability
    FROM users u
    LEFT JOIN volunteers v ON u.id = v.user_id
    WHERE u.role = 'volunteer'
    ORDER BY u.created_at DESC
");
$stmt->execute();
$volunteers = $stmt->fetchAll();

// جلب إحصائيات الحسابات
$pending_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'volunteer' AND status = 'pending'")->fetchColumn();
$active_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'volunteer' AND status = 'active'")->fetchColumn();
$inactive_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'volunteer' AND status = 'inactive'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المتطوعين - مدير النظام</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- نفس كود الـ CSS السابق -->
    <style>
        /* نفس كود CSS من الصفحة السابقة */
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --sidebar-width: 280px;
            --sidebar-collapsed-width: 80px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .admin-sidebar {
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            right: 0;
            width: var(--sidebar-width);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: -5px 0 15px rgba(0,0,0,0.1);
        }
        
        .admin-sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .sidebar-logo {
            font-weight: 700;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-logo i {
            color: var(--accent);
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }
        
        .toggle-sidebar:hover {
            background: rgba(255,255,255,0.1);
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-title {
            padding: 15px 25px 10px;
            font-size: 0.8rem;
            text-transform: uppercase;
            color: #adb5bd;
            font-weight: 600;
            letter-spacing: 1px;
        }
        
        .sidebar-menu a {
            color: #adb5bd;
            text-decoration: none;
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s;
            margin: 0 10px 4px;
            border-radius: 8px;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar-menu a i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-menu a span {
            transition: opacity 0.3s;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a span,
        .admin-sidebar.collapsed .menu-title,
        .admin-sidebar.collapsed .sidebar-logo span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            margin: 0;
        }
        
        .admin-sidebar.collapsed .sidebar-logo {
            justify-content: center;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a {
            justify-content: center;
            padding: 15px;
        }
        
        .admin-main {
            margin-right: var(--sidebar-width);
            padding: 20px;
            transition: margin-right 0.3s ease;
        }
        
        .admin-main.sidebar-collapsed {
            margin-right: var(--sidebar-collapsed-width);
        }
        
        .admin-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 15px 25px;
            margin-bottom: 25px;
            border-radius: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title h1 {
            color: var(--primary);
            font-weight: 700;
            margin: 0;
            font-size: 1.8rem;
        }
        
        .page-title p {
            color: #6c757d;
            margin: 5px 0 0;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .user-info {
            text-align: right;
        }
        
        .user-info .username {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 2px;
        }
        
        .user-info .role {
            font-size: 0.85rem;
            color: #6c757d;
        }
        
        .volunteer-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
            border: none;
        }
        
        .volunteer-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .status-pending {
            background-color: rgba(255, 193, 7, 0.15);
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        
        .status-active {
            background-color: rgba(40, 167, 69, 0.15);
            color: #28a745;
            border: 1px solid #28a745;
        }
        
        .status-inactive {
            background-color: rgba(220, 53, 69, 0.15);
            color: #dc3545;
            border: 1px solid #dc3545;
        }
        
        .skills-tag {
            display: inline-block;
            background: rgba(108, 117, 125, 0.1);
            color: #6c757d;
            padding: 0.2em 0.6em;
            border-radius: 12px;
            font-size: 0.85rem;
            margin: 0.2em;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
        }
        
        @media (max-width: 992px) {
            .admin-sidebar {
                transform: translateX(0);
                width: 280px;
            }
            
            .admin-sidebar.collapsed {
                transform: translateX(280px);
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-main.sidebar-collapsed {
                margin-right: 0;
            }
        }
        
        @media (max-width: 768px) {
            .admin-navbar {
                padding: 15px;
            }
            
            .page-title h1 {
                font-size: 1.5rem;
            }
            
            .user-profile {
                gap: 10px;
            }
            
            .avatar {
                width: 40px;
                height: 40px;
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

<!-- الشريط الجانبي -->
<div class="admin-sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <i class="bi bi-heart-pulse"></i>
            <span>نظام التطوع</span>
        </div>
        <button class="toggle-sidebar" id="toggleSidebar">
            <i class="bi bi-list"></i>
        </button>
    </div>
    
    <div class="sidebar-menu">
        <a href="system_admin_dashboard.php">
            <i class="bi bi-speedometer2"></i>
            <span>لوحة التحكم</span>
        </a>
        
        <div class="menu-title">الحساب</div>
        <a href="system_admin_profile.php">
            <i class="bi bi-person"></i>
            <span>ملفي الشخصي</span>
        </a>
        
        <div class="menu-title">إدارة الحسابات</div>
        <a href="system_admin_organizations.php">
            <i class="bi bi-building"></i>
            <span>مدراء المنظمات</span>
        </a>
        <a href="system_admin_volunteers.php" class="active">
            <i class="bi bi-people"></i>
            <span>المتطوعون</span>
        </a>
        
        <div class="menu-title">إدارة المحتوى</div>
        <a href="system_admin_cities.php">
            <i class="bi bi-geo-alt"></i>
            <span>المدن</span>
        </a>
        <a href="system_admin_centers.php">
            <i class="bi bi-building"></i>
            <span>المراكز التطوعية</span>
        </a>
        <a href="system_admin_citizens.php">
            <i class="bi bi-person-lines-fill"></i>
            <span>المواطنين</span>
        </a>
        
        <div class="menu-title">التحليلات</div>
        <a href="system_admin_reports.php">
            <i class="bi bi-bar-chart-line"></i>
            <span>التقارير</span>
        </a>
        <a href="system_admin_reviews.php">
            <i class="bi bi-star"></i>
            <span>التقييمات</span>
        </a>
    </div>
</div>

<!-- المحتوى الرئيسي -->
<div class="admin-main" id="mainContent">
    <!-- الشريط العلوي -->
    <div class="admin-navbar">
        <div class="page-title">
            <h1>إدارة المتطوعين</h1>
            <p>الموافقة على الحسابات الجديدة وإدارة الحسابات الحالية</p>
        </div>
        
        <div class="user-profile">
           
            <a href="logout.php" class="btn btn-outline-danger ms-3">
                <i class="bi bi-box-arrow-right"></i>
            </a>
        </div>
    </div>
    
    <!-- رسائل النجاح والخطأ -->
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- ملخص الإحصائيات -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card border-left-warning shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-warning font-weight-bold">قيد الانتظار</h6>
                            <div class="h5 font-weight-bold"><?= $pending_count ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-hourglass text-warning" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-left-success shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-success font-weight-bold">الحسابات النشطة</h6>
                            <div class="h5 font-weight-bold"><?= $active_count ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-check-circle text-success" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-left-danger shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-danger font-weight-bold">الحسابات المرفوضة</h6>
                            <div class="h5 font-weight-bold"><?= $inactive_count ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-x-circle text-danger" style="font-size: 2rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- قائمة المتطوعين -->
    <div class="row g-4">
        <?php if ($volunteers): ?>
            <?php foreach ($volunteers as $volunteer): ?>
                <div class="col-lg-6">
                    <div class="card volunteer-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h5 class="card-title mb-2"><?= htmlspecialchars($volunteer['name']) ?></h5>
                                    <p class="text-muted mb-1">
                                        <i class="bi bi-envelope me-1"></i> <?= htmlspecialchars($volunteer['email']) ?>
                                    </p>
                                    <?php if (!empty($volunteer['phone'])): ?>
                                        <p class="text-muted mb-1">
                                            <i class="bi bi-telephone me-1"></i> <?= htmlspecialchars($volunteer['phone']) ?>
                                        </p>
                                    <?php endif; ?>
                                    <?php if (!empty($volunteer['city'])): ?>
                                        <p class="mb-2">
                                            <i class="bi bi-geo-alt me-1"></i> <?= htmlspecialchars($volunteer['city']) ?>
                                        </p>
                                    <?php endif; ?>
                                    <?php if (!empty($volunteer['skills'])): ?>
                                        <div class="mb-2">
                                            <small class="text-muted me-2">المهارات:</small>
                                            <?php 
                                            $skills = explode(',', $volunteer['skills']);
                                            foreach ($skills as $skill): ?>
                                                <span class="skills-tag"><?= htmlspecialchars(trim($skill)) ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($volunteer['availability'])): ?>
                                        <p class="mb-0">
                                            <small class="text-muted">
                                                <i class="bi bi-calendar-check me-1"></i> التوافر: <?= htmlspecialchars($volunteer['availability']) ?>
                                            </small>
                                        </p>
                                    <?php endif; ?>
                                </div>
                                <span class="badge <?= 
                                    $volunteer['status'] === 'pending' ? 'status-pending' : 
                                    ($volunteer['status'] === 'active' ? 'status-active' : 'status-inactive') 
                                ?>">
                                    <?php 
                                    if ($volunteer['status'] === 'pending') echo 'قيد الانتظار';
                                    elseif ($volunteer['status'] === 'active') echo 'نشط';
                                    else echo 'مرفوض';
                                    ?>
                                </span>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <small class="text-muted">
                                    <i class="bi bi-clock me-1"></i> <?= date('Y-m-d H:i', strtotime($volunteer['created_at'])) ?>
                                </small>
                                
                                <div class="d-flex gap-2">
                                    <?php if ($volunteer['status'] === 'pending'): ?>
                                        <!-- الموافقة على الحساب -->
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?= $volunteer['id'] ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <button type="submit" class="btn btn-outline-success btn-sm">
                                                <i class="bi bi-check-circle me-1"></i> موافقة
                                            </button>
                                        </form>
                                        
                                        <!-- رفض الحساب -->
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?= $volunteer['id'] ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" class="btn btn-outline-danger btn-sm" 
                                                    onclick="return confirm('هل أنت متأكد من رفض هذا الحساب؟')">
                                                <i class="bi bi-x-circle me-1"></i> رفض
                                            </button>
                                        </form>
                                    <?php elseif ($volunteer['status'] === 'active'): ?>
                                        <!-- إلغاء التفعيل -->
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?= $volunteer['id'] ?>">
                                            <input type="hidden" name="action" value="deactivate">
                                            <button type="submit" class="btn btn-outline-danger btn-sm" 
                                                    onclick="return confirm('هل أنت متأكد من إلغاء تفعيل هذا الحساب؟')">
                                                <i class="bi bi-power me-1"></i> إلغاء التفعيل
                                            </button>
                                        </form>
                                        
                                        <!-- حذف -->
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?= $volunteer['id'] ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <button type="submit" class="btn btn-outline-secondary btn-sm" 
                                                    onclick="return confirm('هل أنت متأكد من حذف هذا الحساب نهائيًا؟')">
                                                <i class="bi bi-trash me-1"></i> حذف
                                            </button>
                                        </form>
                                    <?php else: // inactive ?>
                                        <!-- تفعيل -->
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?= $volunteer['id'] ?>">
                                            <input type="hidden" name="action" value="activate">
                                            <button type="submit" class="btn btn-outline-success btn-sm">
                                                <i class="bi bi-check-circle me-1"></i> تفعيل
                                            </button>
                                        </form>
                                        
                                        <!-- حذف -->
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?= $volunteer['id'] ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <button type="submit" class="btn btn-outline-secondary btn-sm" 
                                                    onclick="return confirm('هل أنت متأكد من حذف هذا الحساب نهائيًا؟')">
                                                <i class="bi bi-trash me-1"></i> حذف
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="empty-state">
                    <i class="bi bi-people fs-1 text-muted mb-3"></i>
                    <h4 class="text-muted mb-2">لا توجد حسابات متطوعين</h4>
                    <p class="text-muted">سيظهر هنا المتطوعون المسجلون في النظام.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// تبديل الشريط الجانبي
document.getElementById('toggleSidebar').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('sidebar-collapsed');
});
</script>
</body>
</html>

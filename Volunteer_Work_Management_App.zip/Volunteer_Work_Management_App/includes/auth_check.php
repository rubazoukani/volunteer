<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// التحقق من نوع المستخدم (يُستخدم في صفحات محددة)
function requireRole($requiredRole) {
    if ($_SESSION['user_role'] !== $requiredRole) {
        http_response_code(403);
        die("<div class='container mt-5 text-center'><h3 class='text-danger'>غير مصرح لك بالوصول إلى هذه الصفحة</h3><a href='index.php' class='btn btn-primary mt-3'>العودة للرئيسية</a></div>");
    }
}
?>
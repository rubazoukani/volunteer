<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

// معالجة تصدير CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="volunteer_system_report_' . date('Y-m-d') . '.csv"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    $output = fopen('php://output', 'w');
    
    // كتابة رأس CSV
    fputcsv($output, ['نوع التقرير', 'القيمة', 'التاريخ']);
    
    // جلب الإحصائيات
    $stats = [
        'مراكز تطوعية' => $pdo->query("SELECT COUNT(*) FROM centers")->fetchColumn(),
        'فرص تطوع' => $pdo->query("SELECT COUNT(*) FROM volunteer_opportunities")->fetchColumn(),
        'فرص تدريب' => $pdo->query("SELECT COUNT(*) FROM training_opportunities")->fetchColumn(),
        'طلبات تطوع' => $pdo->query("SELECT COUNT(*) FROM volunteer_requests")->fetchColumn(),
        'طلبات مساعدة' => $pdo->query("SELECT COUNT(*) FROM help_requests")->fetchColumn(),
        'خدمات' => $pdo->query("SELECT COUNT(*) FROM services")->fetchColumn(),
        'متطوعون' => $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'volunteer'")->fetchColumn(),
        'طلبات تطوع مقبولة' => $pdo->query("SELECT COUNT(*) FROM volunteer_requests WHERE status = 'approved'")->fetchColumn(),
        'طلبات مساعدة مقبولة' => $pdo->query("SELECT COUNT(*) FROM help_requests WHERE status = 'accepted'")->fetchColumn(),
    ];
    
    // كتابة البيانات
    foreach ($stats as $key => $value) {
        fputcsv($output, [$key, $value, date('Y-m-d H:i:s')]);
    }
    
    fclose($output);
    exit();
}

// جلب الإحصائيات للعرض
$stats = [
    'مراكز تطوعية' => $pdo->query("SELECT COUNT(*) FROM centers")->fetchColumn(),
    'فرص تطوع' => $pdo->query("SELECT COUNT(*) FROM volunteer_opportunities")->fetchColumn(),
    'فرص تدريب' => $pdo->query("SELECT COUNT(*) FROM training_opportunities")->fetchColumn(),
    'طلبات تطوع' => $pdo->query("SELECT COUNT(*) FROM volunteer_requests")->fetchColumn(),
    'طلبات مساعدة' => $pdo->	query("SELECT COUNT(*) FROM help_requests")->fetchColumn(),
    'خدمات' => $pdo->query("SELECT COUNT(*) FROM services")->fetchColumn(),
    'متطوعون' => $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'volunteer'")->fetchColumn(),
    'طلبات تطوع مقبولة' => $pdo->query("SELECT COUNT(*) FROM volunteer_requests WHERE status = 'approved'")->fetchColumn(),
    'طلبات مساعدة مقبولة' => $pdo->query("SELECT COUNT(*) FROM help_requests WHERE status = 'accepted'")->fetchColumn(),
];
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقارير النظام - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .report-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .report-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary);
        }
        
        .btn-export {
            background: linear-gradient(135deg, var(--primary), #1e4a8a);
            border: none;
            padding: 12px 25px;
            font-weight: 600;
            border-radius: 30px;
        }
        
        .btn-export:hover {
            background: linear-gradient(135deg, #1e4a8a, var(--primary));
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <i class="bi bi-heart-pulse me-2 text-primary"></i>
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="../dashboard.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للوحة التحكم
            </a>
            <a href="../logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-bar-chart-line me-2"></i> تقارير النظام
        </h2>
        <button onclick="window.location.href='?export=csv'" class="btn btn-export">
            <i class="bi bi-file-earmark-spreadsheet me-2"></i> تصدير كـ CSV
        </button>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- المراكز التطوعية -->
        <div class="col-md-6 col-lg-4">
            <div class="card report-card text-center">
                <div class="card-body">
                    <div class="stat-number"><?= $stats['مراكز تطوعية'] ?></div>
                    <h5 class="card-title">مراكز تطوعية</h5>
                </div>
            </div>
        </div>
        
        <!-- فرص التطوع -->
        <div class="col-md-6 col-lg-4">
            <div class="card report-card text-center">
                <div class="card-body">
                    <div class="stat-number"><?= $stats['فرص تطوع'] ?></div>
                    <h5 class="card-title">فرص تطوع</h5>
                </div>
            </div>
        </div>
        
        <!-- فرص التدريب -->
        <div class="col-md-6 col-lg-4">
            <div class="card report-card text-center">
                <div class="card-body">
                    <div class="stat-number"><?= $stats['فرص تدريب'] ?></div>
                    <h5 class="card-title">فرص تدريب</h5>
                </div>
            </div>
        </div>
        
        <!-- المتطوعون -->
        <div class="col-md-6 col-lg-4">
            <div class="card report-card text-center">
                <div class="card-body">
                    <div class="stat-number"><?= $stats['متطوعون'] ?></div>
                    <h5 class="card-title">المتطوعون</h5>
                </div>
            </div>
        </div>
        
        <!-- الطلبات المقبولة -->
        <div class="col-md-6 col-lg-4">
            <div class="card report-card text-center">
                <div class="card-body">
                    <div class="stat-number"><?= $stats['طلبات تطوع مقبولة'] ?></div>
                    <h5 class="card-title">تطوع مقبول</h5>
                </div>
            </div>
        </div>
        
        <!-- طلبات المساعدة المقبولة -->
        <div class="col-md-6 col-lg-4">
            <div class="card report-card text-center">
                <div class="card-body">
                    <div class="stat-number"><?= $stats['طلبات مساعدة مقبولة'] ?></div>
                    <h5 class="card-title">مساعدة مقبولة</h5>
                </div>
            </div>
        </div>
        
        <!-- الخدمات -->
        <div class="col-md-6 col-lg-4">
            <div class="card report-card text-center">
                <div class="card-body">
                    <div class="stat-number"><?= $stats['خدمات'] ?></div>
                    <h5 class="card-title">الخدمات</h5>
                </div>
            </div>
        </div>
        
        <!-- طلبات التطوع الكلية -->
        <div class="col-md-6 col-lg-4">
            <div class="card report-card text-center">
                <div class="card-body">
                    <div class="stat-number"><?= $stats['طلبات تطوع'] ?></div>
                    <h5 class="card-title">جميع طلبات التطوع</h5>
                </div>
            </div>
        </div>
        
        <!-- طلبات المساعدة الكلية -->
        <div class="col-md-6 col-lg-4">
            <div class="card report-card text-center">
                <div class="card-body">
                    <div class="stat-number"><?= $stats['طلبات مساعدة'] ?></div>
                    <h5 class="card-title">جميع طلبات المساعدة</h5>
                </div>
            </div>
        </div>
    </div>

    <!-- قسم معلومات إضافية -->
    <div class="card mt-5">
        <div class="card-header bg-white">
            <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i> معلومات التقرير</h5>
        </div>
        <div class="card-body">
            <p class="text-muted">
                <strong>تاريخ التقرير:</strong> <?= date('Y-m-d H:i:s') ?><br>
                <strong>المستخدم:</strong> <?= htmlspecialchars($_SESSION['user_name']) ?><br>
                <strong>المنظمة:</strong> <?= htmlspecialchars($_SESSION['user_email']) ?>
            </p>
            
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// إضافة تأكيد بسيط عند التصدير
document.querySelector('.btn-export').addEventListener('click', function() {
    // لا حاجة لتأكيد، التصدير مباشر
});
</script>
</body>
</html>

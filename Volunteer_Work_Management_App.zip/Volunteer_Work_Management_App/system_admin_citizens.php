<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

// فقط مدير النظام يمكنه الدخول
requireRole('system_admin');

// جلب جميع المواطنين
$stmt = $pdo->prepare("SELECT * FROM citizens ORDER BY created_at DESC");
$stmt->execute();
$citizens = $stmt->fetchAll();

// جلب الإحصائيات
$total_citizens = count($citizens);
$active_citizens = $pdo->query("SELECT COUNT(*) FROM citizens WHERE status = 'active'")->fetchColumn();
$inactive_citizens = $pdo->query("SELECT COUNT(*) FROM citizens WHERE status = 'inactive'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المواطنين - مدير النظام</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --sidebar-width: 280px;
            --sidebar-collapsed-width: 80px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        /* الشريط الجانبي */
        .admin-sidebar {
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            right: 0;
            width: var(--sidebar-width);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: -5px 0 15px rgba(0,0,0,0.1);
        }
        
        .admin-sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .sidebar-logo {
            font-weight: 700;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-logo i {
            color: var(--accent);
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }
        
        .toggle-sidebar:hover {
            background: rgba(255,255,255,0.1);
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-title {
            padding: 15px 25px 10px;
            font-size: 0.8rem;
            text-transform: uppercase;
            color: #adb5bd;
            font-weight: 600;
            letter-spacing: 1px;
        }
        
        .sidebar-menu a {
            color: #adb5bd;
            text-decoration: none;
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s;
            margin: 0 10px 4px;
            border-radius: 8px;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar-menu a i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-menu a span {
            transition: opacity 0.3s;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a span,
        .admin-sidebar.collapsed .menu-title,
        .admin-sidebar.collapsed .sidebar-logo span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            margin: 0;
        }
        
        .admin-sidebar.collapsed .sidebar-logo {
            justify-content: center;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a {
            justify-content: center;
            padding: 15px;
        }
        
        /* المحتوى الرئيسي */
        .admin-main {
            margin-right: var(--sidebar-width);
            padding: 20px;
            transition: margin-right 0.3s ease;
        }
        
        .admin-main.sidebar-collapsed {
            margin-right: var(--sidebar-collapsed-width);
        }
        
        /* الشريط العلوي */
        .admin-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 15px 25px;
            margin-bottom: 25px;
            border-radius: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title h1 {
            color: var(--primary);
            font-weight: 700;
            margin: 0;
            font-size: 1.8rem;
        }
        
        .page-title p {
            color: #6c757d;
            margin: 5px 0 0;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .user-info {
            text-align: right;
        }
        
        .user-info .username {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 2px;
        }
        
        .user-info .role {
            font-size: 0.85rem;
            color: #6c757d;
        }
        
        /* بطاقات المواطنين */
        .citizen-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
            border: none;
            background: white;
        }
        
        .citizen-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .citizen-header {
            padding: 20px;
            background: linear-gradient(135deg, var(--primary), #1e4a8a);
            color: white;
        }
        
        .citizen-name {
            font-weight: 700;
            font-size: 1.3rem;
            margin: 0;
        }
        
        .citizen-gender {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.85rem;
            margin-top: 5px;
        }
        
        .citizen-body {
            padding: 20px;
        }
        
        .citizen-info {
            margin-bottom: 15px;
        }
        
        .citizen-info label {
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 3px;
        }
        
        .citizen-info p {
            margin: 0;
            color: #495057;
        }
        
        .status-active { background-color: rgba(40, 167, 69, 0.15); color: #28a745; border: 1px solid #28a745; }
        .status-inactive { background-color: rgba(220, 53, 69, 0.15); color: #dc3545; border: 1px solid #dc3545; }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        
        /* التصميم المتجاوب */
        @media (max-width: 992px) {
            .admin-sidebar {
                transform: translateX(0);
                width: 280px;
            }
            
            .admin-sidebar.collapsed {
                transform: translateX(280px);
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-main.sidebar-collapsed {
                margin-right: 0;
            }
        }
        
        @media (max-width: 768px) {
            .admin-navbar {
                padding: 15px;
            }
            
            .page-title h1 {
                font-size: 1.5rem;
            }
            
            .user-profile {
                gap: 10px;
            }
            
            .avatar {
                width: 40px;
                height: 40px;
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

<!-- الشريط الجانبي -->
<div class="admin-sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <i class="bi bi-heart-pulse"></i>
            <span>نظام التطوع</span>
        </div>
        <button class="toggle-sidebar" id="toggleSidebar">
            <i class="bi bi-list"></i>
        </button>
    </div>
    
    <div class="sidebar-menu">
        <a href="system_admin_dashboard.php">
            <i class="bi bi-speedometer2"></i>
            <span>لوحة التحكم</span>
        </a>
        
        <div class="menu-title">الحساب</div>
        <a href="system_admin_profile.php">
            <i class="bi bi-person"></i>
            <span>ملفي الشخصي</span>
        </a>
        
        <div class="menu-title">إدارة الحسابات</div>
        <a href="system_admin_organizations.php">
            <i class="bi bi-building"></i>
            <span>مدراء المنظمات</span>
        </a>
        <a href="system_admin_volunteers.php">
            <i class="bi bi-people"></i>
            <span>المتطوعون</span>
        </a>
        
        <div class="menu-title">إدارة المحتوى</div>
        <a href="system_admin_cities.php">
            <i class="bi bi-geo-alt"></i>
            <span>المدن</span>
        </a>
        <a href="system_admin_centers.php">
            <i class="bi bi-building"></i>
            <span>المراكز التطوعية</span>
        </a>
        <a href="system_admin_citizens.php" class="active">
            <i class="bi bi-person-lines-fill"></i>
            <span>المواطنين</span>
        </a>
        
        <div class="menu-title">التحليلات</div>
        <a href="system_admin_reports.php">
            <i class="bi bi-bar-chart-line"></i>
            <span>التقارير</span>
        </a>
        <a href="system_admin_reviews.php">
            <i class="bi bi-star"></i>
            <span>التقييمات</span>
        </a>
    </div>
</div>

<!-- المحتوى الرئيسي -->
<div class="admin-main" id="mainContent">
    <!-- الشريط العلوي -->
    <div class="admin-navbar">
        <div class="page-title">
            <h1>المواطنين</h1>
            <p>عرض جميع المواطنين المسجلين في النظام</p>
        </div>
        
        <div class="user-profile">
            <a href="logout.php" class="btn btn-outline-danger ms-3">
                <i class="bi bi-box-arrow-right"></i>
            </a>
        </div>
    </div>
    
    <!-- ملخص الإحصائيات -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card border-left-primary shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-primary font-weight-bold">إجمالي المواطنين</h6>
                            <div class="h5 font-weight-bold"><?= $total_citizens ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-people text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-left-success shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-success font-weight-bold">المواطنين النشطين</h6>
                            <div class="h5 font-weight-bold"><?= $active_citizens ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-check-circle text-success" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-left-danger shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-danger font-weight-bold">المواطنين غير النشطين</h6>
                            <div class="h5 font-weight-bold"><?= $inactive_citizens ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-x-circle text-danger" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- قائمة المواطنين -->
    <h4 class="mb-4">
        <i class="bi bi-list-ul me-2 text-primary"></i>
        قائمة المواطنين
    </h4>
    
    <?php if ($citizens): ?>
        <div class="row g-4">
            <?php foreach ($citizens as $citizen): ?>
                <div class="col-lg-6">
                    <div class="card citizen-card h-100">
                        <div class="citizen-header">
                            <h3 class="citizen-name"><?= htmlspecialchars($citizen['full_name']) ?></h3>
                            <div class="citizen-gender">
                                <i class="bi bi-gender-<?= $citizen['gender'] === 'ذكر' ? 'male' : 'female' ?> me-1"></i>
                                <?= $citizen['gender'] === 'ذكر' ? 'ذكر' : 'أنثى' ?>
                            </div>
                        </div>
                        <div class="citizen-body">
                            <div class="citizen-info">
                                <label><i class="bi bi-geo-alt me-1"></i> المدينة</label>
                                <p><?= htmlspecialchars($citizen['city'] ?: 'غير محدد') ?></p>
                            </div>
                            
                            <?php if ($citizen['address']): ?>
                                <div class="citizen-info">
                                    <label><i class="bi bi-geo me-1"></i> العنوان</label>
                                    <p><?= htmlspecialchars($citizen['address']) ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($citizen['phone']): ?>
                                <div class="citizen-info">
                                    <label><i class="bi bi-telephone me-1"></i> رقم الهاتف</label>
                                    <p><?= htmlspecialchars($citizen['phone']) ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($citizen['email']): ?>
                                <div class="citizen-info">
                                    <label><i class="bi bi-envelope me-1"></i> البريد الإلكتروني</label>
                                    <p><?= htmlspecialchars($citizen['email']) ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($citizen['id_number']): ?>
                                <div class="citizen-info">
                                    <label><i class="bi bi-credit-card me-1"></i> رقم الهوية</label>
                                    <p><?= htmlspecialchars($citizen['id_number']) ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($citizen['birth_date']): ?>
                                <div class="citizen-info">
                                    <label><i class="bi bi-calendar me-1"></i> تاريخ الميلاد</label>
                                    <p><?= date('Y-m-d', strtotime($citizen['birth_date'])) ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <span class="badge <?= $citizen['status'] === 'active' ? 'status-active' : 'status-inactive' ?>">
                                    <?= $citizen['status'] === 'active' ? 'نشط' : 'غير نشط' ?>
                                </span>
                                <small class="text-muted">
                                    <i class="bi bi-clock me-1"></i>
                                    <?= date('Y-m-d', strtotime($citizen['created_at'])) ?>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-people fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد بيانات مواطنين</h4>
            <p class="text-muted">لم يتم تسجيل أي مواطنين في النظام حتى الآن.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// تبديل الشريط الجانبي
document.getElementById('toggleSidebar').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('sidebar-collapsed');
});
</script>
</body>
</html>


<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

// معالجة تغيير حالة الطلب
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $request_id = (int)$_POST['request_id'];
    $new_status = $_POST['status'];
    
    if (in_array($new_status, ['pending', 'approved', 'rejected'])) {
        $stmt = $pdo->prepare("UPDATE volunteer_requests SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $request_id]);
        $success = "تم تحديث حالة الطلب بنجاح!";
        header("Location: volunteer_requests.php?success=" . urlencode($success));
        exit();
    }
}

// جلب جميع طلبات التطوع مع تفاصيل الفرصة والمركز
$stmt = $pdo->prepare("
    SELECT vr.*, 
           vo.title as opportunity_title,
           c.name as center_name,
           c.city as center_city
    FROM volunteer_requests vr
    LEFT JOIN volunteer_opportunities vo ON vr.opportunity_id = vo.id
    LEFT JOIN centers c ON vo.center_id = c.id
    ORDER BY vr.submitted_at DESC
");
$stmt->execute();
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة طلبات التطوع - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .request-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .request-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .status-pending { background: rgba(255, 193, 7, 0.15); color: #856404; border: 1px solid #ffeaa7; }
        .status-approved { background: rgba(40, 167, 69, 0.15); color: #155724; border: 1px solid #c3e6cb; }
        .status-rejected { background: rgba(220, 53, 69, 0.15); color: #721c24; border: 1px solid #f1b0b7; }
        
        .form-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
        }
        
        .status-badge {
            font-size: 0.85rem;
            padding: 0.4em 0.8em;
            border-radius: 20px;
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <i class="bi bi-heart-pulse me-2 text-primary"></i>
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="../dashboard.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للوحة التحكم
            </a>
            <a href="../logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-file-earmark-check me-2"></i> إدارة طلبات التطوع
        </h2>
        <span class="badge bg-primary"><?= count($requests) ?> طلب</span>
    </div>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- عرض الطلبات -->
    <h4 class="mb-4"><i class="bi bi-list-ul me-2 text-primary"></i> سجل طلبات التطوع</h4>

    <?php if ($requests): ?>
        <div class="row g-4">
            <?php foreach ($requests as $request): ?>
                <div class="col-lg-6">
                    <div class="card request-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h5 class="card-title mb-1"><?= htmlspecialchars($request['user_name']) ?></h5>
                                    <p class="text-muted mb-1">
                                        <i class="bi bi-envelope me-1"></i> <?= htmlspecialchars($request['user_email']) ?>
                                    </p>
                                </div>
                                <span class="status-badge <?= 
                                    $request['status'] === 'pending' ? 'status-pending' : 
                                    ($request['status'] === 'approved' ? 'status-approved' : 'status-rejected') 
                                ?>">
                                    <?php 
                                    if ($request['status'] === 'pending') echo 'قيد الانتظار';
                                    elseif ($request['status'] === 'approved') echo 'مقبول';
                                    else echo 'مرفوض';
                                    ?>
                                </span>
                            </div>
                            
                            <?php if ($request['opportunity_title']): ?>
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <strong>فرصة التطوع:</strong> <?= htmlspecialchars($request['opportunity_title']) ?>
                                    </small>
                                </div>
                                <?php if ($request['center_name']): ?>
                                    <div class="mb-2">
                                        <small class="text-muted">
                                            <i class="bi bi-building me-1"></i> <?= htmlspecialchars($request['center_name']) ?>
                                            <?php if ($request['center_city']): ?>
                                                <span class="badge bg-light text-dark ms-1"><?= htmlspecialchars($request['center_city']) ?></span>
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="mb-2">
                                    <small class="text-muted">فرصة التطوع: غير متوفرة</small>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <small class="text-muted">
                                    <i class="bi bi-clock me-1"></i> <?= date('Y-m-d H:i', strtotime($request['submitted_at'])) ?>
                                </small>
                                
                                <div>
                                    <!-- نموذج تغيير الحالة -->
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                        <select name="status" class="form-select form-select-sm d-inline me-2" style="width: auto;" onchange="this.form.submit()">
                                            <option value="pending" <?= $request['status'] === 'pending' ? 'selected' : '' ?>>قيد الانتظار</option>
                                            <option value="approved" <?= $request['status'] === 'approved' ? 'selected' : '' ?>>مقبول</option>
                                            <option value="rejected" <?= $request['status'] === 'rejected' ? 'selected' : '' ?>>مرفوض</option>
                                        </select>
                                        <button type="submit" name="update_status" class="btn btn-outline-primary btn-sm">
                                            <i class="bi bi-check"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-file-earmark-check fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد طلبات تطوع حتى الآن</h4>
            <p class="text-muted">سيظهر هنا طلبات المتطوعين عند تقديمهم لفرص التطوع.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

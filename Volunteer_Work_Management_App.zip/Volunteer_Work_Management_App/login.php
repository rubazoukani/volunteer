<?php
session_start();
require_once 'config/db.php';

if (isset($_SESSION['user_id'])) {
    // توجيه حسب الدور
    if ($_SESSION['user_role'] === 'org_admin') {
        header("Location: dashboard.php");
    } else {
        header("Location: system_admin_dashboard.php");
    }
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = "يرجى إدخال البريد الإلكتروني وكلمة المرور.";
    } else {
        // تعديل الاستعلام ليشمل حقل status
        $stmt = $pdo->prepare("SELECT id, name, email, password, role, status FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            // التحقق من حالة الحساب أولاً
            if ($user['status'] === 'inactive') {
                $error = "حسابك غير مفعل. يرجى التواصل مع مدير النظام.";
            } 
            elseif ($user['status'] === 'pending') {
                $error = "حسابك قيد الانتظار. يرجى الانتظار حتى يتم الموافقة عليه من قبل مدير النظام.";
            }
            // ثم التحقق من كلمة المرور (للحسابات النشطة فقط)
            elseif ($user['status'] === 'active' && password_verify($password, $user['password'])) {
                // بدء الجلسة
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['user_status'] = $user['status'];
                
                // توجيه حسب الدور
                if ($user['role'] === 'org_admin') {
                    header("Location: dashboard.php");
                } else {
                    header("Location: system_admin_dashboard.php");
                }
                exit();
            } else {
                $error = "بيانات الدخول غير صحيحة. يرجى المحاولة مرة أخرى.";
            }
        } else {
            $error = "بيانات الدخول غير صحيحة. يرجى المحاولة مرة أخرى.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - نظام إدارة العمل التطوعي</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4edf9 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .login-container {
            max-width: 450px;
            margin: 3rem auto;
            padding: 2.5rem;
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .login-header h2 {
            color: var(--primary);
            font-weight: 700;
        }
        
        .login-header p {
            color: #6c757d;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 12px;
            font-weight: 600;
            border-radius: 30px;
        }
        
        .btn-primary:hover {
            background-color: #1e4a8a;
            border-color: #1e4a8a;
        }
        
        .alert-inactive,
        .alert-pending {
            background-color: #fff3cd;
            border-color: #ffeaa7;
            color: #856404;
        }
        
        .alert-pending {
            background-color: #e8f4fd;
            border-color: #bee5eb;
            color: #0c5460;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h2><i class="bi bi-box-arrow-in-right me-2"></i> تسجيل الدخول</h2>
            <p>أدخل بيانات حسابك للوصول إلى لوحة التحكم</p>
        </div>

        <?php if ($error): ?>
            <?php if (strpos($error, 'قيد الانتظار') !== false): ?>
                <div class="alert alert-pending alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php elseif (strpos($error, 'غير مفعل') !== false): ?>
                <div class="alert alert-inactive alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php else: ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">البريد الإلكتروني</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">كلمة المرور</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">تسجيل الدخول</button>

            <div class="text-center mt-3">
                <a href="index.php" class="text-decoration-none"><i class="bi bi-arrow-left me-1"></i> العودة للرئيسية</a> |
                <a href="register.php" class="text-decoration-none">ليس لديك حساب؟ سجل الآن</a>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

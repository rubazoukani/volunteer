<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

// جلب بيانات المستخدم الحالي
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$current_user = $stmt->fetch();

if (!$current_user) {
    header("Location: logout.php");
    exit();
}

$error = '';
$success = '';

// معالجة تحديث بيانات الملف الشخصي
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $organization_name = trim($_POST['organization_name'] ?? '');
    
    if (empty($name) || empty($email)) {
        $error = "الاسم والبريد الإلكتروني مطلوبان.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "البريد الإلكتروني غير صحيح.";
    } else {
        // التحقق من عدم وجود بريد إلكتروني مسجل لمستخدم آخر
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $_SESSION['user_id']]);
        if ($stmt->fetch()) {
            $error = "البريد الإلكتروني مستخدم من قبل مستخدم آخر.";
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ?, organization_name = ? WHERE id = ?");
            $stmt->execute([$name, $email, $phone, $organization_name, $_SESSION['user_id']]);
            
            // تحديث جلسة المستخدم
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            
            $success = "تم تحديث بيانات الملف الشخصي بنجاح!";
            header("Location: profile.php?success=" . urlencode($success));
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ملفي الشخصي - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --card-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding-bottom: 2rem;
        }
        
        .navbar {
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .profile-container {
            max-width: 950px;
            margin: 2rem auto;
        }
        
        .profile-card {
            background: white;
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            overflow: hidden;
            transition: var(--transition);
        }
        
        .profile-card:hover {
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
        }
        
        .profile-header {
            background: linear-gradient(135deg, var(--primary), #3a6dc2);
            color: white;
            padding: 2.5rem 2rem;
            position: relative;
            overflow: hidden;
        }
        
        .profile-header::before {
            content: "";
            position: absolute;
            top: -50%;
            right: -20%;
            width: 150%;
            height: 150%;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 40% 40% 0 0;
            transform: rotate(10deg);
        }
        
        .profile-avatar {
            width: 110px;
            height: 110px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-size: 2.8rem;
            font-weight: bold;
            margin: 0 auto 1.5rem;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
            position: relative;
            z-index: 2;
        }
        
        .profile-name {
            font-weight: 700;
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 2;
        }
        
        .profile-role {
            opacity: 0.9;
            font-size: 1.1rem;
            margin-bottom: 1rem;
            position: relative;
            z-index: 2;
        }
        
        .profile-org {
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1.5rem;
            border-radius: 30px;
            display: inline-block;
            font-size: 0.95rem;
            backdrop-filter: blur(5px);
            position: relative;
            z-index: 2;
        }
        
        .profile-body {
            padding: 2.5rem;
        }
        
        .section-title {
            color: var(--primary);
            margin-bottom: 1.8rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid rgba(44, 90, 160, 0.1);
            font-weight: 600;
            display: flex;
            align-items: center;
        }
        
        .section-title i {
            margin-left: 0.5rem;
            font-size: 1.3rem;
        }
        
        .form-group-enhanced {
            margin-bottom: 1.8rem;
        }
        
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 0.7rem;
            display: flex;
            align-items: center;
        }
        
        .form-control {
            border-radius: 12px;
            padding: 0.75rem 1rem;
            border: 1.5px solid #e1e5eb;
            transition: var(--transition);
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(44, 90, 160, 0.15);
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            top: 50%;
            right: 1rem;
            transform: translateY(-50%);
            color: #6c757d;
            font-size: 1.2rem;
        }
        
        .input-with-icon .form-control {
            padding-right: 3rem;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
        }
        
        .info-card {
            background: #f8fafc;
            border-radius: 12px;
            padding: 1.5rem;
            border-left: 4px solid var(--primary);
            transition: var(--transition);
        }
        
        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .info-card-title {
            font-weight: 600;
            color: #495057;
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
        }
        
        .info-card-value {
            color: var(--dark);
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .btn-back {
            background: rgba(44, 90, 160, 0.1);
            color: var(--primary);
            border: none;
            padding: 0.6rem 1.5rem;
            border-radius: 30px;
            font-weight: 600;
            transition: var(--transition);
        }
        
        .btn-back:hover {
            background: rgba(44, 90, 160, 0.2);
            color: var(--primary);
            transform: translateY(-2px);
        }
        
        .btn-save {
            background: linear-gradient(135deg, var(--primary), #1e4a8a);
            border: none;
            padding: 0.9rem 2.5rem;
            font-weight: 600;
            border-radius: 30px;
            font-size: 1.05rem;
            transition: var(--transition);
            box-shadow: 0 4px 15px rgba(44, 90, 160, 0.3);
        }
        
        .btn-save:hover {
            background: linear-gradient(135deg, #1e4a8a, var(--primary));
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(44, 90, 160, 0.4);
        }
        
        .alert-custom {
            border-radius: 12px;
            border: none;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
        }
        
        .alert-danger {
            background: linear-gradient(135deg, #ffebee, #ffcdd2);
            color: #b71c1c;
        }
        
        .alert-success {
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            color: #1b5e20;
        }
        
        @media (max-width: 768px) {
            .profile-container {
                margin: 1rem auto;
            }
            
            .profile-header {
                padding: 2rem 1.5rem;
            }
            
            .profile-body {
                padding: 1.8rem;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white">
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">
            
            <span>نظام التطوع - <?= htmlspecialchars($_SESSION['user_name']) ?></span>
        </a>
        <div class="d-flex align-items-center">
            <a href="dashboard.php" class="btn btn-back">
                <i class="bi bi-arrow-left me-1"></i> العودة للوحة التحكم
            </a>
           
        </div>
    </div>
</nav>

<div class="container profile-container">
    <?php if ($error): ?>
        <div class="alert alert-danger alert-custom alert-dismissible fade show" role="alert">
            <div class="d-flex align-items-center">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <div><?= htmlspecialchars($error) ?></div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-custom alert-dismissible fade show" role="alert">
            <div class="d-flex align-items-center">
                <i class="bi bi-check-circle-fill me-2"></i>
                <div><?= htmlspecialchars($success) ?></div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="profile-card">
        <div class="profile-header">
           
            <div class="profile-name"><?= htmlspecialchars($current_user['name']) ?></div>
            <div class="profile-role">مدير منظمة تطوعية</div>
            <?php if (!empty($current_user['organization_name'])): ?>
                <div class="profile-org"><?= htmlspecialchars($current_user['organization_name']) ?></div>
            <?php endif; ?>
        </div>
        
        <div class="profile-body">
            <div class="mb-5">
                <h4 class="section-title">
                    <i class="bi bi-person"></i>
                    معلومات الحساب الأساسية
                </h4>
                <form method="POST">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="form-group-enhanced">
                                <label for="name" class="form-label">
                                    <i class="bi bi-person me-1"></i>
                                    الاسم الكامل <span class="text-danger">*</span>
                                </label>
                                <div class="input-with-icon">
                                    <input type="text" id="name" name="name" class="form-control" 
                                           value="<?= htmlspecialchars($current_user['name']) ?>" required>
                                    <div class="input-icon">
                                        <i class="bi bi-person"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group-enhanced">
                                <label for="email" class="form-label">
                                    <i class="bi bi-envelope me-1"></i>
                                    البريد الإلكتروني <span class="text-danger">*</span>
                                </label>
                                <div class="input-with-icon">
                                    <input type="email" id="email" name="email" class="form-control" 
                                           value="<?= htmlspecialchars($current_user['email']) ?>" required>
                                    <div class="input-icon">
                                        <i class="bi bi-envelope"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group-enhanced">
                                <label for="organization_name" class="form-label">
                                    <i class="bi bi-building me-1"></i>
                                    اسم المنظمة
                                </label>
                                <div class="input-with-icon">
                                    <input type="text" id="organization_name" name="organization_name" class="form-control" 
                                           value="<?= htmlspecialchars($current_user['organization_name'] ?? '') ?>">
                                    <div class="input-icon">
                                        <i class="bi bi-building"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group-enhanced">
                                <label for="phone" class="form-label">
                                    <i class="bi bi-telephone me-1"></i>
                                    رقم الهاتف
                                </label>
                                <div class="input-with-icon">
                                    <input type="text" id="phone" name="phone" class="form-control" 
                                           value="<?= htmlspecialchars($current_user['phone'] ?? '') ?>">
                                    <div class="input-icon">
                                        <i class="bi bi-telephone"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4 pt-3">
                        <button type="submit" name="update_profile" class="btn btn-save">
                            <i class="bi bi-save me-2"></i> تحديث بيانات الملف الشخصي
                        </button>
                    </div>
                </form>
            </div>
            
            <div class="mt-5 pt-3">
                <h4 class="section-title">
                    <i class="bi bi-clock"></i>
                    معلومات النظام
                </h4>
                <div class="info-grid">
                    <div class="info-card">
                        <div class="info-card-title">تاريخ التسجيل</div>
                        <div class="info-card-value"><?= date('Y-m-d H:i', strtotime($current_user['created_at'])) ?></div>
                    </div>
                    <div class="info-card">
                        <div class="info-card-title">نوع الحساب</div>
                        <div class="info-card-value">مدير منظمة تطوعية</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

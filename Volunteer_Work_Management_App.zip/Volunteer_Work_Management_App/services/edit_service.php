<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

$error = '';
$success = '';

// التحقق من وجود مُعرّف الخدمة
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: services.php?error=معرف الخدمة غير صالح");
    exit();
}

$service_id = (int)$_GET['id'];

// جلب بيانات الخدمة
$stmt = $pdo->prepare("SELECT * FROM services WHERE id = ?");
$stmt->execute([$service_id]);
$service = $stmt->fetch();

if (!$service) {
    header("Location: services.php?error=الخدمة غير موجودة");
    exit();
}

// معالجة تحديث البيانات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'active';

    if (empty($name)) {
        $error = "يرجى إدخال اسم الخدمة.";
    } else {
        $stmt = $pdo->prepare("UPDATE services SET name = ?, description = ?, status = ? WHERE id = ?");
        $stmt->execute([$name, $description, $status, $service_id]);
        $success = "تم تحديث بيانات الخدمة بنجاح!";
        header("Location: services.php?success=" . urlencode($success));
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل خدمة - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .form-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <i class="bi bi-heart-pulse me-2 text-primary"></i>
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="services.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للخدمات
            </a>
            <a href="../logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-pencil-square me-2"></i> تعديل خدمة: <?= htmlspecialchars($service['name']) ?>
        </h2>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="form-card">
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">اسم الخدمة <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($service['name']) ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">الحالة الحالية</label>
                    <select name="status" class="form-select">
                        <option value="active" <?= $service['status'] === 'active' ? 'selected' : '' ?>>نشط</option>
                        <option value="inactive" <?= $service['status'] === 'inactive' ? 'selected' : '' ?>>غير نشط</option>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">الوصف</label>
                    <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($service['description']) ?></textarea>
                </div>
                <div class="col-12">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i> تحديث الخدمة
                        </button>
                        <a href="services.php" class="btn btn-secondary">
                            <i class="bi bi-x me-2"></i> إلغاء
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';


requireRole('org_admin');


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $request_id = (int)$_POST['request_id'];
    $new_status = $_POST['status'];
    
    if (in_array($new_status, ['accepted', 'rejected'])) {
        $stmt = $pdo->prepare("UPDATE help_requests SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $request_id]);
        $success = "تم تحديث حالة طلب المساعدة بنجاح!";
        header("Location: help_requests.php?success=" . urlencode($success));
        exit();
    }
}


$stmt = $pdo->prepare("
    SELECT hr.*, s.name as service_name
    FROM help_requests hr
    LEFT JOIN services s ON hr.service_id = s.id
    ORDER BY hr.submitted_at DESC
");
$stmt->execute();
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة طلبات المساعدة - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .request-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .request-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .status-accepted { background: rgba(40, 167, 69, 0.15); color: #155724; border: 1px solid #c3e6cb; }
        .status-rejected { background: rgba(220, 53, 69, 0.15); color: #721c24; border: 1px solid #f1b0b7; }
        
        .form-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
        }
        
        .status-badge {
            font-size: 0.85rem;
            padding: 0.4em 0.8em;
            border-radius: 20px;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
    </style>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
           
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="../dashboard.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للوحة التحكم
            </a>
            
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-question-circle me-2"></i> إدارة طلبات المساعدة
        </h2>
        <span class="badge bg-primary"><?= count($requests) ?> طلب</span>
    </div>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- عرض طلبات المساعدة -->
    <h4 class="mb-4"><i class="bi bi-list-ul me-2 text-primary"></i> قائمة طلبات المساعدة</h4>

    <?php if ($requests): ?>
        <div class="row g-4">
            <?php foreach ($requests as $request): ?>
                <div class="col-lg-6">
                    <div class="card request-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h5 class="card-title mb-1"><?= htmlspecialchars($request['requester_name']) ?></h5>
                                    <p class="text-muted mb-1">
                                        <i class="bi bi-telephone me-1"></i> <?= htmlspecialchars($request['requester_contact']) ?>
                                    </p>
                                </div>
                                <span class="status-badge <?= 'status-' . $request['status'] ?>">
                                    <?= $request['status'] === 'accepted' ? 'مقبول' : 'مرفوض' ?>
                                </span>
                            </div>
                            
                            <?php if ($request['service_name']): ?>
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <strong>الخدمة المطلوبة:</strong> <?= htmlspecialchars($request['service_name']) ?>
                                    </small>
                                </div>
                            <?php else: ?>
                                <div class="mb-2">
                                    <small class="text-muted">الخدمة المطلوبة: غير متوفرة</small>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($request['description']): ?>
                                <div class="mb-3">
                                    <small class="text-muted">
                                        <strong>الوصف:</strong><br>
                                        <?= htmlspecialchars($request['description']) ?>
                                    </small>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <small class="text-muted">
                                    <i class="bi bi-clock me-1"></i> <?= date('Y-m-d H:i', strtotime($request['submitted_at'])) ?>
                                </small>
                                
                                <div class="action-buttons">
                                    <!-- زر القبول -->
                                    <?php if ($request['status'] !== 'accepted'): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                            <input type="hidden" name="status" value="accepted">
                                            <button type="submit" name="update_status" class="btn btn-success btn-sm">
                                                <i class="bi bi-check-circle me-1"></i> قبول
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <!-- زر الرفض -->
                                    <?php if ($request['status'] !== 'rejected'): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                            <input type="hidden" name="status" value="rejected">
                                            <button type="submit" name="update_status" class="btn btn-danger btn-sm">
                                                <i class="bi bi-x-circle me-1"></i> رفض
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-question-circle fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد طلبات مساعدة حتى الآن</h4>
            <p class="text-muted">سيظهر هنا طلبات المساعدة التي يتلقاها المستفيدون.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

$error = '';
$success = '';

// التحقق من وجود مُعرّف الفرصة
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: volunteer_opportunities.php?error=معرف الفرصة غير صالح");
    exit();
}

$opportunity_id = (int)$_GET['id'];

// جلب المراكز النشطة
$centers = $pdo->query("SELECT id, name FROM centers WHERE status = 'active' ORDER BY name")->fetchAll();

// جلب بيانات الفرصة
$stmt = $pdo->prepare("
    SELECT vo.*, c.name as center_name 
    FROM volunteer_opportunities vo 
    LEFT JOIN centers c ON vo.center_id = c.id 
    WHERE vo.id = ?
");
$stmt->execute([$opportunity_id]);
$opportunity = $stmt->fetch();

if (!$opportunity) {
    header("Location: volunteer_opportunities.php?error=الفرصة غير موجودة");
    exit();
}

// معالجة تحديث البيانات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $center_id = !empty($_POST['center_id']) ? (int)$_POST['center_id'] : null;
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $status = $_POST['status'] ?? 'open';

    if (empty($title)) {
        $error = "يرجى إدخال عنوان الفرصة.";
    } elseif (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
        $error = "تاريخ الانتهاء يجب أن يكون بعد تاريخ البدء.";
    } else {
        $stmt = $pdo->prepare("UPDATE volunteer_opportunities SET title = ?, description = ?, center_id = ?, start_date = ?, end_date = ?, status = ? WHERE id = ?");
        $stmt->execute([$title, $description, $center_id, $start_date ?: null, $end_date ?: null, $status, $opportunity_id]);
        $success = "تم تحديث فرصة التطوع بنجاح!";
        header("Location: volunteer_opportunities.php?success=" . urlencode($success));
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل فرصة تطوع - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .form-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <i class="bi bi-heart-pulse me-2 text-primary"></i>
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="volunteer_opportunities.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للفرص
            </a>
            <a href="../logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-pencil-square me-2"></i> تعديل فرصة: <?= htmlspecialchars($opportunity['title']) ?>
        </h2>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="form-card">
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">عنوان الفرصة <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($opportunity['title']) ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">المركز التطوعي</label>
                    <select name="center_id" class="form-select">
                        <option value="">-- اختيار مركز --</option>
                        <?php foreach ($centers as $center): ?>
                            <option value="<?= $center['id'] ?>" <?= ($opportunity['center_id'] == $center['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($center['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">الوصف</label>
                    <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($opportunity['description']) ?></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">تاريخ البدء</label>
                    <input type="date" name="start_date" class="form-control" value="<?= $opportunity['start_date'] ? date('Y-m-d', strtotime($opportunity['start_date'])) : '' ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">تاريخ الانتهاء</label>
                    <input type="date" name="end_date" class="form-control" value="<?= $opportunity['end_date'] ? date('Y-m-d', strtotime($opportunity['end_date'])) : '' ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">الحالة الحالية</label>
                    <select name="status" class="form-select">
                        <option value="open" <?= $opportunity['status'] === 'open' ? 'selected' : '' ?>>مفتوح</option>
                        <option value="closed" <?= $opportunity['status'] === 'closed' ? 'selected' : '' ?>>مغلق</option>
                        <option value="full" <?= $opportunity['status'] === 'full' ? 'selected' : '' ?>>ممتلئ</option>
                    </select>
                </div>
                <div class="col-12">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i> تحديث الفرصة
                        </button>
                        <a href="volunteer_opportunities.php" class="btn btn-secondary">
                            <i class="bi bi-x me-2"></i> إلغاء
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

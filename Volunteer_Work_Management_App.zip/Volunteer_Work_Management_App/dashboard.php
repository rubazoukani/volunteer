<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';


requireRole('org_admin');


$stats = [
    'centers' => $pdo->query("SELECT COUNT(*) FROM centers")->fetchColumn(),
    'opportunities' => $pdo->query("SELECT COUNT(*) FROM volunteer_opportunities")->fetchColumn(),
    'training_opportunities' => $pdo->query("SELECT COUNT(*) FROM training_opportunities")->fetchColumn(),
    'requests' => $pdo->query("SELECT COUNT(*) FROM volunteer_requests")->fetchColumn(),
    'services' => $pdo->query("SELECT COUNT(*) FROM services")->fetchColumn(),
    'help_requests' => $pdo->query("SELECT COUNT(*) FROM help_requests")->fetchColumn(),
    'volunteers' => $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'volunteer'")->fetchColumn(),
];
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم المنظمة - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --primary-light: #4a76c5;
            --primary-dark: #1e3d73;
            --secondary: #28a745;
            --secondary-light: #34ce57;
            --accent: #ff6b35;
            --accent-light: #ff8c5a;
            --light: #f8f9fa;
            --dark: #343a40;
            --success: #28a745;
            --warning: #ffc107;
            --info: #17a2b8;
            --danger: #dc3545;
            --purple: #6f42c1;
            --orange: #fd7e14;
            --teal: #20c997;
            --tree-green: #2e8b57;
            --handshake: #e67e22;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            font-family: 'Segoe UI', 'Tajawal', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
       
        .dashboard-card {
            border: none;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            height: 100%;
            background: white;
            position: relative;
            overflow: hidden;
        }
        
        .dashboard-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }
        
        .dashboard-card:hover::before {
            transform: scaleX(1);
        }
        
        .card-icon {
            width: 70px;
            height: 70px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            transition: all 0.3s ease;
        }
        
        .dashboard-card:hover .card-icon {
            transform: scale(1.1);
        }
        
       
        .bg-primary-light { background: linear-gradient(135deg, rgba(44, 90, 160, 0.12), rgba(44, 90, 160, 0.08)); color: var(--primary); }
        .bg-success-light { background: linear-gradient(135deg, rgba(40, 167, 69, 0.12), rgba(40, 167, 69, 0.08)); color: var(--secondary); }
        .bg-warning-light { background: linear-gradient(135deg, rgba(255, 107, 53, 0.12), rgba(255, 107, 53, 0.08)); color: var(--accent); }
        .bg-info-light { background: linear-gradient(135deg, rgba(23, 162, 184, 0.12), rgba(23, 162, 184, 0.08)); color: var(--info); }
        .bg-danger-light { background: linear-gradient(135deg, rgba(220, 53, 69, 0.12), rgba(220, 53, 69, 0.08)); color: var(--danger); }
        .bg-purple-light { background: linear-gradient(135deg, rgba(111, 66, 193, 0.12), rgba(111, 66, 193, 0.08)); color: var(--purple); }
        .bg-orange-light { background: linear-gradient(135deg, rgba(253, 126, 20, 0.12), rgba(253, 126, 20, 0.08)); color: var(--orange); }
        .bg-teal-light { background: linear-gradient(135deg, rgba(32, 201, 151, 0.12), rgba(32, 201, 151, 0.08)); color: var(--teal); }
        .bg-tree-light { background: linear-gradient(135deg, rgba(46, 139, 87, 0.12), rgba(46, 139, 87, 0.08)); color: var(--tree-green); }
        .bg-handshake-light { background: linear-gradient(135deg, rgba(230, 126, 34, 0.12), rgba(230, 126, 34, 0.08)); color: var(--handshake); }
        
        
        .btn-action {
            border-radius: 12px;
            padding: 8px 16px;
            font-weight: 600;
            font-size: 0.85rem;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        
        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        
        .navbar {
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
        }
        
        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            background: linear-gradient(135deg, var(--tree-green), var(--handshake));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
      
        .welcome-title {
            font-weight: 800;
            background: linear-gradient(135deg, var(--tree-green), var(--handshake));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            position: relative;
            display: inline-block;
        }
        
        .welcome-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            right: 0;
            width: 60%;
            height: 4px;
            background: linear-gradient(90deg, var(--tree-green), var(--handshake));
            border-radius: 2px;
        }
        
        
        .stat-number {
            font-weight: 800;
            font-size: 2.2rem;
            line-height: 1;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
            font-weight: 600;
        }
        
        
        .pulse {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .floating {
            animation: floating 3s ease-in-out infinite;
        }
        
        @keyframes floating {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-8px); }
            100% { transform: translateY(0px); }
        }
        
        
        .logo-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--tree-green), var(--handshake));
            color: white;
            margin-left: 10px;
            font-size: 1.3rem;
        }
        
        
        @media (max-width: 768px) {
            .card-icon {
                width: 60px;
                height: 60px;
                font-size: 1.6rem;
            }
            
            .stat-number {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light sticky-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <span class="logo-icon">
                <i class="bi bi-tree-fill"></i>
            </span>
            نظام التطوع
        </a>
        <div class="d-flex align-items-center">
            <div class="dropdown me-3">
                <button class="btn btn-outline-primary dropdown-toggle btn-action" type="button" data-bs-toggle="dropdown">
                    <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($_SESSION['user_name']) ?>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i>الملف الشخصي</a></li>
                    
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>تسجيل الخروج</a></li>
                </ul>
            </div>
            <span class="badge bg-primary rounded-pill px-3 py-2">
                <i class="bi bi-building me-1"></i> مدير منظمة
            </span>
        </div>
    </div>
</nav>

<div class="container py-5">
    
    <div class="text-center mb-5">
        <h1 class="welcome-title display-5 fw-bold mb-3">لوحة تحكم منظمتك التطوعية</h1>
        <p class="lead text-muted mb-4">أدر عملك التطوعي بفعالية واحترافية من خلال الأدوات المتكاملة</p>
    </div>

   
    <div class="row g-4">
        
        <div class="col-md-6 col-lg-3">
            <div class="card dashboard-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="card-icon bg-primary-light me-3 pulse">
                            <i class="bi bi-building"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="stat-number text-primary"><?= $stats['centers'] ?></div>
                            <div class="stat-label">مراكز تطوعية</div>
                        </div>
                    </div>
                    <a href="centers/centers.php" class="btn btn-action btn-primary w-100">
                        <i class="bi bi-gear me-1"></i> إدارة المراكز
                    </a>
                </div>
            </div>
        </div>
        
        
        <div class="col-md-6 col-lg-3">
            <div class="card dashboard-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="card-icon bg-success-light me-3">
                            <i class="bi bi-hand-index-thumb"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="stat-number text-success"><?= $stats['opportunities'] ?></div>
                            <div class="stat-label">فرص تطوع</div>
                        </div>
                    </div>
                    <a href="volunteer_opportunities/volunteer_opportunities.php" class="btn btn-action btn-success w-100">
                        <i class="bi bi-plus-circle me-1"></i> إدارة الفرص
                    </a>
                </div>
            </div>
        </div>
        
        
        <div class="col-md-6 col-lg-3">
            <div class="card dashboard-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="card-icon bg-orange-light me-3">
                            <i class="bi bi-mortarboard"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="stat-number" style="color: var(--orange);"><?= $stats['training_opportunities'] ?></div>
                            <div class="stat-label">فرص تدريب</div>
                        </div>
                    </div>
                    <a href="training_opportunities/training_opportunities.php" class="btn btn-action w-100" style="background-color: var(--orange); border-color: var(--orange); color: white;">
                        <i class="bi bi-journal-bookmark me-1"></i> إدارة التدريب
                    </a>
                </div>
            </div>
        </div>
        
        <!-- بطاقة طلبات التطوع -->
        <div class="col-md-6 col-lg-3">
            <div class="card dashboard-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="card-icon bg-warning-light me-3">
                            <i class="bi bi-file-earmark-check"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="stat-number text-warning"><?= $stats['requests'] ?></div>
                            <div class="stat-label">طلبات تطوع</div>
                        </div>
                    </div>
                    <a href="volunteer_requests/volunteer_requests.php" class="btn btn-action btn-warning w-100">
                        <i class="bi bi-eye me-1"></i> عرض الطلبات
                    </a>
                </div>
            </div>
        </div>
        
        
        <div class="col-md-6 col-lg-3">
            <div class="card dashboard-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="card-icon bg-handshake-light me-3">
                            <i class="bi bi-people-fill"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="stat-number" style="color: var(--handshake);"><?= $stats['volunteers'] ?></div>
                            <div class="stat-label">المتطوعون</div>
                        </div>
                    </div>
                    <a href="volunteers/volunteers.php" class="btn btn-action w-100" style="background-color: var(--handshake); border-color: var(--handshake); color: white;">
                        <i class="bi bi-person-lines-fill me-1"></i> إدارة حسابات المتطوعون
                    </a>
                </div>
            </div>
        </div>
        
        
        <div class="col-md-6 col-lg-3">
            <div class="card dashboard-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="card-icon bg-info-light me-3">
                            <i class="bi bi-journal-text"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="stat-number text-info"><?= $stats['services'] ?></div>
                            <div class="stat-label">الخدمات المقدمة</div>
                        </div>
                    </div>
                    <a href="services/services.php" class="btn btn-action btn-info w-100">
                        <i class="bi bi-tools me-1"></i> إدارة الخدمات
                    </a>
                </div>
            </div>
        </div>
        
        
        <div class="col-md-6 col-lg-3">
            <div class="card dashboard-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="card-icon bg-danger-light me-3">
                            <i class="bi bi-question-circle-fill"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="stat-number text-danger"><?= $stats['help_requests'] ?></div>
                            <div class="stat-label">طلبات مساعدة</div>
                        </div>
                    </div>
                    <a href="help_requests/help_requests.php" class="btn btn-action btn-danger w-100">
                        <i class="bi bi-inbox me-1"></i> عرض الطلبات
                    </a>
                </div>
            </div>
        </div>
        
    
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    
    document.addEventListener('DOMContentLoaded', function() {
        
        const cards = document.querySelectorAll('.dashboard-card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });
        
        
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        cards.forEach(card => {
            observer.observe(card);
        });
    });
</script>
</body>
</html>
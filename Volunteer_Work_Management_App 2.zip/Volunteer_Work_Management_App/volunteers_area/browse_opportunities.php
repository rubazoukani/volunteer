<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('volunteer');

$stmt = $pdo->query("
    SELECT vo.*, c.name as center_name, c.city as center_city 
    FROM volunteer_opportunities vo
    LEFT JOIN centers c ON vo.center_id = c.id
    WHERE vo.status = 'open'
    ORDER BY vo.created_at DESC
");
$opportunities = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تصفح الفرص | بوابة المتطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .hero-section { background: linear-gradient(135deg, #4e73df 0%, #224abe 100%); color: white; padding: 40px 0; border-radius: 0 0 30px 30px; margin-bottom: 40px; }
        .opp-card { border: none; border-radius: 20px; transition: all 0.3s ease; overflow: hidden; }
        .opp-card:hover { transform: translateY(-10px); box-shadow: 0 15px 30px rgba(0,0,0,0.1); }
        .opp-badge { position: absolute; top: 15px; left: 15px; background: rgba(255,255,255,0.9); backdrop-filter: blur(5px); border-radius: 10px; padding: 5px 12px; font-size: 0.8rem; font-weight: bold; }
        .btn-apply { border-radius: 12px; font-weight: 600; padding: 10px; transition: 0.3s; }
        .info-item { font-size: 0.85rem; color: #5a5c69; margin-bottom: 8px; }
    </style>
</head>
<body>

<div class="hero-section shadow">
    <div class="container d-flex justify-content-between align-items-center">
        <div>
            <h2 class="fw-bold mb-1">استكشف الفرص المتاحة</h2>
            <p class="opacity-75 mb-0">ساهم في إحداث تغيير حقيقي في مجتمعك اليوم</p>
        </div>
        <a href="volunteer_dashboard.php" class="btn btn-light rounded-pill px-4"><i class="bi bi-house-door me-1"></i> الرئيسية</a>
    </div>
</div>

<div class="container mb-5">
    <div class="row g-4">
        <?php foreach ($opportunities as $opp): ?>
        <div class="col-md-6 col-lg-4">
            <div class="card opp-card h-100 shadow-sm">
                <div class="position-relative">
                    <div class="opp-badge text-primary shadow-sm"><i class="bi bi-geo-alt-fill"></i> <?= htmlspecialchars($opp['center_city']) ?></div>
                </div>
                <div class="card-body p-4">
                    <h5 class="fw-bold text-dark mb-3"><?= htmlspecialchars($opp['title']) ?></h5>
                    <div class="info-item"><i class="bi bi-building me-2 text-primary"></i> <?= htmlspecialchars($opp['center_name']) ?></div>
                    <div class="info-item"><i class="bi bi-calendar-event me-2 text-primary"></i> يبدأ في: <?= $opp['start_date'] ?></div>
                    <hr class="my-3 opacity-50">
                    <p class="card-text text-muted small" style="height: 4.5em; overflow: hidden;">
                        <?= nl2br(htmlspecialchars($opp['description'])) ?>
                    </p>
                </div>
                <div class="card-footer bg-white border-0 pb-4 px-4">
                    <a href="my_volunteer_requests.php?apply_id=<?= $opp['id'] ?>" class="btn btn-primary btn-apply w-100">
                        <i class="bi bi-send-fill me-2"></i> قدم الآن
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>
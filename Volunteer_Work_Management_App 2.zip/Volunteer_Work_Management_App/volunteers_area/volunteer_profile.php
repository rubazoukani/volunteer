<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// التأكد من أن المستخدم متطوع
requireRole('volunteer');

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// 1. جلب بيانات المتطوع الحالية
try {
    $stmt = $pdo->prepare("
        SELECT u.name, u.email, v.phone, v.city, v.skills, v.availability 
        FROM users u 
        LEFT JOIN volunteers v ON u.id = v.user_id 
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    $error = "حدث خطأ في جلب البيانات.";
}

// 2. معالجة تحديث البيانات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $city = trim($_POST['city']);
    $skills = trim($_POST['skills']);
    $availability = trim($_POST['availability']);

    try {
        $pdo->beginTransaction();

        // تحديث جدول المستخدمين (الاسم)
        $updateUser = $pdo->prepare("UPDATE users SET name = ? WHERE id = ?");
        $updateUser->execute([$name, $user_id]);

        // التحقق إذا كان للمتطوع سجل في جدول volunteers
        $checkVol = $pdo->prepare("SELECT id FROM volunteers WHERE user_id = ?");
        $checkVol->execute([$user_id]);

        if ($checkVol->fetch()) {
            // تحديث البيانات الموجودة
            $updateVol = $pdo->prepare("UPDATE volunteers SET phone = ?, city = ?, skills = ?, availability = ? WHERE user_id = ?");
            $updateVol->execute([$phone, $city, $skills, $availability, $user_id]);
        } else {
            // إضافة سجل جديد في حال عدم وجوده
            $insertVol = $pdo->prepare("INSERT INTO volunteers (user_id, phone, city, skills, availability) VALUES (?, ?, ?, ?, ?)");
            $insertVol->execute([$user_id, $phone, $city, $skills, $availability]);
        }

        $pdo->commit();
        $success = "تم تحديث ملفك الشخصي بنجاح.";
        $_SESSION['user_name'] = $name; // تحديث الاسم في الجلسة
        
        // تحديث البيانات المعروضة في الصفحة
        $user['name'] = $name;
        $user['phone'] = $phone;
        $user['city'] = $city;
        $user['skills'] = $skills;
        $user['availability'] = $availability;

    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "عذراً، تعذر حفظ التغييرات. يرجى المحاولة لاحقاً.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الملف الشخصي | بوابة المتطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --primary-blue: #4e73df; --secondary-bg: #f8f9fc; }
        body { background-color: var(--secondary-bg); font-family: 'Segoe UI', Tahoma, sans-serif; }
        .profile-card { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
        .avatar-circle { width: 100px; height: 100px; background: linear-gradient(135deg, #4e73df 0%, #224abe 100%); color: white; font-size: 40px; display: flex; align-items: center; justify-content: center; border-radius: 50%; margin: 0 auto 20px; }
        .form-control { border-radius: 10px; padding: 12px; border: 1px solid #e3e6f0; }
        .form-control:focus { box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.1); border-color: var(--primary-blue); }
        .btn-save { background: var(--primary-blue); border: none; border-radius: 10px; padding: 12px; font-weight: bold; transition: 0.3s; }
        .btn-save:hover { background: #2e59d9; transform: translateY(-2px); }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-primary shadow-sm mb-5">
    <div class="container">
        <a class="navbar-brand fw-bold" href="volunteer_dashboard.php">
            <i class="bi bi-arrow-right-circle me-2"></i> عودة للوحة التحكم
        </a>
    </div>
</nav>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card profile-card p-4 p-md-5">
                <div class="text-center">
                    <div class="avatar-circle">
                        <?= mb_substr(htmlspecialchars($user['name']), 0, 1, 'utf-8') ?>
                    </div>
                    <h3 class="fw-bold text-gray-800"><?= htmlspecialchars($user['name']) ?></h3>
                    <p class="text-muted mb-4"><?= htmlspecialchars($user['email']) ?></p>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <form method="POST" class="mt-4">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">الاسم الكامل</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="bi bi-person text-primary"></i></span>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">رقم الهاتف</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="bi bi-phone text-primary"></i></span>
                                <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="09xxxxxxxx">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">المدينة</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="bi bi-geo-alt text-primary"></i></span>
                                <input type="text" name="city" class="form-control" value="<?= htmlspecialchars($user['city'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">أوقات التوافر</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="bi bi-clock text-primary"></i></span>
                                <input type="text" name="availability" class="form-control" value="<?= htmlspecialchars($user['availability'] ?? '') ?>" placeholder="مثلاً: يومياً بعد الظهر">
                            </div>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">المهارات والخبرات</label>
                            <textarea name="skills" class="form-control" rows="4" placeholder="اذكر مهاراتك (مثلاً: برمجة، إسعافات أولية، تنظيم فعاليات...)"><?= htmlspecialchars($user['skills'] ?? '') ?></textarea>
                        </div>
                    </div>

                    <div class="mt-5">
                        <button type="submit" class="btn btn-primary btn-save w-100 text-white">
                            <i class="bi bi-cloud-arrow-up me-2"></i> حفظ التغييرات الأساسية
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
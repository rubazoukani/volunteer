<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// التأكد من أن المستخدم متطوع
requireRole('volunteer');

$user_id = $_SESSION['user_id'];
$success = ''; 
$error = '';

// 1. معالجة التقديم على فرصة تدريب (إذا تم إرسال المعرف عبر الرابط)
if (isset($_GET['apply_training_id'])) {
    $t_id = (int)$_GET['apply_training_id'];
    
    // التحقق من عدم وجود طلب سابق لنفس المتطوع ونفس التدريب
    $check = $pdo->prepare("SELECT id FROM training_requests WHERE user_id = ? AND training_id = ?");
    $check->execute([$user_id, $t_id]);
    
    if ($check->fetch()) {
        $error = "لقد سجلت في هذا البرنامج التدريبي مسبقاً.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO training_requests (user_id, training_id, status, submitted_at) VALUES (?, ?, 'pending', NOW())");
        $stmt->execute([$user_id, $t_id]);
        $success = "تم إرسال طلب الانضمام للتدريب بنجاح!";
    }
}

// 2. جلب سجل طلبات التدريب الخاصة بالمتطوع الحالي
$stmt = $pdo->prepare("
    SELECT tr.*, topt.title as t_title, c.name as center_name 
    FROM training_requests tr
    JOIN training_opportunities topt ON tr.training_id = topt.id
    LEFT JOIN centers c ON topt.center_id = c.id
    WHERE tr.user_id = ? 
    ORDER BY tr.submitted_at DESC
");
$stmt->execute([$user_id]);
$my_requests = $stmt->fetchAll(PDO::FETCH_ASSOC); // تم تعريف المتغير هنا باسم $my_requests لإصلاح الخطأ
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>سجل طلبات التدريب | بوابة المتطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fc; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .page-header { background: linear-gradient(135deg, #1cc88a 0%, #13855c 100%); color: white; padding: 40px 0; border-radius: 0 0 30px 30px; margin-bottom: 30px; }
        .request-card { border: none; border-radius: 15px; transition: 0.3s; background: white; border-right: 5px solid #1cc88a; }
        .request-card:hover { transform: scale(1.01); box-shadow: 0 10px 20px rgba(0,0,0,0.05); }
        .status-badge { border-radius: 8px; padding: 6px 12px; font-weight: 600; font-size: 0.85rem; }
        .bg-pending { background-color: #fff9e6; color: #f6c23e; }
        .bg-approved { background-color: #e6f9ed; color: #1cc88a; }
        .bg-rejected { background-color: #fbeaea; color: #e74a3b; }
    </style>
</head>
<body>

<div class="page-header shadow">
    <div class="container d-flex justify-content-between align-items-center">
        <div>
            <h2 class="fw-bold mb-1"><i class="bi bi-mortarboard-fill me-2"></i> سجل طلبات التدريب</h2>
            <p class="opacity-75 mb-0">تابع حالة طلباتك في البرامج التدريبية المختلفة</p>
        </div>
        <a href="volunteer_dashboard.php" class="btn btn-light rounded-pill px-4 fw-bold">العودة للوحة التحكم</a>
    </div>
</div>

<div class="container pb-5">
    <?php if($success): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4">
            <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm mb-4">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-12">
            <?php if (!empty($my_requests)): ?>
                <?php foreach ($my_requests as $req): ?>
                    <div class="card request-card shadow-sm mb-3">
                        <div class="card-body d-flex flex-wrap justify-content-between align-items-center">
                            <div class="d-flex align-items-center mb-3 mb-md-0">
                                <div class="bg-success-subtle text-success p-3 rounded-circle me-3 d-flex align-items-center justify-content-center" style="width: 55px; height: 55px;">
                                    <i class="bi bi-journal-text fs-4"></i>
                                </div>
                                <div>
                                    <h5 class="fw-bold mb-1"><?= htmlspecialchars($req['t_title']) ?></h5>
                                    <div class="text-muted small">
                                        <i class="bi bi-building me-1"></i> <?= htmlspecialchars($req['center_name'] ?? 'مركز غير محدد') ?>
                                        <span class="mx-2">|</span>
                                        <i class="bi bi-calendar3 me-1"></i> <?= date('Y-m-d', strtotime($req['submitted_at'])) ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="text-center">
                                <?php 
                                    $status = $req['status'];
                                    $badge_class = ($status == 'approved') ? 'bg-approved' : (($status == 'rejected') ? 'bg-rejected' : 'bg-pending');
                                    $status_text = ($status == 'approved') ? 'مقبول' : (($status == 'rejected') ? 'مرفوض' : 'قيد الانتظار');
                                    $status_icon = ($status == 'approved') ? 'check-circle' : (($status == 'rejected') ? 'x-circle' : 'clock-history');
                                ?>
                                <div class="status-badge <?= $badge_class ?>">
                                    <i class="bi bi-<?= $status_icon ?> me-1"></i> <?= $status_text ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="text-center py-5 bg-white rounded-4 shadow-sm">
                    <i class="bi bi-inbox fs-1 text-muted opacity-25"></i>
                    <p class="text-muted mt-3">لا توجد طلبات تدريب مسجلة حالياً.</p>
                    <a href="browse_training.php" class="btn btn-primary rounded-pill mt-2">استكشف برامج التدريب</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
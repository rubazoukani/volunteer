<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// التأكد من أن المستخدم متطوع
requireRole('volunteer');

$user_id = $_SESSION['user_id'];

// جلب الإحصائيات لعرضها داخل البطاقات
try {
    $v_req_count = $pdo->query("SELECT COUNT(*) FROM volunteer_requests WHERE user_id = $user_id")->fetchColumn() ?: 0;
    $t_req_count = $pdo->query("SELECT COUNT(*) FROM training_requests WHERE user_id = $user_id")->fetchColumn() ?: 0;
    $opps_count = $pdo->query("SELECT COUNT(*) FROM volunteer_opportunities WHERE status = 'open'")->fetchColumn() ?: 0;
    $train_count = $pdo->query("SELECT COUNT(*) FROM training_opportunities WHERE status = 'open'")->fetchColumn() ?: 0;
    $orgs_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'org_admin' AND status = 'active'")->fetchColumn() ?: 0;
    $centers_count = $pdo->query("SELECT COUNT(*) FROM centers WHERE status = 'active'")->fetchColumn() ?: 0;
} catch (Exception $e) {
    $v_req_count = $t_req_count = $opps_count = $train_count = $orgs_count = $centers_count = 0;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة تحكم المتطوع | نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --primary-gradient: linear-gradient(135deg, #4e73df 0%, #224abe 100%); }
        body { background-color: #f8f9fc; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .navbar { background: var(--primary-gradient); box-shadow: 0 2px 15px rgba(0,0,0,0.1); }
        .welcome-section { background: white; border-radius: 15px; padding: 30px; margin-bottom: 30px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        .dash-card { border: none; border-radius: 20px; transition: all 0.3s ease; height: 100%; cursor: pointer; background: white; }
        .dash-card:hover { transform: translateY(-10px); box-shadow: 0 15px 30px rgba(0,0,0,0.1); border: 1px solid #4e73df; }
        .icon-circle { width: 60px; height: 60px; border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 28px; margin-bottom: 20px; }
        .badge-count { position: absolute; top: 20px; left: 20px; font-size: 0.9rem; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-person-workspace me-2"></i> بوابة المتطوع</a>
        <div class="d-flex align-items-center text-white">
            <a href="volunteer_profile.php" class="text-white text-decoration-none me-3">
                <i class="bi bi-person-circle"></i> <?= htmlspecialchars($_SESSION['user_name']) ?>
            </a>
            <a href="../logout.php" class="btn btn-sm btn-outline-light">خروج</a>
        </div>
    </div>
</nav>

<div class="container pb-5">
    <div class="welcome-section d-flex justify-content-between align-items-center">
        <div>
            <h2 class="fw-bold text-dark">مرحباً بك مجدداً!</h2>
            <p class="text-muted mb-0">يمكنك إدارة نشاطاتك التطوعية والتدريبية من هنا.</p>
        </div>
        <div class="text-end d-none d-md-block">
            <span class="badge bg-primary rounded-pill px-3 py-2">حساب متطوع نشط</span>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card dash-card p-4" onclick="location.href='browse_opportunities.php'">
                <span class="badge bg-primary badge-count"><?= $opps_count ?> متاح</span>
                <div class="icon-circle bg-primary-subtle text-primary"><i class="bi bi-megaphone"></i></div>
                <h5 class="fw-bold">فرص التطوع</h5>
                <p class="text-muted small">تصفح وقدم على أحدث الفرص التطوعية المتاحة حالياً.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card dash-card p-4" onclick="location.href='browse_training.php'">
                <span class="badge bg-success badge-count"><?= $train_count ?> دورة</span>
                <div class="icon-circle bg-success-subtle text-success"><i class="bi bi-mortarboard"></i></div>
                <h5 class="fw-bold">فرص التدريب</h5>
                <p class="text-muted small">طور مهاراتك من خلال البرامج التدريبية المخصصة للمتطوعين.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card dash-card p-4" onclick="location.href='browse_organizations.php'">
                <span class="badge bg-info badge-count"><?= $orgs_count ?> منظمة</span>
                <div class="icon-circle bg-info-subtle text-info"><i class="bi bi-building"></i></div>
                <h5 class="fw-bold">المنظمات التطوعية</h5>
                <p class="text-muted small">تعرف على المنظمات والخدمات والنشاطات التي تقدمها.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card dash-card p-4" onclick="location.href='browse_centers.php'">
                <span class="badge bg-danger badge-count"><?= $centers_count ?> مركز</span>
                <div class="icon-circle bg-danger-subtle text-danger"><i class="bi bi-geo-alt"></i></div>
                <h5 class="fw-bold">المراكز التطوعية</h5>
                <p class="text-muted small">استكشف مواقع المراكز التابعة لنا في مختلف المدن.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card dash-card p-4" onclick="location.href='my_volunteer_requests.php'">
                <span class="badge bg-warning text-dark badge-count"><?= $v_req_count ?> طلب</span>
                <div class="icon-circle bg-warning-subtle text-warning"><i class="bi bi-journal-text"></i></div>
                <h5 class="fw-bold">سجل طلبات التطوع</h5>
                <p class="text-muted small">تابع حالة طلبات الانضمام للفرص التي قدمت عليها.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card dash-card p-4" onclick="location.href='my_training_requests.php'">
                <span class="badge bg-secondary badge-count"><?= $t_req_count ?> طلب</span>
                <div class="icon-circle bg-secondary-subtle text-secondary"><i class="bi bi-clock-history"></i></div>
                <h5 class="fw-bold">سجل طلبات التدريب</h5>
                <p class="text-muted small">مراجعة تاريخ وحالة طلباتك للبرامج التدريبية.</p>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card dash-card p-4 border-start border-primary border-5" onclick="location.href='volunteer_profile.php'">
                <div class="d-flex align-items-center">
                    <div class="icon-circle bg-dark text-white mb-0 me-3"><i class="bi bi-person-gear"></i></div>
                    <div>
                        <h5 class="fw-bold mb-1">إدارة الملف الشخصي</h5>
                        <p class="text-muted mb-0 small">تحديث بياناتك الشخصية، مهاراتك، وأوقات توافرك.</p>
                    </div>
                    <i class="bi bi-chevron-left ms-auto fs-4 text-muted"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
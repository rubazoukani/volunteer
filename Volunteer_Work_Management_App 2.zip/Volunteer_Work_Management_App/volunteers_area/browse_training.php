<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('volunteer');

$stmt = $pdo->query("SELECT topt.*, c.name as center_name FROM training_opportunities topt LEFT JOIN centers c ON topt.center_id = c.id WHERE topt.status = 'open' ORDER BY topt.id DESC");
$trainings = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>البرامج التدريبية | بوابة المتطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fc; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .hero-header { background: linear-gradient(135deg, #1cc88a 0%, #13855c 100%); color: white; padding: 40px 0; border-radius: 0 0 30px 30px; margin-bottom: 30px; }
        .train-card { border: none; border-radius: 20px; transition: 0.3s; overflow: hidden; background: white; }
        .train-card:hover { transform: translateY(-10px); box-shadow: 0 15px 30px rgba(0,0,0,0.1); }
        .btn-apply { border-radius: 12px; font-weight: bold; background: #1cc88a; border: none; color: white; }
        .btn-apply:hover { background: #17a673; }
    </style>
</head>
<body>
<div class="hero-header shadow">
    <div class="container d-flex justify-content-between align-items-center">
        <div><h2 class="fw-bold mb-1">البرامج التدريبية المتاحة</h2><p class="opacity-75 mb-0">نمِّ مهاراتك وانطلق في مسيرتك التطوعية</p></div>
        <a href="volunteer_dashboard.php" class="btn btn-light rounded-pill px-4 fw-bold">الرئيسية</a>
    </div>
</div>
<div class="container mb-5">
    <div class="row g-4">
        <?php foreach ($trainings as $t): ?>
        <div class="col-md-6 col-lg-4">
            <div class="card train-card h-100 shadow-sm">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between mb-3">
                        <span class="badge bg-success-subtle text-success px-3 py-2 rounded-pill small">دورة تدريبية</span>
                        <i class="bi bi-mortarboard fs-3 text-success"></i>
                    </div>
                    <h5 class="fw-bold mb-3"><?= htmlspecialchars($t['title']) ?></h5>
                    <p class="text-muted small mb-4" style="height: 4.5em; overflow: hidden;"><?= htmlspecialchars($t['description']) ?></p>
                    <div class="small text-dark mb-1"><i class="bi bi-geo-alt me-1 text-danger"></i> <?= htmlspecialchars($t['center_name'] ?? 'مركز عام') ?></div>
                </div>
                <div class="card-footer bg-white border-0 pb-4 px-4">
                    <a href="my_training_requests.php?apply_training_id=<?= $t['id'] ?>" class="btn btn-apply w-100 py-2">سجل في التدريب الآن</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>
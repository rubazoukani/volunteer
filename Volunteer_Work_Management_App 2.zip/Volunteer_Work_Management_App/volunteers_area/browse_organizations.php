<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

requireRole('volunteer');

// 1. جلب المنظمات (مدراء المنظمات)
$stmt = $pdo->query("SELECT id, organization_name, name as manager_name, email FROM users WHERE role = 'org_admin' AND status = 'active'");
$organizations = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>المنظمات والخدمات | بوابة المتطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fc; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .hero-header { background: linear-gradient(135deg, #4e73df 0%, #224abe 100%); color: white; padding: 40px 0; border-radius: 0 0 30px 30px; margin-bottom: 40px; }
        .org-card { border: none; border-radius: 20px; transition: 0.3s; background: white; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-bottom: 20px; }
        .service-item { background: #f8f9fc; border-radius: 12px; padding: 15px; margin-bottom: 10px; border-right: 4px solid #4e73df; }
        .accordion-button:not(.collapsed) { background-color: #f1f4ff; color: #4e73df; font-weight: bold; }
    </style>
</head>
<body>

<div class="hero-header shadow">
    <div class="container d-flex justify-content-between align-items-center">
        <div>
            <h2 class="fw-bold mb-1"><i class="bi bi-building-check me-2"></i> المنظمات والخدمات المتاحة</h2>
            <p class="opacity-75 mb-0">استعراض كافة المنظمات التطوعية والخدمات التي تقدمها</p>
        </div>
        <a href="volunteer_dashboard.php" class="btn btn-light rounded-pill px-4 fw-bold">العودة للرئيسية</a>
    </div>
</div>

<div class="container pb-5">
    <div class="row g-4">
        <?php if ($organizations): ?>
            <?php foreach ($organizations as $org): ?>
                <div class="col-lg-6">
                    <div class="card org-card">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center mb-4">
                                <div class="bg-primary text-white rounded-circle p-3 me-3" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                                    <i class="bi bi-building"></i>
                                </div>
                                <div>
                                    <h4 class="fw-bold mb-0 text-primary"><?= htmlspecialchars($org['organization_name']) ?></h4>
                                    <small class="text-muted">المدير المسؤول: <?= htmlspecialchars($org['manager_name']) ?></small>
                                </div>
                            </div>

                            <div class="accordion border-0" id="acc<?= $org['id'] ?>">
                                <div class="accordion-item border-0 shadow-none">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed rounded-3 shadow-sm" type="button" data-bs-toggle="collapse" data-bs-target="#serv<?= $org['id'] ?>">
                                            <i class="bi bi-gear-wide me-2"></i> عرض الخدمات التي نقدمها
                                        </button>
                                    </h2>
                                    <div id="serv<?= $org['id'] ?>" class="accordion-collapse collapse" data-bs-parent="#acc<?= $org['id'] ?>">
                                        <div class="accordion-body px-0 pt-3">
                                            <?php
                                            // ملاحظة هامة: تم الربط هنا باستخدام id مدير المنظمة
                                            $stmt_services = $pdo->prepare("SELECT name, description FROM services WHERE user_id = ?");
                                            $stmt_services->execute([$org['id']]);
                                            $services = $stmt_services->fetchAll();

                                            if ($services):
                                                foreach ($services as $service): ?>
                                                <div class="service-item">
                                                    <h6 class="fw-bold text-dark mb-1"><?= htmlspecialchars($service['name']) ?></h6>
                                                    <p class="small text-muted mb-0"><?= htmlspecialchars($service['description']) ?></p>
                                                </div>
                                            <?php endforeach; else: ?>
                                                <div class="alert alert-light text-center small border-0 py-3">
                                                    <i class="bi bi-info-circle me-1"></i> لا توجد خدمات مضافة لهذه المنظمة في قاعدة البيانات.
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted h5">لا توجد منظمات نشطة حالياً.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('volunteer');

$user_id = $_SESSION['user_id'];
$success = ''; $error = '';

// تقديم طلب جديد إذا أرسل المعرف عبر الرابط
if (isset($_GET['apply_id'])) {
    $opp_id = (int)$_GET['apply_id'];
    // التحقق من عدم وجود طلب سابق
    $check = $pdo->prepare("SELECT id FROM volunteer_requests WHERE user_id = ? AND opportunity_id = ?");
    $check->execute([$user_id, $opp_id]);
    
    if ($check->fetch()) {
        $error = "لقد تقدمت لهذه الفرصة مسبقاً.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO volunteer_requests (user_id, opportunity_id, user_name, user_email, status) 
                               VALUES (?, ?, ?, ?, 'pending')");
        $stmt->execute([$user_id, $opp_id, $_SESSION['user_name'], $_SESSION['user_email']]);
        $success = "تم تقديم طلب التطوع بنجاح! يمكنك تتبع الحالة هنا.";
    }
}

// جلب سجل الطلبات
$stmt = $pdo->prepare("
    SELECT vr.*, vo.title as opp_title, c.name as center_name 
    FROM volunteer_requests vr
    JOIN volunteer_opportunities vo ON vr.opportunity_id = vo.id
    LEFT JOIN centers c ON vo.center_id = c.id
    WHERE vr.user_id = ?
    ORDER BY vr.submitted_at DESC
");
$stmt->execute([$user_id]);
$my_requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>طلباتي التطوعية | بوابة المتطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fc; font-family: 'Segoe UI', sans-serif; }
        .header-bg { background: linear-gradient(135deg, #4e73df 0%, #224abe 100%); color: white; padding: 40px 0; border-radius: 0 0 30px 30px; }
        .request-item { border: none; border-radius: 15px; margin-bottom: 15px; border-right: 5px solid #4e73df; transition: 0.3s; }
        .request-item:hover { transform: scale(1.01); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .status-badge { border-radius: 10px; padding: 8px 15px; font-weight: bold; }
    </style>
</head>
<body>
<div class="header-bg shadow mb-4">
    <div class="container d-flex justify-content-between align-items-center">
        <h2 class="fw-bold m-0">سجل طلبات التطوع</h2>
        <a href="volunteer_dashboard.php" class="btn btn-outline-light rounded-pill px-4">عودة</a>
    </div>
</div>
<div class="container">
    <?php foreach ($my_requests as $req): 
        $status_map = [
            'pending' => ['text' => 'قيد الانتظار', 'class' => 'bg-warning-subtle text-warning', 'icon' => 'clock'],
            'approved' => ['text' => 'تم القبول', 'class' => 'bg-success-subtle text-success', 'icon' => 'check-circle'],
            'rejected' => ['text' => 'مرفوض', 'class' => 'bg-danger-subtle text-danger', 'icon' => 'x-circle']
        ];
        $st = $status_map[$req['status']] ?? $status_map['pending'];
    ?>
    <div class="card request-item shadow-sm">
        <div class="card-body d-flex justify-content-between align-items-center p-4">
            <div class="d-flex align-items-center">
                <div class="p-3 bg-light rounded-circle me-3 text-primary fs-4"><i class="bi bi-clipboard-check"></i></div>
                <div>
                    <h5 class="fw-bold mb-1"><?= htmlspecialchars($req['opp_title']) ?></h5>
                    <small class="text-muted"><i class="bi bi-building me-1"></i> <?= htmlspecialchars($req['center_name'] ?? 'مركز عام') ?> | <i class="bi bi-calendar me-1"></i> <?= $req['submitted_at'] ?></small>
                </div>
            </div>
            <div class="status-badge <?= $st['class'] ?>"><i class="bi bi-<?= $st['icon'] ?> me-2"></i> <?= $st['text'] ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
</body>
</html>
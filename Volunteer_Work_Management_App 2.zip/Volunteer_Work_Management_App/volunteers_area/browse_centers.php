<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('volunteer');

$stmt = $pdo->query("SELECT * FROM centers WHERE status = 'active' ORDER BY city ASC");
$centers = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>المراكز التطوعية | بوابة المتطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fc; font-family: 'Segoe UI', sans-serif; }
        .center-card { border: none; border-radius: 20px; border-top: 5px solid #e74a3b; transition: 0.3s; height: 100%; }
        .center-card:hover { transform: scale(1.03); box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
        .city-tag { background: #fbeaea; color: #e74a3b; border-radius: 8px; padding: 4px 12px; font-weight: bold; font-size: 0.8rem; }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-5">
        <h2 class="fw-bold text-dark border-start border-4 border-danger ps-3">مراكزنا التطوعية</h2>
        <a href="volunteer_dashboard.php" class="btn btn-secondary rounded-pill">عودة للرئيسية</a>
    </div>
    <div class="row g-4">
        <?php foreach ($centers as $c): ?>
        <div class="col-md-6 col-lg-4">
            <div class="card center-card shadow-sm p-4">
                <div class="d-flex justify-content-between mb-3">
                    <span class="city-tag"><i class="bi bi-geo-alt me-1"></i> <?= htmlspecialchars($c['city']) ?></span>
                    <i class="bi bi-hospital text-danger fs-3"></i>
                </div>
                <h5 class="fw-bold mb-2"><?= htmlspecialchars($c['name']) ?></h5>
                <p class="text-muted small mb-0">
                    <i class="bi bi-map me-2"></i> 
                    <?= htmlspecialchars($c['location'] ?? 'العنوان غير متوفر حالياً') ?>
                </p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>
<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('volunteer');

$stmt = $pdo->query("SELECT * FROM services WHERE status = 'active'");
$services = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>خدمات المنظمات</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>الخدمات التي تقدمها المنظمات</h2>
            <a href="volunteer_dashboard.php" class="btn btn-secondary">عودة</a>
        </div>
        <div class="row">
            <?php foreach ($services as $s): ?>
            <div class="col-md-4 mb-3">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body">
                        <h6 class="fw-bold text-primary"><?= htmlspecialchars($s['name']) ?></h6>
                        <p class="small text-muted"><?= htmlspecialchars($s['description']) ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
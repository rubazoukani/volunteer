<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

// التحقق من وجود مُعرّف الفرصة
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: volunteer_opportunities.php?error=معرف الفرصة غير صالح");
    exit();
}

$opportunity_id = (int)$_GET['id'];

// جلب بيانات الفرصة للعرض
$stmt = $pdo->prepare("
    SELECT vo.*, c.name as center_name 
    FROM volunteer_opportunities vo 
    LEFT JOIN centers c ON vo.center_id = c.id 
    WHERE vo.id = ?
");
$stmt->execute([$opportunity_id]);
$opportunity = $stmt->fetch();

if (!$opportunity) {
    header("Location: volunteer_opportunities.php?error=الفرصة غير موجودة");
    exit();
}

// التحقق من وجود طلبات مرتبطة
$requests_count = $pdo->prepare("SELECT COUNT(*) FROM volunteer_requests WHERE opportunity_id = ?");
$requests_count->execute([$opportunity_id]);
$linked_requests = $requests_count->fetchColumn();

// معالجة تأكيد الحذف
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    try {
        // سيتم حذف الطلبات المرتبطة تلقائيًا بسبب ON DELETE CASCADE
        $stmt = $pdo->prepare("DELETE FROM volunteer_opportunities WHERE id = ?");
        $stmt->execute([$opportunity_id]);
        
        header("Location: volunteer_opportunities.php?success=تم حذف فرصة التطوع بنجاح!");
        exit();
    } catch (Exception $e) {
        $error = "حدث خطأ أثناء حذف الفرصة: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حذف فرصة تطوع - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --danger: #dc3545;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .delete-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            border-top: 4px solid var(--danger);
        }
        
        .warning-box {
            background-color: rgba(220, 53, 69, 0.1);
            border: 1px solid var(--danger);
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
        }
        
        .btn-danger {
            background-color: var(--danger);
            border-color: var(--danger);
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <i class="bi bi-heart-pulse me-2 text-primary"></i>
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="volunteer_opportunities.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للفرص
            </a>
            <a href="../logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-danger fw-bold">
            <i class="bi bi-trash me-2"></i> تأكيد حذف فرصة تطوع
        </h2>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="delete-card">
        <div class="text-center mb-4">
            <div class="bg-danger bg-opacity-10 d-inline-flex p-3 rounded-circle mb-3">
                <i class="bi bi-exclamation-triangle fs-1 text-danger"></i>
            </div>
            <h4 class="text-danger">هل أنت متأكد من حذف هذه الفرصة؟</h4>
            <p class="text-muted">هذا الإجراء لا يمكن التراجع عنه، وستحذف جميع الطلبات المرتبطة بها.</p>
        </div>

        <!-- معلومات الفرصة -->
        <div class="row mb-4">
            <div class="col-md-6">
                <h5>معلومات الفرصة</h5>
                <ul class="list-unstyled">
                    <li><strong>العنوان:</strong> <?= htmlspecialchars($opportunity['title']) ?></li>
                    <li><strong>المركز:</strong> <?= htmlspecialchars($opportunity['center_name'] ?: 'غير محدد') ?></li>
                    <li><strong>الحالة:</strong> 
                        <span class="badge <?= 
                            $opportunity['status'] === 'open' ? 'bg-success' : 
                            ($opportunity['status'] === 'closed' ? 'bg-warning' : 'bg-danger') 
                        ?>">
                            <?php 
                            if ($opportunity['status'] === 'open') echo 'مفتوح';
                            elseif ($opportunity['status'] === 'closed') echo 'مغلق';
                            else echo 'ممتلئ';
                            ?>
                        </span>
                    </li>
                    <?php if ($opportunity['start_date']): ?>
                        <li><strong>الفترة:</strong> 
                            <?= date('Y-m-d', strtotime($opportunity['start_date'])) ?>
                            <?php if ($opportunity['end_date']): ?>
                                - <?= date('Y-m-d', strtotime($opportunity['end_date'])) ?>
                            <?php endif; ?>
                        </li>
                    <?php endif; ?>
                    <li><strong>تاريخ الإنشاء:</strong> <?= date('Y-m-d', strtotime($opportunity['created_at'])) ?></li>
                </ul>
            </div>
            
            <?php if ($linked_requests > 0): ?>
            <div class="col-md-6">
                <div class="warning-box">
                    <h5 class="text-danger"><i class="bi bi-link-45deg me-2"></i> تحذير: طلبات مرتبطة</h5>
                    <p>هذه الفرصة مرتبط بها <strong><?= $linked_requests ?> طلب تطوع</strong>.</p>
                    <p class="mt-2 mb-0">
                        <small class="text-muted">
                            سيتم حذف جميع الطلبات المرتبطة بهذه الفرصة بشكل دائم.
                        </small>
                    </p>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- نموذج التأكيد -->
        <form method="POST" class="text-center">
            <div class="d-flex justify-content-center gap-3">
                <button type="submit" name="confirm_delete" class="btn btn-danger btn-lg">
                    <i class="bi bi-trash me-2"></i> نعم، احذف الفرصة
                </button>
                <a href="volunteer_opportunities.php" class="btn btn-secondary btn-lg">
                    <i class="bi bi-x me-2"></i> إلغاء
                </a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';


requireRole('org_admin');


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $request_id = (int)$_POST['request_id'];
    $new_status = $_POST['status'];
    
    if (in_array($new_status, ['accepted', 'rejected'])) {
        // 1. جلب بيانات صاحب الطلب والخدمة قبل التحديث
        $info_stmt = $pdo->prepare("SELECT user_id, title FROM help_requests WHERE id = ?");
        $info_stmt->execute([$request_id]);
        $request_info = $info_stmt->fetch();

        if ($request_info) {
            // 2. تحديث حالة الطلب
            $stmt = $pdo->prepare("UPDATE help_requests SET status = ? WHERE id = ?");
            $stmt->execute([$new_status, $request_id]);

            // 3. إنشاء رسالة الإشعار
            $status_text = ($new_status == 'accepted') ? "قبول" : "رفض";
            $msg = "تم " . $status_text . " طلب المساعدة الخاص بك بخصوص (" . $request_info['title'] . ")";
            
            $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
            $notif_stmt->execute([$request_info['user_id'], $msg]);

            $success = "تم تحديث الحالة وإشعار المواطن بنجاح!";
            header("Location: help_requests.php?success=" . urlencode($success));
            exit();
        }
    }
}


$stmt = $pdo->prepare("
    SELECT hr.*, 
           u.name as requester_name, 
           u.phone as citizen_phone, 
           s.name as service_name
    FROM help_requests hr
    LEFT JOIN users u ON hr.user_id = u.id
    LEFT JOIN services s ON hr.service_id = s.id
    WHERE hr.organization_id = ? 
    ORDER BY hr.id DESC
");
$stmt->execute([$_SESSION['user_id']]);
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة طلبات المساعدة - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .request-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .request-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .status-accepted { background: rgba(40, 167, 69, 0.15); color: #155724; border: 1px solid #c3e6cb; }
        .status-rejected { background: rgba(220, 53, 69, 0.15); color: #721c24; border: 1px solid #f1b0b7; }
        
        .form-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
        }
        
        .status-badge {
            font-size: 0.85rem;
            padding: 0.4em 0.8em;
            border-radius: 20px;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
    </style>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
           
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="../dashboard.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للوحة التحكم
            </a>
            
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-question-circle me-2"></i> إدارة طلبات المساعدة
        </h2>
        <span class="badge bg-primary"><?= count($requests) ?> طلب</span>
    </div>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- عرض طلبات المساعدة -->
    <h4 class="mb-4"><i class="bi bi-list-ul me-2 text-primary"></i> قائمة طلبات المساعدة</h4>

    <?php if ($requests): ?>
        <div class="row g-4">
            <?php foreach ($requests as $request): ?>
                <div class="col-lg-6">
                    <div class="card request-card h-100 shadow-sm border-0">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h5 class="card-title mb-1 fw-bold text-primary">
                                        <?= htmlspecialchars((string)($request['requester_name'] ?? 'مواطن')) ?>
                                    </h5>
                                    <p class="text-muted mb-1 small">
                                        <i class="bi bi-telephone me-1"></i> 
                                        <?= htmlspecialchars((string)($request['citizen_phone'] ?? 'غير متوفر')) ?>
                                    </p>
                                </div>
                                <?php 
                                    $status = $request['status'] ?? 'pending';
                                    $status_label = ($status == 'accepted' || $status == 'approved') ? 'مقبول' : (($status == 'rejected') ? 'مرفوض' : 'قيد الانتظار');
                                    $badge_class = ($status == 'accepted' || $status == 'approved') ? 'bg-success' : (($status == 'rejected') ? 'bg-danger' : 'bg-warning text-dark');
                                ?>
                                <span class="badge <?= $badge_class ?> rounded-pill px-3 py-2">
                                    <?= $status_label ?>
                                </span>
                            </div>

                            <div class="mb-2">
                                <small class="text-dark">
                                    <strong>الخدمة المطلوبة:</strong> 
                                    <span class="text-primary">
                                        <?= htmlspecialchars((string)($request['service_name'] ?? 'غير محددة')) ?>
                                    </span>
                                </small>
                            </div>

                            <div class="mb-3">
                                <small class="text-muted">
                                    <strong>الوصف:</strong><br>
                                    <?= nl2br(htmlspecialchars((string)($request['description'] ?? 'لا يوجد وصف تفصيلي'))) ?>
                                </small>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <small class="text-muted small">
                                    <i class="bi bi-clock me-1"></i> 
                                    <?= isset($request['created_at']) ? date('Y-m-d H:i', strtotime($request['created_at'])) : 'تاريخ غير متوفر' ?>
                                </small>
                                <div class="action-buttons">
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                        <input type="hidden" name="status" value="accepted">
                                        <button type="submit" name="update_status" class="btn btn-success btn-sm rounded-pill px-3">قبول</button>
                                    </form>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                        <input type="hidden" name="status" value="rejected">
                                        <button type="submit" name="update_status" class="btn btn-danger btn-sm rounded-pill px-3">رفض</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-question-circle fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد طلبات مساعدة حتى الآن</h4>
            <p class="text-muted">سيظهر هنا طلبات المساعدة التي يتلقاها المستفيدون.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

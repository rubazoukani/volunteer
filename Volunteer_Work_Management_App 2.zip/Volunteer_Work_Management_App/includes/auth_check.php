<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: /Volunteer_Work_Management_App/login.php");
    exit();
}

function requireRole($allowedRoles) {
    $currentRole = $_SESSION['user_role'] ?? '';
    $allowed = is_array($allowedRoles) ? $allowedRoles : [$allowedRoles];

    if (!in_array($currentRole, $allowed)) {
        http_response_code(403);
        die("
            <div style='text-align:center; margin-top:50px; font-family:tahoma;'>
                <h2 style='color:red;'>غير مصرح لك بالوصول إلى هذه الصفحة</h2>
                <p>دورك الحالي ($currentRole) لا يسمح لك بدخول هذه المنطقة.</p>
                <a href='/Volunteer_Work_Management_App/index.php'>العودة للرئيسية</a>
            </div>
        ");
    }
}
?>
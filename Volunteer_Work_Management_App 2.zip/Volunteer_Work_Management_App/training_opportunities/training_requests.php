<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// التحقق من أن المستخدم هو مدير منظمة
requireRole('org_admin');

// معالجة تحديث حالة طلب التدريب
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $request_id = (int)$_POST['request_id'];
    $new_status = $_POST['status'];
    
    // تأكد من أن هذه القيم تطابق نوع ENUM في قاعدة البيانات
    if (in_array($new_status, ['pending', 'approved', 'rejected'])) { 
        $stmt = $pdo->prepare("UPDATE training_requests SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $request_id]);
        $success = "تم تحديث حالة طلب التدريب بنجاح!";
        header("Location: training_requests.php?success=" . urlencode($success));
        exit();
    }
}

// جلب طلبات التدريب مع تفاصيل فرصة التدريب والمركز المرتبط بها
$stmt = $pdo->prepare("
    SELECT tr.*, 
           topp.title as training_title,
           u.name as volunteer_name,
           u.email as volunteer_email,
           c.name as center_name
    FROM training_requests tr
    JOIN training_opportunities topp ON tr.training_id = topp.id
    JOIN users u ON tr.user_id = u.id
    LEFT JOIN centers c ON topp.center_id = c.id
    ORDER BY tr.submitted_at DESC
");
$stmt->execute();
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة طلبات التدريب - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root { --primary: #2c5aa0; }
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma; }
        .request-card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.08); margin-bottom: 1.5rem; border: none; }
        .status-pending { background: rgba(255, 193, 7, 0.15); color: #856404; border: 1px solid #ffeaa7; }
        .status-accepted { background: rgba(40, 167, 69, 0.15); color: #155724; border: 1px solid #c3e6cb; }
        .status-rejected { background: rgba(220, 53, 69, 0.15); color: #721c24; border: 1px solid #f1b0b7; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php"><span>نظام التطوع - إدارة التدريب</span></a>
        <a href="../dashboard.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> عودة</a>
    </div>
</nav>

<div class="container py-4">
    <h2 class="text-primary fw-bold mb-4"><i class="bi bi-mortarboard me-2"></i> إدارة طلبات التدريب</h2>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($requests): ?>
        <div class="row">
            <?php foreach ($requests as $request): ?>
                <div class="col-lg-6">
                    <div class="card request-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h5 class="fw-bold"><?= htmlspecialchars($request['volunteer_name']) ?></h5>
                                    <p class="text-muted small mb-1"><i class="bi bi-envelope"></i> <?= htmlspecialchars($request['volunteer_email']) ?></p>
                                    <p class="mb-1"><strong>الدورة:</strong> <?= htmlspecialchars($request['training_title']) ?></p>
                                    <p class="text-muted small"><i class="bi bi-building"></i> <?= htmlspecialchars($request['center_name'] ?? 'غير محدد') ?></p>
                                </div>
                                <span class="badge rounded-pill p-2 px-3 status-<?= $request['status'] ?>">
                                    <?= $request['status'] === 'pending' ? 'انتظار' : ($request['status'] === 'accepted' ? 'مقبول' : 'مرفوض') ?>
                                </span>
                            </div>
                            
                            <hr>
                            <form method="POST" class="d-flex gap-2 align-items-center">
                                <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                <select name="status" class="form-select form-select-sm">
                                    <option value="pending" <?= $request['status'] === 'pending' ? 'selected' : '' ?>>قيد الانتظار</option>
                                    <option value="approved" <?= $request['status'] === 'approved' ? 'selected' : '' ?>>قبول</option>
                                    <option value="rejected" <?= $request['status'] === 'rejected' ? 'selected' : '' ?>>رفض</option>
                                </select>
                                <button type="submit" name="update_status" class="btn btn-primary btn-sm">تحديث</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5 bg-white rounded shadow-sm">
            <i class="bi bi-inbox fs-1 text-muted"></i>
            <p class="text-muted mt-2">لا توجد طلبات تدريب مقدمة حالياً.</p>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
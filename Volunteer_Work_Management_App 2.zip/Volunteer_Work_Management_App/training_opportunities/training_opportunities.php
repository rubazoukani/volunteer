<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// فقط مدير المنظمة يمكنه الدخول
requireRole('org_admin');

// معالجة طلبات AJAX (تغيير الحالة)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] === 'toggle_status') {
    header('Content-Type: application/json');
    
    if (!isset($_POST['id']) || !is_numeric($_POST['id']) || !isset($_POST['current_status'])) {
        echo json_encode(['success' => false, 'error' => 'بيانات غير صالحة']);
        exit();
    }

    $id = (int)$_POST['id'];
    $current_status = $_POST['current_status'];
    
    // تحديد الحالة التالية بناءً على الحالة الحالية
    $status_order = ['open' => 'closed', 'closed' => 'full', 'full' => 'open'];
    $new_status = $status_order[$current_status] ?? 'open';
    
    try {
        $stmt = $pdo->prepare("UPDATE training_opportunities SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $id]);
        echo json_encode(['success' => true, 'new_status' => $new_status]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'فشل التحديث']);
    }
    exit();
}

$error = '';
$success = '';

// جلب المراكز لقائمة الاختيار
$centers = $pdo->query("SELECT id, name FROM centers WHERE status = 'active' ORDER BY name")->fetchAll();

// معالجة إضافة فرصة تدريب جديدة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_training'])) {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $center_id = !empty($_POST['center_id']) ? (int)$_POST['center_id'] : null;
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $status = $_POST['status'] ?? 'open';

    if (empty($title)) {
        $error = "يرجى إدخال عنوان فرصة التدريب.";
    } elseif (!empty($start_date) && !empty($end_date) && $start_date > $end_date) {
        $error = "تاريخ الانتهاء يجب أن يكون بعد تاريخ البدء.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO training_opportunities (title, description, center_id, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $description, $center_id, $start_date ?: null, $end_date ?: null, $status]);
        $success = "تم إضافة فرصة التدريب بنجاح!";
        header("Location: training_opportunities.php?success=" . urlencode($success));
        exit();
    }
}

// جلب جميع فرص التدريب مع أسماء المراكز والمدن
$stmt = $pdo->prepare("
    SELECT training.*, c.name as center_name, c.city as center_city 
    FROM training_opportunities training 
    LEFT JOIN centers c ON training.center_id = c.id 
    ORDER BY training.created_at DESC
");
$stmt->execute();
$trainings = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة فرص التدريب - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .training-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .training-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .status-open { background: rgba(40, 167, 69, 0.15); color: #28a745; border: 1px solid #28a745; }
        .status-closed { background: rgba(255, 193, 7, 0.15); color: #ffc107; border: 1px solid #ffc107; }
        .status-full { background: rgba(220, 53, 69, 0.15); color: #dc3545; border: 1px solid #dc3545; }
        
        .btn-icon {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            font-size: 0.9rem;
        }
        
        .form-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
        }
    </style>
</head>
<body>

<!-- شريط التنقل العلوي -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            <i class="bi bi-heart-pulse me-2 text-primary"></i>
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="../dashboard.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للوحة التحكم
            </a>
            <a href="../logout.php" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-box-arrow-right me-1"></i> خروج
            </a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-mortarboard me-2"></i> إدارة فرص التدريب
        </h2>
        <span class="badge bg-primary"><?= count($trainings) ?> فرصة</span>
    </div>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- قسم إضافة فرصة تدريب جديدة -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-mortarboard me-2"></i> إدارة فرص التدريب
        </h2>
        <div class="d-flex gap-2">
            <a href="training_requests.php" class="btn btn-outline-primary shadow-sm">
                <i class="bi bi-people me-1"></i> عرض المتقدمين للتدريب
            </a>
        </div>
    </div>
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">عنوان فرصة التدريب <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">المركز التطوعي</label>
                    <select name="center_id" class="form-select">
                        <option value="">-- اختيار مركز --</option>
                        <?php foreach ($centers as $center): ?>
                            <option value="<?= $center['id'] ?>"><?= htmlspecialchars($center['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">الوصف</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">تاريخ البدء</label>
                    <input type="date" name="start_date" class="form-control">
                </div>
                <div class="col-md-6">
                    <label class="form-label">تاريخ الانتهاء</label>
                    <input type="date" name="end_date" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">الحالة الابتدائية</label>
                    <select name="status" class="form-select">
                        <option value="open">مفتوح</option>
                        <option value="closed">مغلق</option>
                        <option value="full">ممتلئ</option>
                    </select>
                </div>
                <div class="col-12">
                    <button type="submit" name="add_training" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i> حفظ فرصة التدريب
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- عرض فرص التدريب -->
    <h4 class="mb-4"><i class="bi bi-list-ul me-2 text-primary"></i> قائمة فرص التدريب</h4>

    <?php if ($trainings): ?>
        <div class="row g-4">
            <?php foreach ($trainings as $training): ?>
                <div class="col-lg-6">
                    <div class="card training-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title mb-1"><?= htmlspecialchars($training['title']) ?></h5>
                                <span class="badge <?= 
                                    $training['status'] === 'open' ? 'status-open' : 
                                    ($training['status'] === 'closed' ? 'status-closed' : 'status-full') 
                                ?>">
                                    <?php 
                                    if ($training['status'] === 'open') echo 'مفتوح';
                                    elseif ($training['status'] === 'closed') echo 'مغلق';
                                    else echo 'ممتلئ';
                                    ?>
                                </span>
                            </div>
                            
                            <?php if ($training['center_name']): ?>
                                <p class="text-muted mb-1">
                                    <i class="bi bi-building me-1"></i> <?= htmlspecialchars($training['center_name']) ?>
                                    <?php if ($training['center_city']): ?>
                                        <span class="badge bg-light text-dark ms-2"><?= htmlspecialchars($training['center_city']) ?></span>
                                    <?php endif; ?>
                                </p>
                            <?php endif; ?>
                            
                            <?php if ($training['description']): ?>
                                <p class="card-text mb-3"><?= htmlspecialchars(substr($training['description'], 0, 150)) ?><?= strlen($training['description']) > 150 ? '...' : '' ?></p>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <div>
                                    <?php if ($training['start_date']): ?>
                                        <small class="text-muted">
                                            <i class="bi bi-calendar me-1"></i> 
                                            <?= date('Y-m-d', strtotime($training['start_date'])) ?>
                                            <?php if ($training['end_date']): ?>
                                                - <?= date('Y-m-d', strtotime($training['end_date'])) ?>
                                            <?php endif; ?>
                                        </small>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <!-- زر تغيير الحالة -->
                                    <button class="btn btn-outline-secondary btn-sm change-status" 
                                            data-id="<?= $training['id'] ?>" 
                                            data-status="<?= $training['status'] ?>">
                                        <i class="bi bi-arrow-clockwise me-1"></i> تغيير الحالة
                                    </button>
                                    
                                    <a href="edit_training.php?id=<?= $training['id'] ?>" class="btn btn-icon btn-outline-warning" title="تعديل">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="delete_training.php?id=<?= $training['id'] ?>" class="btn btn-icon btn-outline-danger" title="حذف" onclick="return confirm('هل أنت متأكد من حذف هذه الفرصة؟')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-mortarboard fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد فرص تدريب حتى الآن</h4>
            <p class="text-muted">يمكنك إضافة فرصة تدريب جديدة من النموذج أعلاه.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // تغيير حالة فرصة التدريب
    const changeStatusButtons = document.querySelectorAll('.change-status');
    changeStatusButtons.forEach(button => {
        button.addEventListener('click', function() {
            const trainingId = this.getAttribute('data-id');
            const currentStatus = this.getAttribute('data-status');
            
            fetch('training_opportunities.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'ajax=toggle_status&id=' + trainingId + '&current_status=' + currentStatus
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // تحديث الحالة في الواجهة
                    const badge = this.closest('.training-card').querySelector('.badge');
                    
                    // إزالة جميع فئات الحالة
                    badge.className = badge.className.replace(/status-\w+/g, '');
                    
                    // إضافة الفئة الجديدة
                    if (data.new_status === 'open') {
                        badge.classList.add('status-open');
                        badge.textContent = 'مفتوح';
                    } else if (data.new_status === 'closed') {
                        badge.classList.add('status-closed');
                        badge.textContent = 'مغلق';
                    } else {
                        badge.classList.add('status-full');
                        badge.textContent = 'ممتلئ';
                    }
                    
                    // تحديث سمة البيانات
                    this.setAttribute('data-status', data.new_status);
                } else {
                    alert('فشل تغيير الحالة. الرجاء المحاولة مرة أخرى.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ أثناء تغيير الحالة.');
            });
        });
    });
});
</script>
</body>
</html>



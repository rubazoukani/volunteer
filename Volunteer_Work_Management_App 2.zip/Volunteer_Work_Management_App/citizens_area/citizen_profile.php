<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// التأكد من أن المستخدم هو مواطن
requireRole('citizen');

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// 1. جلب بيانات المواطن الحالية
$stmt = $pdo->prepare("SELECT name, email, phone, city FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("تعذر العثور على بيانات المستخدم.");
}

// 2. معالجة تحديث البيانات عند إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $city = trim($_POST['city']);

    if (!empty($name)) {
        try {
            $updateStmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, city = ? WHERE id = ?");
            if ($updateStmt->execute([$name, $phone, $city, $user_id])) {
                $success = "تم تحديث بياناتك الشخصية بنجاح.";
                $_SESSION['user_name'] = $name; // تحديث الاسم في الجلسة ليعكس التغيير في لوحة التحكم
                
                // تحديث البيانات المعروضة في الصفحة فوراً
                $user['name'] = $name;
                $user['phone'] = $phone;
                $user['city'] = $city;
            }
        } catch (PDOException $e) {
            $error = "عذراً، لم نتمكن من تحديث البيانات. يرجى المحاولة لاحقاً.";
        }
    } else {
        $error = "حقل الاسم مطلوب ولا يمكن تركه فارغاً.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الملف الشخصي | بوابة المواطن</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .profile-container { max-width: 600px; margin-top: 50px; }
        .card { border: none; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
        .header-avatar { width: 80px; height: 80px; background: #6610f2; color: white; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-size: 30px; margin: -40px auto 20px; border: 5px solid #f0f2f5; }
        .form-control { border-radius: 10px; padding: 12px; border: 1px solid #dee2e6; }
        .btn-update { background-color: #6610f2; border: none; border-radius: 10px; padding: 12px; font-weight: bold; color: white; transition: 0.3s; }
        .btn-update:hover { background-color: #520dc2; transform: translateY(-2px); }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark shadow-sm" style="background-color: #6610f2;">
    <div class="container">
        <a class="navbar-brand fw-bold" href="citizen_dashboard.php"><i class="bi bi-arrow-right-circle me-2"></i> عودة للوحة التحكم</a>
    </div>
</nav>

<div class="container profile-container mb-5">
    <div class="card">
        <div class="card-body p-4 p-md-5">
            <div class="header-avatar shadow">
                <i class="bi bi-person"></i>
            </div>
            
            <h3 class="text-center fw-bold text-dark mb-4">تعديل ملفي الشخصي</h3>

            <?php if ($success): ?>
                <div class="alert alert-success border-0 shadow-sm d-flex align-items-center" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i> <div><?= $success ?></div>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger border-0 shadow-sm d-flex align-items-center" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <div><?= $error ?></div>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label text-muted fw-bold small">البريد الإلكتروني (لا يمكن تعديله)</label>
                    <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($user['email']) ?>" readonly>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">الاسم الكامل</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="bi bi-person text-muted"></i></span>
                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">رقم الهاتف</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="bi bi-telephone text-muted"></i></span>
                        <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="09xxxxxxx">
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">المدينة / السكن</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="bi bi-geo-alt text-muted"></i></span>
                        <input type="text" name="city" class="form-control" value="<?= htmlspecialchars($user['city'] ?? '') ?>" placeholder="مثلاً: دمشق، المزة">
                    </div>
                </div>

                <button type="submit" class="btn btn-update w-100 shadow-sm">
                    <i class="bi bi-save me-2"></i> حفظ التغييرات
                </button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('citizen'); // تأكد من وجود دور citizen في قاعدة البيانات

$user_id = $_SESSION['user_id'];
$requests_count = $pdo->query("SELECT COUNT(*) FROM help_requests WHERE user_id = $user_id")->fetchColumn();

// جلب عدد الإشعارات غير المقروءة
$notif_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$notif_count_stmt->execute([$_SESSION['user_id']]);
$notif_count = $notif_count_stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>بوابة المواطن</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .hero-citizen { background: linear-gradient(135deg, #6610f2 0%, #6f42c1 100%); color: white; padding: 40px 0; border-radius: 0 0 30px 30px; }
        .card-menu { border: none; border-radius: 20px; transition: 0.3s; height: 100%; text-align: center; padding: 30px; }
        .card-menu:hover { transform: translateY(-10px); box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
        .icon-box { width: 70px; height: 70px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 30px; margin: 0 auto 20px; }
    </style>
</head>
<body>

<div class="hero-citizen shadow mb-5">
    <div class="container d-flex justify-content-between align-items-center">
        <div>
            <h2 class="fw-bold">أهلاً بك يا سيد <?= htmlspecialchars($_SESSION['user_name']) ?></h2>
            <p class="mb-0">نحن هنا لخدمتك ومساعدتك في تلبية احتياجاتك.</p>
        </div>
        <a href="../logout.php" class="btn btn-outline-light rounded-pill">تسجيل الخروج</a>
    </div>
</div>
<div class="dropdown me-3">
    <button class="btn btn-light position-relative rounded-circle p-2" type="button" data-bs-toggle="dropdown">
        <i class="bi bi-bell-fill text-primary"></i>
        <?php if($notif_count > 0): ?>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">
                <?= $notif_count ?>
            </span>
        <?php endif; ?>
    </button>
    <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2" style="width: 300px; border-radius: 15px;">
        <li class="p-2 border-bottom"><h6 class="mb-0 fw-bold small">الإشعارات الأخيرة</h6></li>
        <?php
        $notifs = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 5");
        $notifs->execute([$_SESSION['user_id']]);
        $rows = $notifs->fetchAll();
        
        if($rows):
            foreach($rows as $row): ?>
                <li><a class="dropdown-item small p-3 <?= $row['is_read'] ? 'opacity-50' : 'fw-bold' ?>" href="my_help_requests.php">
                    <i class="bi bi-info-circle me-2 text-primary"></i> <?= htmlspecialchars($row['message']) ?>
                    <div class="text-muted" style="font-size: 0.7rem;"><?= date('Y-m-d H:i', strtotime($row['created_at'])) ?></div>
                </a></li>
            <?php endforeach;
        else: ?>
            <li class="p-3 text-center text-muted small">لا توجد إشعارات حالياً</li>
        <?php endif; ?>
        <li class="p-2 text-center border-top">
            <a href="notifications.php" class="text-primary small text-decoration-none fw-bold">عرض الكل</a>
        </li>
    </ul>
</div>

<div class="container">
    <div class="row g-4">
        <div class="col-md-4">
            <a href="request_help.php" class="text-decoration-none text-dark">
                <div class="card card-menu shadow-sm">
                    <div class="icon-box bg-danger-subtle text-danger"><i class="bi bi-hand-index-thumb"></i></div>
                    <h5 class="fw-bold">طلب مساعدة جديد</h5>
                    <p class="text-muted small">أرسل طلباً للحصول على دعم أو مساعدة فورية.</p>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="my_help_requests.php" class="text-decoration-none text-dark">
                <div class="card card-menu shadow-sm">
                    <div class="icon-box bg-danger-subtle text-danger"><i class="bi bi-clock-history"></i></div>
                    <h5 class="fw-bold">سجل طلبات المساعدة</h5>
                    <p class="text-muted small">تتبع حالة الطلبات المقدمة</p>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="manage_reviews.php" class="text-decoration-none text-dark">
                <div class="card card-menu shadow-sm">
                    <div class="icon-box bg-success-subtle text-success"><i class="bi bi-star"></i></div>
                    <h5 class="fw-bold">التقييمات والآراء</h5>
                    <p class="text-muted small">شاركنا تجربتك وساعدنا في تحسين الخدمة.</p>
                </div>
            </a>
        </div>
        <div class="col-md-6">
            <a href="citizen_profile.php" class="text-decoration-none text-dark">
                <div class="card card-menu shadow-sm">
                    <div class="icon-box bg-primary-subtle text-primary"><i class="bi bi-person-gear"></i></div>
                    <h5 class="fw-bold">إدارة ملفي الشخصي</h5>
                </div>
            </a>
        </div>
        <div class="col-md-6">
            <a href="browse_orgs_centers.php" class="text-decoration-none text-dark">
                <div class="card card-menu shadow-sm">
                    <div class="icon-box bg-info-subtle text-info"><i class="bi bi-building"></i></div>
                    <h5 class="fw-bold">المنظمات والمراكز</h5>
                </div>
            </a>
        </div>
    </div>
</div>
</body>
</html>
<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('citizen');

// جلب كافة المنظمات النشطة
$stmt = $pdo->query("SELECT id, organization_name, email FROM users WHERE role = 'org_admin' AND status = 'active' ORDER BY organization_name ASC");
$organizations = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>المنظمات والمراكز | بوابة المواطن</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .navbar-custom { background: #6610f2; color: white; }
        .org-card { border: none; border-radius: 20px; box-shadow: 0 8px 25px rgba(0,0,0,0.05); transition: 0.3s; background: white; margin-bottom: 30px; overflow: hidden; }
        .org-header { background: #f8f9fc; border-bottom: 1px solid #edf2f9; padding: 20px; }
        .section-title { font-size: 0.85rem; font-weight: 700; color: #6e707e; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 15px; display: block; }
        .service-badge { background: #eef2ff; color: #4e73df; border: 1px solid #d1dcfd; border-radius: 8px; padding: 5px 12px; display: inline-block; margin: 2px; font-size: 0.85rem; }
        .center-item { border-right: 3px solid #1cc88a; background: #f8fffb; padding: 10px 15px; border-radius: 0 8px 8px 0; margin-bottom: 10px; }
    </style>
</head>
<body>

<nav class="navbar navbar-custom shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold text-white" href="citizen_dashboard.php"><i class="bi bi-building me-2"></i> دليل الهيئات والمراكز</a>
        <a href="citizen_dashboard.php" class="btn btn-light btn-sm rounded-pill fw-bold">العودة للرئيسية</a>
    </div>
</nav>

<div class="container py-4">
    <div class="text-center mb-5">
        <h2 class="fw-bold">المنظمات الشريكة ومراكزها</h2>
        <p class="text-muted">تصفح الخدمات المتاحة وأقرب المراكز التطوعية إليك في سورية</p>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-10">
            <?php if ($organizations): ?>
                <?php foreach ($organizations as $org): ?>
                    <div class="org-card">
                        <div class="org-header d-flex justify-content-between align-items-center">
                            <div>
                                <h4 class="fw-bold text-dark mb-1"><?= htmlspecialchars($org['organization_name']) ?></h4>
                                <small class="text-muted"><i class="bi bi-envelope me-1"></i> <?= htmlspecialchars($org['email']) ?></small>
                            </div>
                            <a href="request_help.php" class="btn btn-primary rounded-pill px-4 btn-sm shadow-sm">طلب مساعدة</a>
                        </div>

                        <div class="card-body p-4">
                            <div class="row">
                                <div class="col-md-6 mb-4 mb-md-0">
                                    <span class="section-title text-primary"><i class="bi bi-star-fill me-1"></i> الخدمات المقدمة</span>
                                    <div class="mt-2">
                                        <?php
                                        $s_stmt = $pdo->prepare("SELECT name FROM services WHERE user_id = ? AND status = 'active'");
                                        $s_stmt->execute([$org['id']]);
                                        $services = $s_stmt->fetchAll();
                                        if ($services):
                                            foreach ($services as $s): ?>
                                                <span class="service-badge"><?= htmlspecialchars($s['name']) ?></span>
                                            <?php endforeach;
                                        else:
                                            echo "<p class='text-muted small'>لا توجد خدمات مضافة حالياً.</p>";
                                        endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <span class="section-title text-success"><i class="bi bi-geo-alt-fill me-1"></i> مراكزنا في المحافظات</span>
                                    <div class="mt-2">
                                        <?php
                                        $c_stmt = $pdo->prepare("SELECT name, city, location FROM centers WHERE user_id = ? AND status = 'active'");
                                        $c_stmt->execute([$org['id']]);
                                        $centers = $c_stmt->fetchAll();
                                        if ($centers):
                                            foreach ($centers as $c): ?>
                                                <div class="center-item">
                                                    <div class="fw-bold small"><?= htmlspecialchars($c['name']) ?></div>
                                                    <div class="text-muted" style="font-size: 0.75rem;">
                                                        <i class="bi bi-map me-1"></i> <?= htmlspecialchars($c['city']) ?> - <?= htmlspecialchars($c['location']) ?>
                                                    </div>
                                                </div>
                                            <?php endforeach;
                                        else:
                                            echo "<p class='text-muted small'>لا توجد مراكز تطوعية مسجلة لهذه المنظمة.</p>";
                                        endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="text-center bg-white p-5 rounded-4 shadow-sm">
                    <i class="bi bi-building-exclamation fs-1 text-muted opacity-25"></i>
                    <h5 class="text-muted mt-3">لا توجد منظمات مسجلة حالياً.</h5>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
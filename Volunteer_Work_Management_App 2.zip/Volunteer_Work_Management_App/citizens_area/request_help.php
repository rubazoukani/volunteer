<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('citizen');

$user_id = $_SESSION['user_id'];
$success = ""; $error = "";

// 1. جلب المنظمات النشطة فقط
$orgs_stmt = $pdo->query("SELECT id, organization_name FROM users WHERE role = 'org_admin' AND status = 'active'");
$organizations = $orgs_stmt->fetchAll();

// 2. معالجة إرسال طلب جديد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    $org_id = (int)$_POST['organization_id'];
    $service_id = (int)$_POST['service_id'];
    $desc = trim($_POST['description']);
    $user_name = $_SESSION['user_name'] ?? 'مواطن';

    if ($org_id > 0 && $service_id > 0 && !empty($desc)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO help_requests (user_id, organization_id, service_id, requester_name, description, status) VALUES (?, ?, ?, ?, ?, 'pending')");
            if ($stmt->execute([$user_id, $org_id, $service_id, $user_name, $desc])) {
                $success = "تم إرسال طلبك بنجاح للمنظمة، يمكنك متابعته من صفحة سجل الطلبات.";
            }
        } catch (PDOException $e) {
            $error = "خطأ في الإرسال: " . $e->getMessage();
        }
    } else {
        $error = "يرجى اختيار المنظمة والخدمة وكتابة وصف الحالة.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقديم طلب مساعدة | نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .hero-header { background: linear-gradient(135deg, #6610f2 0%, #4e73df 100%); color: white; padding: 40px 0; border-radius: 0 0 30px 30px; }
        .request-card { border: none; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); background: white; margin-top: -50px; }
        .form-select, .form-control { border-radius: 12px; padding: 12px; border: 1px solid #dee2e6; }
        .form-select:focus, .form-control:focus { border-color: #6610f2; box-shadow: 0 0 0 0.25 row rgba(102, 16, 242, 0.1); }
        .btn-submit { background: #6610f2; color: white; border: none; border-radius: 12px; padding: 15px; font-weight: bold; transition: 0.3s; }
        .btn-submit:hover { background: #520dc2; transform: translateY(-2px); color: white; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark" style="background: #6610f2;">
    <div class="container">
        <a class="navbar-brand fw-bold" href="citizen_dashboard.php"><i class="bi bi-heart-fill me-2"></i> بوابة المواطن</a>
        <a href="citizen_dashboard.php" class="btn btn-light btn-sm rounded-pill px-3">العودة للرئيسية</a>
    </div>
</nav>

<div class="hero-header text-center">
    <div class="container">
        <h2 class="fw-bold">تقديم طلب مساعدة جديد</h2>
        <p class="opacity-75">املأ النموذج أدناه لتصل رسالتك للمنظمة المعنية</p>
    </div>
</div>

<div class="container pb-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card request-card p-4 p-md-5">
                
                <?php if($success): ?>
                    <div class="alert alert-success border-0 shadow-sm mb-4">
                        <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
                        <div class="mt-2">
                            <a href="my_help_requests.php" class="alert-link small">انتقل لمشاهدة سجل طلباتك <i class="bi bi-arrow-left"></i></a>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($error): ?>
                    <div class="alert alert-danger border-0 shadow-sm mb-4">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <div class="mb-4">
                        <label class="form-label fw-bold"><i class="bi bi-building me-2 text-primary"></i> اختر المنظمة</label>
                        <select name="organization_id" id="organization_id" class="form-select shadow-sm" required onchange="fetchServices(this.value)">
                            <option value="" disabled selected>-- اختر المنظمة المستهدفة --</option>
                            <?php foreach($organizations as $org): ?>
                                <option value="<?= $org['id'] ?>"><?= htmlspecialchars($org['organization_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold"><i class="bi bi-gear-fill me-2 text-primary"></i> نوع الخدمة المتاحة</label>
                        <select name="service_id" id="service_id" class="form-select shadow-sm" required disabled>
                            <option value="">يجب اختيار المنظمة أولاً...</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold"><i class="bi bi-chat-left-text-fill me-2 text-primary"></i> شرح الحالة والاحتياج</label>
                        <textarea name="description" class="form-control shadow-sm" rows="5" placeholder="يرجى كتابة تفاصيل الطلب بوضوح لمساعدتنا في تقييم الحالة..." required></textarea>
                    </div>

                    <button type="submit" name="submit_request" class="btn btn-submit w-100 shadow">
                        <i class="bi bi-send-fill me-2"></i> إرسال الطلب للمراجعة
                    </button>
                    
                    <div class="text-center mt-4">
                        <a href="my_help_requests.php" class="text-muted text-decoration-none small">
                            <i class="bi bi-clock-history"></i> عرض سجل طلباتي السابقة
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function fetchServices(orgId) {
    const serviceSelect = document.getElementById('service_id');
    serviceSelect.innerHTML = '<option value="">جاري تحميل الخدمات...</option>';
    serviceSelect.disabled = true;

    if (!orgId) return;

    fetch('get_services.php?org_id=' + orgId)
        .then(response => response.json())
        .then(data => {
            serviceSelect.innerHTML = '<option value="" disabled selected>-- اختر من خدمات المنظمة --</option>';
            if (data.length > 0) {
                data.forEach(service => {
                    serviceSelect.innerHTML += `<option value="${service.id}">${service.name}</option>`;
                });
                serviceSelect.disabled = false;
            } else {
                serviceSelect.innerHTML = '<option value="">لا توجد خدمات متاحة لهذه المنظمة حالياً</option>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            serviceSelect.innerHTML = '<option value="">خطأ في تحميل البيانات</option>';
        });
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
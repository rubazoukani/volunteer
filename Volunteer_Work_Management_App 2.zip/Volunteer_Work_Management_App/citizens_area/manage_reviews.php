<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('citizen');

$user_id = $_SESSION['user_id'];
$success = "";
$error = "";

// 1. معالجة إرسال التقييم
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $org_id = (int)$_POST['organization_id'];
    $rating = (int)$_POST['rating'];
    $comment = trim($_POST['comment']);

    if ($org_id > 0 && $rating >= 1 && $rating <= 5 && !empty($comment)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO reviews (user_id, organization_id, rating, comment) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$user_id, $org_id, $rating, $comment])) {
                $success = "تم إضافة تقييمك بنجاح، شكراً لك!";
            }
        } catch (PDOException $e) {
            $error = "حدث خطأ أثناء الحفظ، يرجى التأكد من تحديث قاعدة البيانات.";
        }
    } else {
        $error = "يرجى اختيار المنظمة وكتابة التعليق.";
    }
}

// 2. جلب المنظمات
$orgs_stmt = $pdo->query("SELECT id, organization_name FROM users WHERE role = 'org_admin'");
$organizations = $orgs_stmt->fetchAll();

// 3. جلب التقييمات (تم تعديل الاستعلام ليكون أكثر أماناً)
try {
    $my_reviews_stmt = $pdo->prepare("
        SELECT r.*, u.organization_name 
        FROM reviews r 
        LEFT JOIN users u ON r.organization_id = u.id 
        WHERE r.user_id = ? 
        ORDER BY r.id DESC
    ");
    $my_reviews_stmt->execute([$user_id]);
    $my_reviews = $my_reviews_stmt->fetchAll();
} catch (PDOException $e) {
    $my_reviews = []; // في حال وجود خطأ في الأعمدة لا تتوقف الصفحة عن العمل
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تقييم المنظمات</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fc; font-family: 'Segoe UI', sans-serif; }
        .card-custom { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .star-filled { color: #f6c23e; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark mb-4" style="background: #6610f2;">
    <div class="container">
        <a class="navbar-brand fw-bold" href="citizen_dashboard.php">بوابة المواطن</a>
        <a href="citizen_dashboard.php" class="btn btn-light btn-sm">العودة للرئيسية</a>
    </div>
</nav>

<div class="container">
    <div class="row g-4">
        <div class="col-lg-5">
            <div class="card card-custom p-4">
                <h5 class="fw-bold mb-3 text-primary">إضافة تقييم جديد</h5>
                <?php if($success) echo "<div class='alert alert-success small'>$success</div>"; ?>
                <?php if($error) echo "<div class='alert alert-danger small'>$error</div>"; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">المنظمة</label>
                        <select name="organization_id" class="form-select border-0 bg-light" required>
                            <option value="">-- اختر المنظمة --</option>
                            <?php foreach($organizations as $org): ?>
                                <option value="<?= $org['id'] ?>"><?= htmlspecialchars($org['organization_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">التقييم</label>
                        <select name="rating" class="form-select border-0 bg-light" required>
                            <option value="5">5 نجوم - ممتاز</option>
                            <option value="4">4 نجوم - جيد جداً</option>
                            <option value="3">3 نجوم - جيد</option>
                            <option value="2">2 نجمة - مقبول</option>
                            <option value="1">1 نجمة - ضعيف</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">تعليقك</label>
                        <textarea name="comment" class="form-control border-0 bg-light" rows="3" required></textarea>
                    </div>
                    <button type="submit" name="submit_review" class="btn btn-primary w-100 rounded-pill fw-bold">إرسال</button>
                </form>
            </div>
        </div>

        <div class="col-lg-7">
            <div class="card card-custom p-4">
                <h5 class="fw-bold mb-3 text-secondary">تقييماتي السابقة</h5>
                <?php if($my_reviews): ?>
                    <?php foreach($my_reviews as $rev): ?>
                        <div class="border-bottom py-3">
                            <div class="d-flex justify-content-between">
                                <span class="fw-bold"><?= htmlspecialchars($rev['organization_name'] ?? 'منظمة') ?></span>
                                <div>
                                    <?php for($i=1; $i<=5; $i++): ?>
                                        <i class="bi bi-star-fill <?= $i <= $rev['rating'] ? 'star-filled' : 'text-light' ?>"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <p class="small text-muted mb-0 mt-1"><?= htmlspecialchars($rev['comment']) ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-center text-muted py-5 small">لا توجد تقييمات لعرضها حالياً.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

</body>
</html>
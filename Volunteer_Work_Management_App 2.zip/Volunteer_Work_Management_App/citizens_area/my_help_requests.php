<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('citizen');

$user_id = $_SESSION['user_id'];

// 1. تحديث كافة الإشعارات المتعلقة بطلبات المساعدة لتصبح "مقروءة" بمجرد دخول المواطن لهذه الصفحة
$update_notifs = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND message LIKE '%طلب المساعدة%'");
$update_notifs->execute([$user_id]);

// 2. جلب سجل طلبات المساعدة الخاصة بالمواطن مع بيانات المنظمة والخدمة
$stmt = $pdo->prepare("
    SELECT hr.*, u.organization_name, s.name as service_name 
    FROM help_requests hr 
    LEFT JOIN users u ON hr.organization_id = u.id 
    LEFT JOIN services s ON hr.service_id = s.id 
    WHERE hr.user_id = ? 
    ORDER BY hr.id DESC
");
$stmt->execute([$user_id]);
$my_requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سجل طلباتي | نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .page-header { background: #6610f2; color: white; padding: 30px 0; border-radius: 0 0 30px 30px; margin-bottom: 30px; }
        .request-card { border: none; border-radius: 15px; transition: 0.3s; background: white; border-right: 5px solid #ddd; }
        .request-card:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.05); }
        
        /* ألوان الحالات */
        .status-pending { border-right-color: #f6c23e; }
        .status-accepted { border-right-color: #1cc88a; }
        .status-rejected { border-right-color: #e74a3b; }
        
        .badge-status { border-radius: 8px; padding: 6px 12px; font-size: 0.8rem;}
        .bg-pending { background: #fff9e6; color: #856404; }
        .bg-accepted { background: #e6f9ed; color: #0f5132; }
        .bg-rejected { background: #fbeaea; color: #842029; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark shadow-sm" style="background: #6610f2;">
    <div class="container">
        <a class="navbar-brand fw-bold" href="citizen_dashboard.php">بوابة المواطن</a>
        <a href="citizen_dashboard.php" class="btn btn-outline-light btn-sm rounded-pill">العودة للرئيسية</a>
    </div>
</nav>

<div class="page-header shadow-sm">
    <div class="container text-center">
        <h2 class="fw-bold">سجل طلبات المساعدة</h2>
        <p class="opacity-75">تابع حالة طلباتك المقدمة للمنظمات المختلفة</p>
    </div>
</div>

<div class="container pb-5">
    <?php if ($my_requests): ?>
        <div class="row g-4">
            <?php foreach ($my_requests as $req): ?>
                <?php 
                    // تحديد نمط البطاقة بناءً على الحالة
                    $status_class = "status-" . $req['status'];
                    $badge_class = "bg-" . $req['status'];
                    $status_text = ($req['status'] == 'accepted') ? 'تم القبول' : (($req['status'] == 'rejected') ? 'تم الرفض' : 'قيد الانتظار');
                ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card request-card <?= $status_class ?> p-4 h-100 shadow-sm">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="badge-status <?= $badge_class ?>"><?= $status_text ?></span>
                            <small class="text-muted"><i class="bi bi-calendar3 me-1"></i> <?= date('Y-m-d', strtotime($req['created_at'])) ?></small>
                        </div>
                        
                        <h5 class="fw-bold text-dark mb-2"><?= htmlspecialchars($req['service_name'] ?? 'خدمة عامة') ?></h5>
                        <p class="small text-primary mb-3"><i class="bi bi-building me-1"></i> <?= htmlspecialchars($req['organization_name'] ?? 'غير محدد') ?></p>
                        
                        <div class="bg-light p-3 rounded-3 mb-3" style="min-height: 80px;">
                            <small class="text-secondary fw-bold d-block mb-1">وصف الحالة:</small>
                            <small class="text-dark"><?= nl2br(htmlspecialchars($req['description'])) ?></small>
                        </div>

                        <?php if($req['status'] == 'accepted'): ?>
                            <div class="alert alert-success py-2 px-3 m-0 small border-0">
                                <i class="bi bi-check-circle-fill me-1"></i> سيتم التواصل معك قريباً لتنفيذ الطلب.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5 bg-white rounded-4 shadow-sm">
            <i class="bi bi-clipboard-x fs-1 text-muted opacity-25"></i>
            <h5 class="text-muted mt-3">لا يوجد لديك أي طلبات مقدمة حتى الآن.</h5>
            <a href="request_help.php" class="btn btn-primary mt-3 rounded-pill">تقديم طلب الآن</a>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
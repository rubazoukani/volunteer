<?php
require_once '../config/db.php';
if (isset($_GET['org_id'])) {
    $org_id = (int)$_GET['org_id'];
    $stmt = $pdo->prepare("SELECT id, name FROM services WHERE user_id = ?");
    $stmt->execute([$org_id]);
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($services);
}
?>
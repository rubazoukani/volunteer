<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

// التأكد من أن المستخدم هو مدير النظام
requireRole('system_admin');

// جلب إحصائيات التقييمات
$stats_stmt = $pdo->query("SELECT COUNT(*) as total, AVG(rating) as average FROM reviews");
$stats = $stats_stmt->fetch();
$total_reviews = $stats['total'] ?? 0;
$avg_rating = round($stats['average'] ?? 0, 2);

// جلب التقييمات مع بيانات المواطن والمنظمة
$query = "
    SELECT r.*, 
           u_citizen.name as reviewer_name, 
           u_citizen.email as reviewer_email,
           u_org.organization_name as org_name
    FROM reviews r
    JOIN users u_citizen ON r.user_id = u_citizen.id
    JOIN users u_org ON r.organization_id = u_org.id
    ORDER BY r.created_at DESC";
$stmt = $pdo->query($query);
$reviews = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التقييمات - مدير النظام</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0; --secondary: #28a745; --accent: #ff6b35;
            --light: #f8f9fa; --dark: #343a40; --sidebar-width: 280px;
            --sidebar-collapsed-width: 80px;
        }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background-color: #f8f9fa; }
        .admin-sidebar { background: var(--dark); color: white; height: 100vh; position: fixed; top: 0; right: 0; width: var(--sidebar-width); transition: all 0.3s ease; z-index: 1000; overflow-y: auto; }
        .admin-sidebar.collapsed { width: var(--sidebar-collapsed-width); }
        .sidebar-header { padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.1); display: flex; align-items: center; justify-content: space-between; }
        .sidebar-menu a { color: #adb5bd; text-decoration: none; padding: 12px 25px; display: flex; align-items: center; gap: 12px; transition: all 0.3s; margin: 0 10px 4px; border-radius: 8px; }
        .sidebar-menu a:hover, .sidebar-menu a.active { background: rgba(255,255,255,0.1); color: white; }
        .admin-main { margin-right: var(--sidebar-width); padding: 20px; transition: margin-right 0.3s ease; }
        .admin-main.sidebar-collapsed { margin-right: var(--sidebar-collapsed-width); }
        .review-card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.08); background: white; margin-bottom: 1.5rem; border: none; }
        .review-header { padding: 20px; background: linear-gradient(135deg, var(--primary), #1a3a6d); color: white; border-radius: 15px 15px 0 0; }
        .review-rating { color: #ffc107; font-size: 1.2rem; }
        .review-type { background: rgba(255,255,255,0.2); padding: 3px 10px; border-radius: 15px; font-size: 0.8rem; }
    </style>
</head>
<body>

<div class="admin-sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo"><span>نظام التطوع</span></div>
        <button class="toggle-sidebar" id="toggleSidebar"><i class="bi bi-list"></i></button>
    </div>
    <div class="sidebar-menu">
        <a href="system_admin_dashboard.php"><i class="bi bi-speedometer2"></i><span>لوحة التحكم</span></a>
        <div class="menu-title text-muted px-4 small mt-3">إدارة المحتوى</div>
        <a href="system_admin_organizations.php"><i class="bi bi-building"></i><span>مدراء المنظمات</span></a>
        <a href="system_admin_volunteers.php"><i class="bi bi-people"></i><span>المتطوعون</span></a>
        <a href="system_admin_reviews.php" class="active"><i class="bi bi-star"></i><span>التقييمات</span></a>
    </div>
</div>

<div class="admin-main" id="mainContent">
    <div class="admin-navbar mb-4 bg-white p-3 rounded-3 shadow-sm d-flex justify-content-between">
        <div>
            <h2 class="fw-bold text-primary mb-0">إدارة التقييمات</h2>
            <p class="text-muted mb-0">مراقبة آراء المواطنين حول أداء المنظمات</p>
        </div>
    </div>

    <div class="row mb-4 g-3">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm p-3 h-100">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted fw-bold">إجمالي التقييمات</h6>
                        <h2 class="fw-bold mb-0"><?= $total_reviews ?></h2>
                    </div>
                    <i class="bi bi-chat-left-text text-primary fs-1"></i>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card border-0 shadow-sm p-3 h-100">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted fw-bold">متوسط التقييم العام</h6>
                        <h2 class="fw-bold mb-0 text-warning"><?= $avg_rating ?>/5</h2>
                    </div>
                    <div class="review-rating fs-2">
                        <?php for($i=1; $i<=5; $i++) echo $i <= round($avg_rating) ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star"></i>'; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <?php if ($reviews): ?>
            <?php foreach ($reviews as $review): ?>
                <div class="col-lg-6">
                    <div class="card review-card h-100">
                        <div class="review-header p-3">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h5 class="mb-1 fw-bold"><?= htmlspecialchars((string)($review['reviewer_name'] ?? 'مواطن')) ?></h5>
                                    <span class="review-type">تقييم لمنظمة: <?= htmlspecialchars((string)($review['org_name'] ?? 'غير محددة')) ?></span>
                                </div>
                                <div class="review-rating">
                                    <?php for($i=1; $i<=5; $i++) echo $i <= $review['rating'] ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star text-white-50"></i>'; ?>
                                </div>
                            </div>
                        </div>
                        <div class="review-body p-3">
                            <p class="review-text fst-italic">"<?= nl2br(htmlspecialchars((string)($review['comment'] ?? 'لا يوجد تعليق'))) ?>"</p>
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top">
                                <small class="text-muted"><i class="bi bi-envelope me-1"></i> <?= htmlspecialchars((string)($review['reviewer_email'] ?? '')) ?></small>
                                <small class="text-muted"><i class="bi bi-clock me-1"></i> <?= date('Y-m-d', strtotime($review['created_at'])) ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info text-center py-5 rounded-4 shadow-sm border-0">
                    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                    لا توجد تقييمات مضافة حالياً في النظام.
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('toggleSidebar').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('collapsed');
        document.getElementById('mainContent').classList.toggle('sidebar-collapsed');
    });
</script>
</body>
</html>
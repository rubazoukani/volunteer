<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';

// التأكد من أن المستخدم هو مدير منظمة
requireRole('org_admin');

$success = "";
$error = "";
$user_id = $_SESSION['user_id'];

// 1. معالجة إضافة خدمة جديدة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_service'])) {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);

    if (!empty($name)) {
        try {
            // التعديل الجوهري: إدراج $user_id لربط الخدمة بالمنظمة الصحيحة
            $stmt = $pdo->prepare("INSERT INTO services (user_id, name, description, status) VALUES (?, ?, ?, 'active')");
            if ($stmt->execute([$user_id, $name, $description])) {
                $success = "تم إضافة الخدمة الجديدة بنجاح.";
            }
        } catch (PDOException $e) {
            $error = "خطأ في قاعدة البيانات: " . $e->getMessage();
        }
    } else {
        $error = "يرجى إدخال اسم الخدمة.";
    }
}

// 2. جلب الخدمات التابعة لهذه المنظمة فقط
$stmt = $pdo->prepare("SELECT * FROM services WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$services = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الخدمات - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root { --primary: #2c5aa0; --secondary: #28a745; }
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .card-header-custom { background: var(--primary); color: white; border-radius: 15px 15px 0 0 !important; }
        .btn-add { background: var(--secondary); color: white; border-radius: 10px; }
        .service-card { border: none; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); transition: 0.3s; }
        .service-card:hover { transform: translateY(-5px); }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">لوحة تحكم المنظمة</a>
        <a href="../dashboard.php" class="btn btn-outline-light btn-sm">العودة للرئيسية</a>
    </div>
</nav>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="card service-card border-0">
                <div class="card-header card-header-custom py-3">
                    <h5 class="mb-0"><i class="bi bi-plus-circle me-2"></i> إضافة خدمة جديدة</h5>
                </div>
                <div class="card-body">
                    <?php if($success): ?>
                        <div class="alert alert-success small"><?= $success ?></div>
                    <?php endif; ?>
                    <?php if($error): ?>
                        <div class="alert alert-danger small"><?= $error ?></div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">اسم الخدمة</label>
                            <input type="text" name="name" class="form-control" placeholder="مثلاً: توزيع سلال غذائية" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">وصف الخدمة</label>
                            <textarea name="description" class="form-control" rows="4" placeholder="اكتب تفاصيل الخدمة..." required></textarea>
                        </div>
                        <button type="submit" name="add_service" class="btn btn-add w-100 py-2 fw-bold">
                            <i class="bi bi-save me-2"></i> حفظ الخدمة
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card service-card border-0">
                <div class="card-header bg-white py-3 border-0">
                    <h5 class="mb-0 text-primary fw-bold"><i class="bi bi-list-stars me-2"></i> الخدمات الحالية للمنظمة</h5>
                </div>
                <div class="card-body">
                    <?php if($services): ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>الخدمة</th>
                                        <th>الوصف</th>
                                        <th>الحالة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($services as $service): ?>
                                        <tr>
                                            <td class="fw-bold"><?= htmlspecialchars($service['name']) ?></td>
                                            <td class="small text-muted"><?= htmlspecialchars(substr($service['description'], 0, 50)) ?>...</td>
                                            <td><span class="badge bg-success-subtle text-success">نشطة</span></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="edit_service.php?id=<?= $service['id'] ?>" class="btn btn-outline-primary btn-sm"><i class="bi bi-pencil"></i></a>
                                                    <a href="delete_service.php?id=<?= $service['id'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('هل أنت متأكد من الحذف؟')"><i class="bi bi-trash"></i></a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-folder2-open fs-1 text-muted opacity-25"></i>
                            <p class="text-muted mt-3">لم يتم إضافة أي خدمات بعد.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';
requireRole('org_admin');

$user_id = $_SESSION['user_id'];
$success = "";
$error = "";

if (!isset($_GET['id'])) {
    header("Location: centers.php");
    exit();
}

$center_id = (int)$_GET['id'];

// جلب بيانات المركز مع التأكد أنه يخص هذه المنظمة فقط
$stmt = $pdo->prepare("SELECT * FROM centers WHERE id = ? AND user_id = ?");
$stmt->execute([$center_id, $user_id]);
$center = $stmt->fetch();

if (!$center) {
    die("المركز غير موجود أو ليس لديك صلاحية الوصول إليه.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_center'])) {
    $name = trim($_POST['name']);
    $city = trim($_POST['city']);
    $address = trim($_POST['location']);

    if (!empty($name)) {
        try {
            $stmt = $pdo->prepare("UPDATE centers SET name = ?, city = ?, address = ? WHERE id = ? AND user_id = ?");
            $stmt->execute([$name, $city, $address, $center_id, $user_id]);
            $success = "تم تحديث بيانات المركز بنجاح.";
            // إعادة جلب البيانات المحدثة
            $center['name'] = $name;
            $center['city'] = $city;
            $center['location'] = $address;
        } catch (PDOException $e) {
            $error = "خطأ في التحديث: " . $e->getMessage();
        }
    } else {
        $error = "يرجى ملء الحقول المطلوبة.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تعديل مركز | نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, sans-serif; }
        .edit-card { border: none; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card edit-card p-4">
                <h4 class="fw-bold text-primary mb-4"><i class="bi bi-pencil-square me-2"></i> تعديل بيانات المركز</h4>
                
                <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
                <?php if($error) echo "<div class='alert alert-danger'>$error</div>"; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-bold">اسم المركز</label>
                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($center['name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">المدينة</label>
                        <input type="text" name="city" class="form-control" value="<?= htmlspecialchars($center['city']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">العنوان التفصيلي</label>
                        <textarea name="address" class="form-control" rows="3"><?= htmlspecialchars($center['location']) ?></textarea>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" name="update_center" class="btn btn-primary px-4 fw-bold">حفظ التغييرات</button>
                        <a href="centers.php" class="btn btn-light px-4">إلغاء</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
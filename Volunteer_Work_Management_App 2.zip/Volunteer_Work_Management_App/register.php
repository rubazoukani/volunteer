<?php
session_start();
require_once 'config/db.php'; //

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? '';
    $organization_name = trim($_POST['organization_name'] ?? '');

    if (empty($name) || empty($email) || empty($password) || empty($role)) {
        $error = "يرجى ملء جميع الحقول المطلوبة.";
    } elseif ($password !== $confirm_password) {
        $error = "كلمة المرور وتأكيد كلمة المرور غير متطابقين.";
    } elseif (strlen($password) < 6) {
        $error = "يجب أن تكون كلمة المرور على الأقل 6 أحرف.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "البريد الإلكتروني غير صحيح.";
    } elseif ($role === 'org_admin' && empty($organization_name)) {
        $error = "يرجى إدخال اسم المنظمة.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "البريد الإلكتروني مسجل مسبقًا.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // إدراج المستخدم الجديد مع الحالة 'pending' بانتظار موافقة المدير
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, organization_name, status) VALUES (?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([
                $name, 
                $email, 
                $hashed_password, 
                $role, 
                ($role === 'org_admin' ? $organization_name : null)
            ]);
            
            $success = "تم إنشاء الحساب بنجاح! بانتظار موافقة مدير النظام لتتمكن من الدخول.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء حساب - نظام إدارة العمل التطوعي</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root { --primary: #2c5aa0; }
        body { background: linear-gradient(135deg, #f5f7fa 0%, #e4edf9 100%); min-height: 100vh; font-family: 'Segoe UI', Tahoma; }
        .register-container { max-width: 700px; margin: 2rem auto; padding: 2rem; background: white; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.1); }
        .role-card { flex: 1; padding: 1rem; border: 2px solid #e9ecef; border-radius: 15px; cursor: pointer; transition: all 0.3s; text-align: center; }
        .role-card:hover, .role-card.selected { border-color: var(--primary); background-color: rgba(44, 90, 160, 0.05); }
        .role-card i { font-size: 2rem; color: var(--primary); }
    </style>
</head>
<body>
    <div class="register-container">
        <h2 class="text-center mb-4"><i class="bi bi-person-plus"></i> إنشاء حساب جديد</h2>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">الاسم الكامل</label>
                    <input type="text" class="form-control" name="name" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">البريد الإلكتروني</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">كلمة المرور</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">تأكيد كلمة المرور</label>
                    <input type="password" class="form-control" name="confirm_password" required>
                </div>
            </div>

            <label class="form-label">نوع الحساب</label>
            <div class="d-flex gap-3 mb-4">
                <div class="role-card" onclick="selectRole('org_admin')">
                    <i class="bi bi-building"></i>
                    <h6>مدير منظمة</h6>
                    <input type="radio" name="role" value="org_admin" id="role_org" class="d-none" required>
                </div>
                <div class="role-card" onclick="selectRole('volunteer')">
                    <i class="bi bi-person-heart"></i> <h6>متطوع</h6>
                    <input type="radio" name="role" value="volunteer" id="role_vol" class="d-none">
                </div>
                <div class="role-card" onclick="selectRole('citizen')">
                    <i class="bi bi-people"></i>
                    <h6>مواطن</h6>
                    <input type="radio" name="role" value="citizen" id="role_cit" class="d-none">
                </div>
            </div>

            <div id="orgField" class="mb-3 d-none">
                <label class="form-label">اسم المنظمة التطوعية</label>
                <input type="text" class="form-control" name="organization_name" id="organization_name">
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2">إنشاء الحساب</button>
            <div class="text-center mt-3">
                <a href="login.php" class="text-decoration-none">لديك حساب؟ سجل الدخول الآن</a>
            </div>
        </form>
    </div>

    <script>
        function selectRole(role) {
            document.querySelectorAll('.role-card').forEach(c => c.classList.remove('selected'));
            event.currentTarget.classList.add('selected');
            
            if(role === 'org_admin') {
                document.getElementById('role_org').checked = true;
                document.getElementById('orgField').classList.remove('d-none');
            } else if(role === 'volunteer') {
                document.getElementById('role_vol').checked = true;
                document.getElementById('orgField').classList.add('d-none');
            } else {
                document.getElementById('role_cit').checked = true;
                document.getElementById('orgField').classList.add('d-none');
            }
        }
    </script>
</body>
</html>
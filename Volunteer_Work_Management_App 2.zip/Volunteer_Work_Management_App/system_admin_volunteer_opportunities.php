<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

// فقط مدير النظام يمكنه الدخول
requireRole('system_admin');

// جلب جميع فرص التطوع مع تفاصيل المراكز والمدن
$stmt = $pdo->prepare("
    SELECT vo.*, 
           c.name as center_name, 
           c.city as center_city,
           COUNT(vr.id) as applications_count
    FROM volunteer_opportunities vo
    LEFT JOIN centers c ON vo.center_id = c.id
    LEFT JOIN volunteer_requests vr ON vo.id = vr.opportunity_id AND vr.status = 'approved'
    GROUP BY vo.id
    ORDER BY vo.created_at DESC
");
$stmt->execute();
$opportunities = $stmt->fetchAll();

// جلب الإحصائيات
$total_opportunities = count($opportunities);
$open_opportunities = $pdo->query("SELECT COUNT(*) FROM volunteer_opportunities WHERE status = 'open'")->fetchColumn();
$closed_opportunities = $pdo->query("SELECT COUNT(*) FROM volunteer_opportunities WHERE status = 'closed'")->fetchColumn();
$full_opportunities = $pdo->query("SELECT COUNT(*) FROM volunteer_opportunities WHERE status = 'full'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فرص التطوع المتاحة - مدير النظام</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
            --sidebar-width: 280px;
            --sidebar-collapsed-width: 80px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        /* الشريط الجانبي */
        .admin-sidebar {
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            right: 0;
            width: var(--sidebar-width);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: -5px 0 15px rgba(0,0,0,0.1);
        }
        
        .admin-sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .sidebar-logo {
            font-weight: 700;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-logo i {
            color: var(--accent);
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }
        
        .toggle-sidebar:hover {
            background: rgba(255,255,255,0.1);
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-title {
            padding: 15px 25px 10px;
            font-size: 0.8rem;
            text-transform: uppercase;
            color: #adb5bd;
            font-weight: 600;
            letter-spacing: 1px;
        }
        
        .sidebar-menu a {
            color: #adb5bd;
            text-decoration: none;
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s;
            margin: 0 10px 4px;
            border-radius: 8px;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .sidebar-menu a i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-menu a span {
            transition: opacity 0.3s;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a span,
        .admin-sidebar.collapsed .menu-title,
        .admin-sidebar.collapsed .sidebar-logo span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            margin: 0;
        }
        
        .admin-sidebar.collapsed .sidebar-logo {
            justify-content: center;
        }
        
        .admin-sidebar.collapsed .sidebar-menu a {
            justify-content: center;
            padding: 15px;
        }
        
        /* المحتوى الرئيسي */
        .admin-main {
            margin-right: var(--sidebar-width);
            padding: 20px;
            transition: margin-right 0.3s ease;
        }
        
        .admin-main.sidebar-collapsed {
            margin-right: var(--sidebar-collapsed-width);
        }
        
        /* الشريط العلوي */
        .admin-navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 15px 25px;
            margin-bottom: 25px;
            border-radius: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-title h1 {
            color: var(--primary);
            font-weight: 700;
            margin: 0;
            font-size: 1.8rem;
        }
        
        .page-title p {
            color: #6c757d;
            margin: 5px 0 0;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .user-info {
            text-align: right;
        }
        
        .user-info .username {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 2px;
        }
        
        .user-info .role {
            font-size: 0.85rem;
            color: #6c757d;
        }
        
        /* بطاقات فرص التطوع */
        .opportunity-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
            border: none;
            background: white;
        }
        
        .opportunity-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 35px rgba(0,0,0,0.15);
        }
        
        .opportunity-header {
            padding: 25px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            position: relative;
        }
        
        .opportunity-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: rgba(255,255,255,0.2);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
        }
        
        .opportunity-title {
            font-weight: 700;
            font-size: 1.4rem;
            margin: 0 0 15px 0;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .opportunity-center {
            display: inline-flex;
            align-items: center;
            background: rgba(255,255,255,0.25);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.9rem;
            margin-right: 8px;
        }
        
        .opportunity-city {
            display: inline-flex;
            align-items: center;
            background: rgba(255,255,255,0.25);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.9rem;
        }
        
        .opportunity-body {
            padding: 25px;
        }
        
        .opportunity-description {
            color: #495057;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        
        .opportunity-info {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .info-item {
            text-align: center;
            flex: 1;
            min-width: 100px;
        }
        
        .info-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 5px;
        }
        
        .info-label {
            color: #6c757d;
            font-size: 0.85rem;
        }
        
        .status-open { background-color: rgba(40, 167, 69, 0.15); color: #28a745; }
        .status-closed { background-color: rgba(255, 193, 7, 0.15); color: #856404; }
        .status-full { background-color: rgba(220, 53, 69, 0.15); color: #dc3545; }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        
        /* التصميم المتجاوب */
        @media (max-width: 992px) {
            .admin-sidebar {
                transform: translateX(0);
                width: 280px;
            }
            
            .admin-sidebar.collapsed {
                transform: translateX(280px);
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-main.sidebar-collapsed {
                margin-right: 0;
            }
        }
        
        @media (max-width: 768px) {
            .admin-navbar {
                padding: 15px;
            }
            
            .page-title h1 {
                font-size: 1.5rem;
            }
            
            .user-profile {
                gap: 10px;
            }
            
            .avatar {
                width: 40px;
                height: 40px;
                font-size: 1rem;
            }
            
            .opportunity-info {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>

<!-- الشريط الجانبي -->
<div class="admin-sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <i class="bi bi-heart-pulse"></i>
            <span>نظام التطوع</span>
        </div>
        <button class="toggle-sidebar" id="toggleSidebar">
            <i class="bi bi-list"></i>
        </button>
    </div>
    
    <div class="sidebar-menu">
        <a href="system_admin_dashboard.php">
            <i class="bi bi-speedometer2"></i>
            <span>لوحة التحكم</span>
        </a>
        
        <div class="menu-title">الحساب</div>
        <a href="system_admin_profile.php">
            <i class="bi bi-person"></i>
            <span>ملفي الشخصي</span>
        </a>
        
        <div class="menu-title">إدارة الحسابات</div>
        <a href="system_admin_organizations.php">
            <i class="bi bi-building"></i>
            <span>مدراء المنظمات</span>
        </a>
        <a href="system_admin_volunteers.php">
            <i class="bi bi-people"></i>
            <span>المتطوعون</span>
        </a>
        
        <div class="menu-title">إدارة المحتوى</div>
        <a href="system_admin_cities.php">
            <i class="bi bi-geo-alt"></i>
            <span>المدن</span>
        </a>
        <a href="system_admin_centers.php">
            <i class="bi bi-building"></i>
            <span>المراكز التطوعية</span>
        </a>
        <a href="system_admin_citizens.php">
            <i class="bi bi-person-lines-fill"></i>
            <span>المواطنين</span>
        </a>
        <a href="system_admin_volunteer_opportunities.php" class="active">
            <i class="bi bi-hand-index-thumb"></i>
            <span>فرص التطوع</span>
        </a>
        
        <div class="menu-title">التحليلات</div>
        <a href="system_admin_reports.php">
            <i class="bi bi-bar-chart-line"></i>
            <span>التقارير</span>
        </a>
        <a href="system_admin_reviews.php">
            <i class="bi bi-star"></i>
            <span>التقييمات</span>
        </a>
    </div>
</div>

<!-- المحتوى الرئيسي -->
<div class="admin-main" id="mainContent">
    <!-- الشريط العلوي -->
    <div class="admin-navbar">
        <div class="page-title">
            <h1>فرص التطوع المتاحة</h1>
            <p>عرض جميع فرص التطوع المسجلة في النظام</p>
        </div>
        
        <div class="user-profile">
            <div class="avatar">
                <?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?>
            </div>
            <div class="user-info">
                <div class="username"><?= htmlspecialchars($_SESSION['user_name']) ?></div>
                <div class="role">مدير النظام</div>
            </div>
            <a href="logout.php" class="btn btn-outline-danger ms-3">
                <i class="bi bi-box-arrow-right"></i>
            </a>
        </div>
    </div>
    
    <!-- ملخص الإحصائيات -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-left-primary shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-primary font-weight-bold">إجمالي الفرص</h6>
                            <div class="h5 font-weight-bold"><?= $total_opportunities ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-hand-index-thumb text-primary" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-left-success shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-success font-weight-bold">مفتوحة</h6>
                            <div class="h5 font-weight-bold"><?= $open_opportunities ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-check-circle text-success" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-left-warning shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-warning font-weight-bold">مغلقة</h6>
                            <div class="h5 font-weight-bold"><?= $closed_opportunities ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-lock text-warning" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-left-danger shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h6 class="text-uppercase text-danger font-weight-bold">ممتلئة</h6>
                            <div class="h5 font-weight-bold"><?= $full_opportunities ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-people-fill text-danger" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- قائمة فرص التطوع -->
    <h4 class="mb-4">
        <i class="bi bi-list-ul me-2 text-primary"></i>
        قائمة فرص التطوع
    </h4>
    
    <?php if ($opportunities): ?>
        <div class="row g-4">
            <?php foreach ($opportunities as $opportunity): ?>
                <div class="col-lg-6">
                    <div class="card opportunity-card h-100">
                        <div class="opportunity-header">
                            <span class="opportunity-badge">
                                <?php 
                                if ($opportunity['status'] === 'open') echo 'مفتوح';
                                elseif ($opportunity['status'] === 'closed') echo 'مغلق';
                                else echo 'ممتلئ';
                                ?>
                            </span>
                            <h3 class="opportunity-title"><?= htmlspecialchars($opportunity['title']) ?></h3>
                            <?php if ($opportunity['center_name']): ?>
                                <div class="opportunity-center">
                                    <i class="bi bi-building me-1"></i>
                                    <?= htmlspecialchars($opportunity['center_name']) ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($opportunity['center_city']): ?>
                                <div class="opportunity-city">
                                    <i class="bi bi-geo-alt me-1"></i>
                                    <?= htmlspecialchars($opportunity['center_city']) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="opportunity-body">
                            <?php if ($opportunity['description']): ?>
                                <p class="opportunity-description">
                                    <?= htmlspecialchars(substr($opportunity['description'], 0, 200)) ?><?= strlen($opportunity['description']) > 200 ? '...' : '' ?>
                                </p>
                            <?php endif; ?>
                            
                            <div class="opportunity-info">
                                <div class="info-item">
                                    <div class="info-number"><?= $opportunity['applications_count'] ?></div>
                                    <div class="info-label">متطوعين مقبولين</div>
                                </div>
                                
                                <?php if ($opportunity['start_date']): ?>
                                    <div class="info-item">
                                        <div class="info-number">
                                            <i class="bi bi-calendar"></i>
                                        </div>
                                        <div class="info-label">
                                            <?= date('Y-m-d', strtotime($opportunity['start_date'])) ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($opportunity['end_date']): ?>
                                    <div class="info-item">
                                        <div class="info-number">
                                            <i class="bi bi-calendar-x"></i>
                                        </div>
                                        <div class="info-label">
                                            <?= date('Y-m-d', strtotime($opportunity['end_date'])) ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <span class="badge <?= 
                                    $opportunity['status'] === 'open' ? 'status-open' : 
                                    ($opportunity['status'] === 'closed' ? 'status-closed' : 'status-full') 
                                ?>">
                                    <?php 
                                    if ($opportunity['status'] === 'open') echo 'مفتوح';
                                    elseif ($opportunity['status'] === 'closed') echo 'مغلق';
                                    else echo 'ممتلئ';
                                    ?>
                                </span>
                                <small class="text-muted">
                                    <i class="bi bi-clock me-1"></i>
                                    <?= date('Y-m-d', strtotime($opportunity['created_at'])) ?>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-hand-index-thumb fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد فرص تطوع</h4>
            <p class="text-muted">لم يتم تسجيل أي فرص تطوع في النظام حتى الآن.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// تبديل الشريط الجانبي
document.getElementById('toggleSidebar').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('sidebar-collapsed');
});
</script>
</body>
</html>

<?php
require_once '../includes/auth_check.php';
require_once '../config/db.php';


requireRole('org_admin');


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_volunteer_status'])) {
    $user_id = (int)$_POST['user_id'];
    $new_status = $_POST['status'];
    
    if (in_array($new_status, ['active', 'inactive'])) {
        
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'volunteer'");
        $stmt->execute([$new_status, $user_id]);
        
        $success = $new_status === 'active' ? 
            "تم تفعيل حساب المتطوع بنجاح!" : 
            "تم إلغاء تفعيل حساب المتطوع بنجاح!";
            
        header("Location: volunteers.php?success=" . urlencode($success));
        exit();
    }
}



$stmt = $pdo->prepare("
    SELECT u.id as user_id, u.name, u.email, u.status as user_status, u.created_at as user_created_at,
           v.phone, v.city, v.skills, v.availability
    FROM users u
    LEFT JOIN volunteers v ON u.id = v.user_id
    WHERE u.role = 'volunteer'
    ORDER BY u.created_at DESC
");
$stmt->execute();
$volunteers = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المتطوعين - نظام التطوع</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #28a745;
            --accent: #ff6b35;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand span {
            color: var(--primary);
            font-weight: 700;
        }
        
        .volunteer-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .volunteer-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .status-active { background: rgba(40, 167, 69, 0.15); color: #155724; border: 1px solid #c3e6cb; }
        .status-inactive { background: rgba(220, 53, 69, 0.15); color: #721c24; border: 1px solid #f1b0b7; }
        
        .form-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 15px;
            margin-top: 2rem;
        }
        
        .status-badge {
            font-size: 0.85rem;
            padding: 0.4em 0.8em;
            border-radius: 20px;
        }
        
        .skills-tag {
            display: inline-block;
            background: rgba(44, 90, 160, 0.1);
            color: var(--primary);
            padding: 0.2em 0.6em;
            border-radius: 12px;
            font-size: 0.85rem;
            margin: 0.2em;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
    </style>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="../dashboard.php">
            
            <span>نظام التطوع - لوحة التحكم</span>
        </a>
        <div class="d-flex align-items-center">
            <a href="../dashboard.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="bi bi-arrow-left me-1"></i> العودة للوحة التحكم
            </a>
            
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary fw-bold">
            <i class="bi bi-people me-2"></i> إدارة المتطوعين
        </h2>
        <span class="badge bg-primary"><?= count($volunteers) ?> متطوع</span>
    </div>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['error']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_GET['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <h4 class="mb-4"><i class="bi bi-list-ul me-2 text-primary"></i> قائمة المتطوعين</h4>

    <?php if ($volunteers): ?>
        <div class="row g-4">
            <?php foreach ($volunteers as $volunteer): ?>
                <div class="col-lg-6">
                    <div class="card volunteer-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h5 class="card-title mb-1"><?= htmlspecialchars($volunteer['name']) ?></h5>
                                    <p class="text-muted mb-1">
                                        <i class="bi bi-envelope me-1"></i> <?= htmlspecialchars($volunteer['email']) ?>
                                    </p>
                                    <?php if ($volunteer['phone']): ?>
                                        <p class="text-muted mb-0">
                                            <i class="bi bi-telephone me-1"></i> <?= htmlspecialchars($volunteer['phone']) ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                                <span class="status-badge <?= 
                                    $volunteer['user_status'] === 'active' ? 'status-active' : 'status-inactive' 
                                ?>">
                                    <?= $volunteer['user_status'] === 'active' ? 'نشط' : 'غير نشط' ?>
                                </span>
                            </div>
                            
                            <?php if ($volunteer['city']): ?>
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <i class="bi bi-geo-alt me-1"></i> <?= htmlspecialchars($volunteer['city']) ?>
                                    </small>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($volunteer['skills']): ?>
                                <div class="mb-2">
                                    <small class="text-muted me-2">المهارات:</small>
                                    <?php 
                                    $skills = explode(',', $volunteer['skills']);
                                    foreach ($skills as $skill): ?>
                                        <span class="skills-tag"><?= htmlspecialchars(trim($skill)) ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($volunteer['availability']): ?>
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <i class="bi bi-calendar-check me-1"></i> التوافر: <?= htmlspecialchars($volunteer['availability']) ?>
                                    </small>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                <small class="text-muted">
                                    <i class="bi bi-person me-1"></i> منذ <?= date('Y-m-d', strtotime($volunteer['user_created_at'])) ?>
                                </small>
                                
                                <div class="action-buttons">
                                   
                                    <?php if ($volunteer['user_status'] !== 'active'): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?= $volunteer['user_id'] ?>">
                                            <input type="hidden" name="status" value="active">
                                            <button type="submit" name="update_volunteer_status" class="btn btn-success btn-sm">
                                                <i class="bi bi-check-circle me-1"></i> تفعيل
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    
                                    <?php if ($volunteer['user_status'] !== 'inactive'): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?= $volunteer['user_id'] ?>">
                                            <input type="hidden" name="status" value="inactive">
                                            <button type="submit" name="update_volunteer_status" class="btn btn-danger btn-sm">
                                                <i class="bi bi-power me-1"></i> إلغاء التفعيل
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="bi bi-people fs-1 text-muted mb-3"></i>
            <h4 class="text-muted mb-2">لا توجد حسابات متطوعين حتى الآن</h4>
            <p class="text-muted">سيظهر هنا المتطوعون المسجلون في النظام.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

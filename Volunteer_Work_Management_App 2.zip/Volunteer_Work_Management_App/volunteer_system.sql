-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 06, 2026 at 10:21 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `volunteer_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `centers`
--

CREATE TABLE `centers` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `centers`
--

INSERT INTO `centers` (`id`, `user_id`, `name`, `location`, `city`, `description`, `status`, `created_at`) VALUES
(1, 2, 'مركز الرجاء الخيري', 'طريق غباغب', 'درعا', 'مركز يقدم دعماً اجتماعياً وتعليمياً للأسر المحتاجة', 'active', '2025-11-22 11:47:26'),
(2, 2, 'جمعية البر التطوعية', 'شارع الحضارة', 'حمص', 'أنشطة إنسانية وصحية للمجتمع المحلي', 'active', '2025-11-22 11:47:26'),
(4, 2, 'مركز أحمد التطوعي', 'شارع الفرقان', 'حلب', 'استجابة لجميع العمليات الطبية الخاصة بالجراحة', 'active', '2025-11-22 11:54:22'),
(5, 2, 'مركز الشام الطبي', 'دمشق شارع بغداد', 'دمشق', 'مركز يضم جميع الخدمات الطبية(عينية جلدية قلبية )', 'active', '2025-11-22 12:06:24'),
(6, 2, 'مركز الهلال - فرع الميدان', 'حي الميدان - بالقرب من كورنيش الميدان', 'دمشق', 'أنشطة إنسانية وصحية للمجتمع المحلي', 'active', '2026-02-15 11:38:27'),
(7, 2, 'مركز الهلال - فرع الحمدانية', 'حي الحمدانية - الحي الرابع', 'حلب', 'مركز يضم جميع الخدمات الطبية(عينية جلدية قلبية )', 'active', '2026-02-15 11:38:27'),
(8, 2, 'مركز الهلال - فرع المحطة', 'حي المحطة - شارع القوتلي', 'حمص', 'مركز يقدم دعماً اجتماعياً وتعليمياً للأسر المحتاجة', 'active', '2026-02-15 11:38:27');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `created_at`) VALUES
(1, 'دمشق', '2025-11-23 19:46:42'),
(2, 'حلب', '2025-11-23 19:46:42'),
(3, 'حمص', '2025-11-23 19:46:42'),
(4, 'حماة', '2025-11-23 19:46:42'),
(5, 'اللاذقية', '2025-11-23 19:46:42'),
(6, 'طرطوس', '2025-11-23 19:46:42'),
(7, 'درعا', '2025-11-23 19:46:42'),
(8, 'السويداء', '2025-11-23 19:46:42'),
(9, 'إدلب', '2025-11-23 19:46:42'),
(10, 'الرقة', '2025-11-23 19:46:42'),
(11, 'دير الزور', '2025-11-23 19:46:42'),
(12, 'الحسكة', '2025-11-23 19:46:42'),
(13, 'القامشلي', '2025-11-23 19:46:42'),
(14, 'القنيطرة', '2025-11-23 19:46:42');

-- --------------------------------------------------------

--
-- Table structure for table `citizens`
--

CREATE TABLE `citizens` (
  `id` int NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `id_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('ذكر','أنثى') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `citizens`
--

INSERT INTO `citizens` (`id`, `full_name`, `email`, `phone`, `city`, `address`, `id_number`, `birth_date`, `gender`, `status`, `created_at`, `updated_at`) VALUES
(1, 'أحمد محمد العلي', 'ahmad.ali@example.com', '0912345678', 'دمشق', 'حي الميدان، شارع بغداد رقم 45', '1234567890', '1985-03-15', 'ذكر', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(2, 'نادين اسماعيل دعاس', 'nadeen.ismaeel@org.com', '0923456789', 'حلب', 'حي الشهباء، مبنى 12، شقة 3', '2345678901', '1990-07-22', 'أنثى', 'active', '2025-11-24 11:10:48', '2026-03-06 09:52:49'),
(3, 'محمد يوسف أحمد', 'mohammed.yusuf@example.com', '0934567890', 'حمص', 'حي الزهراء، شارع الثورة رقم 78', '3456789012', '1978-11-05', 'ذكر', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(4, 'فاطمة عبد الله', 'fatima.abdullah@example.com', '0945678901', 'اللاذقية', 'حي الصليبة، عمارة النور، طابق 2', '4567890123', '1995-01-30', 'أنثى', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(5, 'خالد سامي محمد', 'khaled.sami@example.com', '0956789012', 'درعا', 'حي السبيل، شارع تشرين رقم 23', '5678901234', '1982-09-12', 'ذكر', 'inactive', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(6, 'رنا علي الحسن', 'rana.hassan@example.com', '0967890123', 'السويداء', 'حي المزة، مبنى السلام، شقة 7', '6789012345', '1993-05-18', 'أنثى', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(7, 'علي محمد عبد الرحمن', 'ali.abdulrahman@example.com', '0978901234', 'إدلب', 'حي المعارض، شارع السلام رقم 67', '7890123456', '1988-12-25', 'ذكر', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(8, 'لمى خالد', 'lama.khaled@example.com', '0989012345', 'الرقة', 'حي النخيل، عمارة الفرات، طابق 3', '8901234567', '1997-08-14', 'أنثى', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(9, 'ياسر سامي', 'yasser.sami@example.com', '0990123456', 'دير الزور', 'حي الفرات، شارع التنظيم رقم 34', '9012345678', '1980-04-03', 'ذكر', 'inactive', '2025-11-24 11:10:48', '2025-11-24 11:10:48'),
(10, 'منى أحمد', 'mona.ahmed@example.com', '0901234567', 'الحسكة', 'حي غويران، مبنى الكرامة، شقة 5', '0123456789', '1992-06-21', 'أنثى', 'active', '2025-11-24 11:10:48', '2025-11-24 11:10:48');

-- --------------------------------------------------------

--
-- Table structure for table `help_requests`
--

CREATE TABLE `help_requests` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requester_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requester_contact` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_id` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','accepted','rejected','approved') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `help_requests`
--

INSERT INTO `help_requests` (`id`, `user_id`, `organization_id`, `title`, `requester_name`, `requester_contact`, `service_id`, `description`, `status`, `submitted_at`, `created_at`) VALUES
(1, 5, 2, 'مساعدة طبية', 'فاطمة علي', '0911223344', 1, 'أسرة مكونة من 6 أفراد بحاجة لسلال غذائية', 'pending', '2025-11-22 11:47:26', '2026-02-15 08:19:53'),
(2, 5, 2, 'مساعدة تعليمية', 'محمد القحطاني', '099887766', 5, 'شاب بحاجة لدورة تأهيل مهني في مجال الحاسوب', 'pending', '2025-11-22 11:47:26', '2026-02-15 08:19:53'),
(3, 5, 2, 'سلة غذائية', 'أم خالد', '099662255', 2, 'أحتاج دعماً نفسياً بعد وفاة زوجي', 'pending', '2025-11-22 11:47:26', '2026-02-15 08:19:53'),
(7, 4, 2, 'سلة غذائية', 'نادين اسماعيل دعاس', '0923456789', 1, 'أسرة مكونة من 4 أفراد أحدهم مريض بحاجة سلة غذائية', 'pending', '2026-02-15 08:32:27', '2026-02-15 08:32:27'),
(9, 4, 2, 'مساعدة طبية', 'نادين اسماعيل دعاس', '0923456789', 6, 'رعاية كبير في السن هو أحد أفراد العائلة', 'accepted', '2026-02-15 08:33:56', '2026-02-15 08:33:56');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `is_read`, `created_at`) VALUES
(1, 4, 'تم رفض طلب المساعدة الخاص بك بخصوص ()', 1, '2026-02-15 11:47:07'),
(2, 4, 'تم قبول طلب المساعدة الخاص بك بخصوص ()', 1, '2026-02-15 11:47:09');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `user_id` int NOT NULL COMMENT 'رقم المواطن الذي قام بالتقييم',
  `organization_id` int NOT NULL COMMENT 'رقم المنظمة التي تم تقييمها',
  `rating` int NOT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `organization_id`, `rating`, `comment`, `created_at`) VALUES
(1, 1, 2, 5, 'استجابة سريعة جداً من مركز الفيحاء، شكراً لتأمين السلة الغذائية في وقت قياسي.', '2026-02-15 15:26:54'),
(2, 1, 3, 4, 'منظمة الشهباء متميزة في التنظيم، لكن كان هناك تأخير بسيط في الرد على الهاتف.', '2026-02-15 15:26:54'),
(3, 1, 4, 5, 'تعامل راقٍ جداً من قبل المتطوعين في مركز حمص، جزاكم الله خيراً.', '2026-02-15 15:26:54'),
(4, 1, 2, 2, 'للأسف الخدمة كانت بطيئة والوصف لم يكن مطابقاً للواقع تماماً.', '2026-02-15 15:26:54');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `user_id`, `name`, `description`, `status`, `created_at`) VALUES
(1, 2, 'توزيع السلال الغذائية', 'توفير سلال غذائية شهرية مناسبة للأسر المتعففة', 'active', '2025-11-22 11:47:26'),
(2, 2, 'الدعم النفسي', 'جلسات دعم نفسي مجانية للمحتاجين', 'active', '2025-11-22 11:47:26'),
(5, 2, 'دعم تعليمي', 'دعم التعليم في المرحلة الدراسية الأولى وحتى المرحلة الجامعية', 'active', '2026-02-15 11:21:40'),
(6, 2, 'رعاية كبار السن', 'رعاية كبار السن اللذين ليس لديهم أبناء قادرون على إعالتهم ضمن مراكز متخصصة', 'active', '2026-02-15 11:30:27');

-- --------------------------------------------------------

--
-- Table structure for table `training_opportunities`
--

CREATE TABLE `training_opportunities` (
  `id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `center_id` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('open','closed','full') COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `training_opportunities`
--

INSERT INTO `training_opportunities` (`id`, `title`, `description`, `center_id`, `start_date`, `end_date`, `status`, `created_at`) VALUES
(1, 'دورة إدارة المشاريع التطوعية', 'تعلم أساسيات إدارة المشاريع الخيرية', 1, '2025-12-05', '2025-12-20', 'open', '2025-11-22 11:47:26'),
(2, 'ورشة مهارات التواصل', 'تحسين مهارات التواصل مع المستفيدين', 2, '2026-01-10', '2026-01-12', 'open', '2025-11-22 11:47:26'),
(4, 'دورة الإسعافات الأولية المتقدمة', 'تدريب مكثف على مهارات الإنقاذ والإسعاف الأولي تحت إشراف متخصصين.', 1, '2024-06-01', '2024-06-15', 'open', '2026-02-14 17:21:43');

-- --------------------------------------------------------

--
-- Table structure for table `training_requests`
--

CREATE TABLE `training_requests` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `training_id` int NOT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `training_requests`
--

INSERT INTO `training_requests` (`id`, `user_id`, `training_id`, `status`, `notes`, `submitted_at`) VALUES
(1, 11, 4, 'pending', NULL, '2026-02-14 17:21:51'),
(2, 3, 4, 'pending', NULL, '2026-02-14 18:45:07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('system_admin','org_admin','volunteer','citizen') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `organization_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'اسم المنظمة (اختياري لمدير المنظمة)',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `status`, `organization_name`, `phone`, `created_at`, `updated_at`, `city`) VALUES
(1, 'مدير النظام', 'sysadmin@org.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'system_admin', 'active', NULL, '099632597', '2025-11-22 11:33:55', '2026-03-06 09:48:10', NULL),
(2, 'مدير منظمة الخير', 'orgadmin@org.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'org_admin', 'active', 'جمعية الخير التطوعية', '0933987452', '2025-11-22 11:33:55', '2026-03-06 09:48:15', NULL),
(3, 'ربا محمد سامر زوكاني', 'ruba.zokani@org.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'volunteer', 'active', NULL, '0912345678', '2025-11-22 12:57:47', '2026-03-06 09:53:15', NULL),
(4, 'نادين اسماعيل دعاس', 'nadeen.ismaeel@org.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'citizen', 'active', NULL, '0923456789', '2025-11-22 12:57:47', '2026-03-06 09:54:34', NULL),
(5, 'محمد يوسف أحمد', 'mohammed.youssef@org.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'citizen', 'active', NULL, '0934567890', '2025-11-22 12:57:47', '2026-03-06 09:50:18', NULL),
(6, 'فاطمة عبد الله', 'fatima.abdullah@org.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'volunteer', 'inactive', NULL, '0945678901', '2025-11-22 12:57:47', '2026-03-06 09:50:23', NULL),
(7, 'خالد سامي', 'khalid.sami@org.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'volunteer', 'active', NULL, '0956789012', '2025-11-22 12:57:47', '2026-03-06 09:50:28', NULL),
(8, 'أحمد الكامل', 'amal@gmail.com', '$2y$10$1Vn/TmtpCNYgq/RMC4FVqOzKPi1I5PHDUJ2NJAsepA3w80CobIPd.', 'org_admin', 'inactive', 'منظمة الأمل', NULL, '2025-11-24 09:44:32', '2025-11-24 09:55:42', NULL),
(11, 'أحمد المتطوع', 'volunteer_test@org.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'volunteer', 'active', NULL, NULL, '2026-02-14 17:21:36', '2026-03-06 09:50:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skills` text COLLATE utf8mb4_unicode_ci,
  `availability` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `volunteers`
--

INSERT INTO `volunteers` (`id`, `user_id`, `phone`, `city`, `skills`, `availability`, `status`, `created_at`) VALUES
(1, 3, '0912345678', 'دمشق', 'التصميم الجرافيكي, مونتاج الفيديو, التصوير الفوتوغرافي', 'عطلة نهاية الأسبوع', 'approved', '2025-11-22 12:58:14'),
(2, 4, '0923456789', 'حلب', 'التدريس, الإرشاد النفسي, الكتابة', 'مساءً بعد الساعة 5', 'pending', '2025-11-22 12:58:14'),
(3, 5, '0934567890', 'حمص', 'البرمجة, تطوير المواقع, دعم فني', 'مرن', 'approved', '2025-11-22 12:58:14'),
(4, 6, '0945678901', 'اللاذقية', 'الترجمة, اللغة الإنجليزية, الترجمة الفورية', 'عطلة نهاية الأسبوع', 'rejected', '2025-11-22 12:58:14'),
(5, 7, '0956789012', 'درعا', 'الإسعافات الأولية, الرعاية الصحية, التمريض', 'مساءً وبعد الظهر', 'pending', '2025-11-22 12:58:14');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_opportunities`
--

CREATE TABLE `volunteer_opportunities` (
  `id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `center_id` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('open','closed','full') COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `volunteer_opportunities`
--

INSERT INTO `volunteer_opportunities` (`id`, `title`, `description`, `center_id`, `start_date`, `end_date`, `status`, `created_at`) VALUES
(2, 'دعم فعالية خيرية', 'المساهمة في تنظيم فعالية جمع التبرعات', 2, '2025-11-25', '2025-11-26', 'full', '2025-11-22 11:47:26'),
(3, 'مرشد تطوعي', 'توجيه المتطوعين الجدد وتدريبهم', 1, '2025-12-10', '2026-03-10', 'open', '2025-11-22 11:47:26'),
(4, 'مساعد طبيب', 'مساعدة الأطباء قسم التمريض', 4, '2025-11-22', '2025-11-29', 'full', '2025-11-22 12:12:21');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_requests`
--

CREATE TABLE `volunteer_requests` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `user_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `opportunity_id` int DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `volunteer_requests`
--

INSERT INTO `volunteer_requests` (`id`, `user_id`, `user_name`, `user_email`, `opportunity_id`, `status`, `notes`, `submitted_at`) VALUES
(3, 7, 'خالد سامي', 'khaled@example.comkhalid.sami@example.com', 2, 'rejected', NULL, '2025-11-22 11:47:26'),
(4, 3, 'أحمد محمد العلي', 'ahmad.alali@example.com', 3, 'pending', NULL, '2026-02-14 18:11:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `centers`
--
ALTER TABLE `centers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_center_org` (`user_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `citizens`
--
ALTER TABLE `citizens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_number` (`id_number`);

--
-- Indexes for table `help_requests`
--
ALTER TABLE `help_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `fk_help_citizen` (`user_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_review_user` (`user_id`),
  ADD KEY `fk_review_org` (`organization_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_opportunities`
--
ALTER TABLE `training_opportunities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `center_id` (`center_id`);

--
-- Indexes for table `training_requests`
--
ALTER TABLE `training_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_training_user` (`user_id`),
  ADD KEY `fk_training_opp` (`training_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `volunteer_opportunities`
--
ALTER TABLE `volunteer_opportunities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `center_id` (`center_id`);

--
-- Indexes for table `volunteer_requests`
--
ALTER TABLE `volunteer_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `opportunity_id` (`opportunity_id`),
  ADD KEY `fk_volunteer_user` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `centers`
--
ALTER TABLE `centers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `citizens`
--
ALTER TABLE `citizens`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `help_requests`
--
ALTER TABLE `help_requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `training_opportunities`
--
ALTER TABLE `training_opportunities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `training_requests`
--
ALTER TABLE `training_requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `volunteer_opportunities`
--
ALTER TABLE `volunteer_opportunities`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `volunteer_requests`
--
ALTER TABLE `volunteer_requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `centers`
--
ALTER TABLE `centers`
  ADD CONSTRAINT `fk_center_org` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `help_requests`
--
ALTER TABLE `help_requests`
  ADD CONSTRAINT `fk_help_citizen` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `help_requests_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `fk_review_org` FOREIGN KEY (`organization_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_review_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `training_opportunities`
--
ALTER TABLE `training_opportunities`
  ADD CONSTRAINT `training_opportunities_ibfk_1` FOREIGN KEY (`center_id`) REFERENCES `centers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `training_requests`
--
ALTER TABLE `training_requests`
  ADD CONSTRAINT `fk_training_opp` FOREIGN KEY (`training_id`) REFERENCES `training_opportunities` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_training_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD CONSTRAINT `volunteers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `volunteer_opportunities`
--
ALTER TABLE `volunteer_opportunities`
  ADD CONSTRAINT `volunteer_opportunities_ibfk_1` FOREIGN KEY (`center_id`) REFERENCES `centers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `volunteer_requests`
--
ALTER TABLE `volunteer_requests`
  ADD CONSTRAINT `fk_volunteer_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `volunteer_requests_ibfk_1` FOREIGN KEY (`opportunity_id`) REFERENCES `volunteer_opportunities` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
